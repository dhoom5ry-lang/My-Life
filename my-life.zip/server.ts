import 'dotenv/config';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import express, { type NextFunction, type Request, type Response } from 'express';
import multer from 'multer';
import { GoogleGenAI } from '@google/genai';
import {
  db,
  DEFAULT_STARTER_FOLDERS,
  DEFAULT_TILE_ORDER,
  UPLOAD_ROOT,
} from './src/db/database.ts';

const PORT = 3000;
const EPHEMERAL_FALLBACK_KEY = crypto.randomBytes(32).toString('hex');

const ALLOWED_EXTS = new Set([
  'pdf',
  'docx',
  'xlsx',
  'pptx',
  'txt',
  'csv',
  'json',
  'jpg',
  'jpeg',
  'png',
  'webp',
  'mp4',
  'zip',
]);

interface AuthUser {
  id: string;
  email: string;
  name: string;
  avatar_url: string;
  language: string;
  theme: string;
  accent_color: string;
  icon_shape: string;
  card_style: string;
  plan: string;
  assistant_consent: string;
  notifications_enabled: number;
  privacy_mode: number;
  created_at: string;
}

interface AuthRequest extends Request {
  user?: AuthUser;
  sessionId?: string;
}

function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyPassword(password: string, storedHash: string): boolean {
  const parts = storedHash.split(':');
  if (parts.length !== 2) return false;
  const [salt, keyHex] = parts;
  const derived = crypto.scryptSync(password, salt, 64);
  const keyBuf = Buffer.from(keyHex, 'hex');
  if (derived.length !== keyBuf.length) return false;
  return crypto.timingSafeEqual(derived, keyBuf);
}

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function parseCookies(cookieHeader?: string): Record<string, string> {
  const result: Record<string, string> = {};
  if (!cookieHeader) return result;
  for (const part of cookieHeader.split(';')) {
    const idx = part.indexOf('=');
    if (idx === -1) continue;
    const key = part.slice(0, idx).trim();
    const val = decodeURIComponent(part.slice(idx + 1).trim());
    result[key] = val;
  }
  return result;
}

function setSessionCookie(req: Request, res: Response, token: string, maxAgeDays: number) {
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  const maxAge = maxAgeDays * 24 * 60 * 60;
  const parts = [
    `mylife_session=${encodeURIComponent(token)}`,
    'HttpOnly',
    'Path=/',
    `Max-Age=${maxAge}`,
  ];
  if (isHttps) {
    parts.push('Secure', 'SameSite=None', 'Partitioned');
  } else {
    parts.push('SameSite=Lax');
  }
  res.setHeader('Set-Cookie', parts.join('; '));
}

function clearSessionCookie(req: Request, res: Response) {
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  const parts = ['mylife_session=', 'HttpOnly', 'Path=/', 'Max-Age=0'];
  if (isHttps) {
    parts.push('Secure', 'SameSite=None', 'Partitioned');
  } else {
    parts.push('SameSite=Lax');
  }
  res.setHeader('Set-Cookie', parts.join('; '));
}

function detectDeviceName(ua: string): string {
  if (/iphone/i.test(ua)) return 'iPhone';
  if (/ipad/i.test(ua)) return 'iPad';
  if (/android/i.test(ua)) return 'Android Device';
  if (/macintosh|mac os/i.test(ua)) return 'Mac';
  if (/windows/i.test(ua)) return 'Windows PC';
  if (/linux/i.test(ua)) return 'Linux';
  return 'Web Browser';
}

function logActivity(userId: string, action: string, module: string, details = '') {
  db.prepare(
    'INSERT INTO activity_logs (id, user_id, action, module, details, created_at) VALUES (?, ?, ?, ?, ?, ?)'
  ).run(crypto.randomUUID(), userId, action, module, details, new Date().toISOString());
}

function addNotification(userId: string, title: string, body: string, type = 'info', linkModule = 'dashboard') {
  db.prepare(
    'INSERT INTO notifications (id, user_id, title, body, type, is_read, link_module, created_at) VALUES (?, ?, ?, ?, ?, 0, ?, ?)'
  ).run(crypto.randomUUID(), userId, title, body, type, linkModule, new Date().toISOString());
}

function resolveUserUploadPath(userId: string, fileName: string): string {
  const userDir = path.resolve(UPLOAD_ROOT, userId);
  if (!fs.existsSync(userDir)) {
    fs.mkdirSync(userDir, { recursive: true });
  }
  const target = path.resolve(userDir, path.basename(fileName));
  if (!target.startsWith(userDir + path.sep)) {
    throw new Error('Invalid file path');
  }
  return target;
}

function resolveExistingUploadPath(userId: string, storedPath: string): string {
  const userDir = path.resolve(UPLOAD_ROOT, userId);
  const resolved = path.resolve(storedPath);
  if (!resolved.startsWith(userDir + path.sep)) {
    throw new Error('Access denied');
  }
  return resolved;
}

function encryptBackupData(plainText: string, passphrase?: string): string {
  const secret = passphrase?.trim() || process.env.BACKUP_ENCRYPTION_SECRET || EPHEMERAL_FALLBACK_KEY;
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(secret, salt, 32);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return JSON.stringify({
    v: 1,
    alg: 'aes-256-gcm',
    userPassphraseProtected: Boolean(passphrase?.trim()),
    salt: salt.toString('hex'),
    iv: iv.toString('hex'),
    tag: tag.toString('hex'),
    data: encrypted.toString('base64'),
  });
}

function decryptBackupData(envelopeRaw: string, passphrase?: string): string {
  const env = JSON.parse(envelopeRaw);
  const secret = passphrase?.trim() || process.env.BACKUP_ENCRYPTION_SECRET || EPHEMERAL_FALLBACK_KEY;
  const salt = Buffer.from(env.salt, 'hex');
  const iv = Buffer.from(env.iv, 'hex');
  const tag = Buffer.from(env.tag, 'hex');
  const key = crypto.scryptSync(secret, salt, 32);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  const plain = Buffer.concat([decipher.update(Buffer.from(env.data, 'base64')), decipher.final()]);
  return plain.toString('utf8');
}

function requireAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  let token = '';
  let usedCookie = false;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.slice(7).trim();
  } else {
    const cookies = parseCookies(req.headers.cookie);
    if (cookies.mylife_session) {
      token = cookies.mylife_session;
      usedCookie = true;
    }
  }

  if (!token) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  if (usedCookie && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) {
    const hasCustomHeader = req.headers['x-requested-with'] === 'MYLIFE-PWA';
    const origin = req.headers.origin;
    const host = (req.headers['x-forwarded-host'] || req.headers.host || '') as string;
    const originHost = origin ? new URL(origin).host : '';
    if (!hasCustomHeader && originHost !== host) {
      res.status(403).json({ error: 'CSRF check failed' });
      return;
    }
  }

  const tokenHash = hashToken(token);
  const session = db
    .prepare('SELECT id, user_id, expires_at FROM sessions WHERE token_hash = ?')
    .get(tokenHash) as { id: string; user_id: string; expires_at: string } | undefined;

  if (!session || new Date(session.expires_at).getTime() < Date.now()) {
    if (session) {
      db.prepare('DELETE FROM sessions WHERE id = ?').run(session.id);
    }
    res.status(401).json({ error: 'Session expired' });
    return;
  }

  const user = db
    .prepare(
      `SELECT id, email, name, avatar_url, language, theme, accent_color, icon_shape, card_style,
              plan, assistant_consent, notifications_enabled, privacy_mode, created_at
       FROM users WHERE id = ?`
    )
    .get(session.user_id) as AuthUser | undefined;

  if (!user) {
    res.status(401).json({ error: 'User not found' });
    return;
  }

  db.prepare('UPDATE sessions SET last_active_at = ? WHERE id = ?').run(
    new Date().toISOString(),
    session.id
  );

  req.user = user;
  req.sessionId = session.id;
  next();
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
});

function createDefaultUserResources(userId: string, userName: string) {
  const now = new Date().toISOString();
  db.prepare('INSERT OR IGNORE INTO dashboard_configs (user_id, tiles_order) VALUES (?, ?)').run(
    userId,
    JSON.stringify(DEFAULT_TILE_ORDER)
  );
  db.prepare('INSERT OR IGNORE INTO icon_prefs (user_id, favorites_json, recent_json) VALUES (?, ?, ?)').run(
    userId,
    '[]',
    '[]'
  );
  const insertFolder = db.prepare(
    `INSERT INTO folders (id, user_id, name, color_hex, opacity, icon_name, style, is_favorite, sort_order, created_at)
     VALUES (?, ?, ?, ?, 84, ?, 'glass', ?, ?, ?)`
  );
  DEFAULT_STARTER_FOLDERS.forEach((f, idx) => {
    insertFolder.run(crypto.randomUUID(), userId, f.name, f.color_hex, f.icon_name, idx < 2 ? 1 : 0, idx, now);
  });
  addNotification(
    userId,
    'مرحبًا بك في MY LIFE',
    `تم تجهيز مساحتك الرقمية بنجاح يا ${userName}. يمكنك رفع مستنداتك أو تخصيص لوحة التحكم.`,
    'success',
    'documents'
  );
}

function getFamilyMembership(userId: string) {
  return db
    .prepare(
      `SELECT fm.*, f.name as family_name, f.invite_code, f.owner_id
       FROM family_members fm
       JOIN families f ON f.id = fm.family_id
       WHERE fm.user_id = ?
       LIMIT 1`
    )
    .get(userId) as
    | {
        id: string;
        family_id: string;
        user_id: string;
        display_name: string;
        relation: string;
        role: string;
        permissions: string;
        family_name: string;
        invite_code: string;
        owner_id: string;
      }
    | undefined;
}

async function startServer() {
  const app = express();
  app.set('trust proxy', 1);
  app.use(express.json({ limit: '10mb' }));

  // Health
  app.get('/api/health', (_req, res) => {
    res.json({ ok: true, app: 'MY LIFE', timestamp: new Date().toISOString() });
  });

  // --- AUTH ---
  app.post('/api/auth/register', (req, res) => {
    try {
      const email = String(req.body?.email || '').trim().toLowerCase();
      const password = String(req.body?.password || '');
      const name = String(req.body?.name || '').trim() || email.split('@')[0];
      const language = req.body?.language === 'en' ? 'en' : 'ar';

      if (!email || !email.includes('@') || password.length < 6) {
        res.status(400).json({ error: 'يرجى إدخال بريد إلكتروني صحيح وكلمة مرور لا تقل عن 6 أحرف' });
        return;
      }

      const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
      if (existing) {
        res.status(409).json({ error: 'البريد الإلكتروني مسجل مسبقًا' });
        return;
      }

      const userId = crypto.randomUUID();
      const now = new Date().toISOString();
      db.prepare(
        `INSERT INTO users (id, email, password_hash, name, language, created_at)
         VALUES (?, ?, ?, ?, ?, ?)`
      ).run(userId, email, hashPassword(password), name, language, now);

      createDefaultUserResources(userId, name);

      const rawToken = crypto.randomBytes(32).toString('hex');
      const sessionId = crypto.randomUUID();
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();
      db.prepare(
        `INSERT INTO sessions (id, token_hash, user_id, device_name, user_agent, ip_address, expires_at, created_at, last_active_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        sessionId,
        hashToken(rawToken),
        userId,
        detectDeviceName(String(req.headers['user-agent'] || '')),
        String(req.headers['user-agent'] || ''),
        req.ip || '',
        expiresAt,
        now,
        now
      );

      setSessionCookie(req, res, rawToken, 30);
      logActivity(userId, 'إنشاء حساب جديد', 'auth', email);

      const user = db
        .prepare(
          `SELECT id, email, name, avatar_url, language, theme, accent_color, icon_shape, card_style,
                  plan, assistant_consent, notifications_enabled, privacy_mode, created_at
           FROM users WHERE id = ?`
        )
        .get(userId);
      res.status(201).json({ user, token: rawToken });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/auth/login', (req, res) => {
    try {
      const email = String(req.body?.email || '').trim().toLowerCase();
      const password = String(req.body?.password || '');
      const remember = Boolean(req.body?.remember);

      const row = db
        .prepare('SELECT id, password_hash FROM users WHERE email = ?')
        .get(email) as { id: string; password_hash: string } | undefined;

      if (!row || !verifyPassword(password, row.password_hash)) {
        res.status(401).json({ error: 'بيانات الدخول غير صحيحة' });
        return;
      }

      const rawToken = crypto.randomBytes(32).toString('hex');
      const sessionId = crypto.randomUUID();
      const days = remember ? 30 : 1;
      const now = new Date().toISOString();
      const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();

      db.prepare(
        `INSERT INTO sessions (id, token_hash, user_id, device_name, user_agent, ip_address, expires_at, created_at, last_active_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        sessionId,
        hashToken(rawToken),
        row.id,
        detectDeviceName(String(req.headers['user-agent'] || '')),
        String(req.headers['user-agent'] || ''),
        req.ip || '',
        expiresAt,
        now,
        now
      );

      setSessionCookie(req, res, rawToken, days);
      logActivity(row.id, 'تسجيل دخول', 'auth', detectDeviceName(String(req.headers['user-agent'] || '')));

      const user = db
        .prepare(
          `SELECT id, email, name, avatar_url, language, theme, accent_color, icon_shape, card_style,
                  plan, assistant_consent, notifications_enabled, privacy_mode, created_at
           FROM users WHERE id = ?`
        )
        .get(row.id);

      res.json({ user, token: rawToken });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.post('/api/auth/logout', requireAuth, (req: AuthRequest, res) => {
    if (req.sessionId) {
      db.prepare('DELETE FROM sessions WHERE id = ?').run(req.sessionId);
    }
    clearSessionCookie(req, res);
    res.json({ ok: true });
  });

  app.get('/api/auth/me', requireAuth, (req: AuthRequest, res) => {
    res.json({ user: req.user });
  });

  app.patch('/api/auth/profile', requireAuth, (req: AuthRequest, res) => {
    const u = req.user!;
    const name = req.body?.name !== undefined ? String(req.body.name).trim() : u.name;
    const email = req.body?.email !== undefined ? String(req.body.email).trim().toLowerCase() : u.email;
    const avatar_url = req.body?.avatar_url !== undefined ? String(req.body.avatar_url) : u.avatar_url;
    const language = req.body?.language === 'en' ? 'en' : req.body?.language === 'ar' ? 'ar' : u.language;
    const theme = req.body?.theme === 'light' ? 'light' : req.body?.theme === 'dark' ? 'dark' : u.theme;
    const accent_color = req.body?.accent_color ? String(req.body.accent_color) : u.accent_color;
    const icon_shape = req.body?.icon_shape ? String(req.body.icon_shape) : u.icon_shape;
    const card_style = req.body?.card_style === 'classic' ? 'classic' : req.body?.card_style === 'glass' ? 'glass' : u.card_style;
    const assistant_consent = req.body?.assistant_consent
      ? JSON.stringify(req.body.assistant_consent)
      : u.assistant_consent;
    const notifications_enabled =
      req.body?.notifications_enabled !== undefined ? (req.body.notifications_enabled ? 1 : 0) : u.notifications_enabled;
    const privacy_mode = req.body?.privacy_mode !== undefined ? (req.body.privacy_mode ? 1 : 0) : u.privacy_mode;

    db.prepare(
      `UPDATE users SET name=?, email=?, avatar_url=?, language=?, theme=?, accent_color=?, icon_shape=?, card_style=?,
       assistant_consent=?, notifications_enabled=?, privacy_mode=? WHERE id=?`
    ).run(
      name,
      email,
      avatar_url,
      language,
      theme,
      accent_color,
      icon_shape,
      card_style,
      assistant_consent,
      notifications_enabled,
      privacy_mode,
      u.id
    );

    logActivity(u.id, 'تحديث الملف الشخصي والإعدادات', 'settings');
    const updated = db
      .prepare(
        `SELECT id, email, name, avatar_url, language, theme, accent_color, icon_shape, card_style,
                plan, assistant_consent, notifications_enabled, privacy_mode, created_at
         FROM users WHERE id = ?`
      )
      .get(u.id);
    res.json({ user: updated });
  });

  app.post('/api/auth/password', requireAuth, (req: AuthRequest, res) => {
    const u = req.user!;
    const currentPassword = String(req.body?.currentPassword || '');
    const newPassword = String(req.body?.newPassword || '');
    if (newPassword.length < 6) {
      res.status(400).json({ error: 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل' });
      return;
    }
    const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(u.id) as { password_hash: string };
    if (!verifyPassword(currentPassword, row.password_hash)) {
      res.status(400).json({ error: 'كلمة المرور الحالية غير صحيحة' });
      return;
    }
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(newPassword), u.id);
    logActivity(u.id, 'تغيير كلمة المرور', 'security');
    res.json({ ok: true });
  });

  app.get('/api/auth/sessions', requireAuth, (req: AuthRequest, res) => {
    const rows = db
      .prepare('SELECT id, device_name, ip_address, created_at, last_active_at, expires_at FROM sessions WHERE user_id = ? ORDER BY last_active_at DESC')
      .all(req.user!.id);
    res.json({ sessions: rows, currentSessionId: req.sessionId });
  });

  app.delete('/api/auth/sessions/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM sessions WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  app.get('/api/auth/export-data', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const bundle = {
      exportedAt: new Date().toISOString(),
      user: req.user,
      folders: db.prepare('SELECT * FROM folders WHERE user_id = ?').all(uid),
      documents: db.prepare('SELECT id, folder_id, name, original_name, mime_type, ext, size_bytes, is_favorite, created_at, updated_at FROM documents WHERE user_id = ?').all(uid),
      purchases: db.prepare('SELECT * FROM purchases WHERE user_id = ?').all(uid),
      transactions: db.prepare('SELECT * FROM transactions WHERE user_id = ?').all(uid),
      subscriptions: db.prepare('SELECT * FROM subscriptions WHERE user_id = ?').all(uid),
      events: db.prepare('SELECT * FROM events WHERE user_id = ?').all(uid),
      budgets: db.prepare('SELECT * FROM budgets WHERE user_id = ?').all(uid),
      savings_goals: db.prepare('SELECT * FROM savings_goals WHERE user_id = ?').all(uid),
      warranties: db.prepare('SELECT * FROM warranties WHERE user_id = ?').all(uid),
      maintenance_logs: db.prepare('SELECT * FROM maintenance_logs WHERE user_id = ?').all(uid),
      properties: db.prepare('SELECT * FROM properties WHERE user_id = ?').all(uid),
      trips: db.prepare('SELECT * FROM trips WHERE user_id = ?').all(uid),
      tasks: db.prepare('SELECT * FROM tasks WHERE user_id = ?').all(uid),
      contacts: db.prepare('SELECT * FROM contacts WHERE user_id = ?').all(uid),
      vault_items: db.prepare('SELECT * FROM vault_items WHERE user_id = ?').all(uid),
      custom_widgets: db.prepare('SELECT * FROM custom_widgets WHERE user_id = ?').all(uid),
    };
    res.setHeader('Content-Disposition', 'attachment; filename="mylife-export.json"');
    res.json(bundle);
  });

  app.delete('/api/auth/delete-account', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const userDir = path.resolve(UPLOAD_ROOT, uid);
    if (userDir.startsWith(UPLOAD_ROOT + path.sep) && fs.existsSync(userDir)) {
      fs.rmSync(userDir, { recursive: true, force: true });
    }
    db.prepare('DELETE FROM users WHERE id = ?').run(uid);
    clearSessionCookie(req, res);
    res.json({ ok: true });
  });

  // Explicit user-triggered sample workspace loader (never auto-seeded as real user data)
  app.post('/api/auth/load-sample-workspace', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const now = new Date().toISOString();
    const today = now.slice(0, 10);
    const folders = db.prepare('SELECT id, name FROM folders WHERE user_id = ?').all(uid) as { id: string; name: string }[];
    const workFolder = folders.find((f) => f.name === 'العمل') || folders[0];
    const bankFolder = folders.find((f) => f.name === 'البنك') || folders[0];
    const idFolder = folders.find((f) => f.name === 'الهوية') || folders[0];

    // Create sample real files on disk so document preview & PDF/XLSX/TXT viewers work immediately
    const createSampleFile = (folderId: string | undefined, title: string, ext: string, mime: string, bodyText: string) => {
      const docId = crypto.randomUUID();
      const fileName = `${docId}.${ext}`;
      const targetPath = resolveUserUploadPath(uid, fileName);
      fs.writeFileSync(targetPath, bodyText, 'utf8');
      db.prepare(
        `INSERT INTO documents (id, user_id, folder_id, name, original_name, mime_type, ext, size_bytes, storage_path, text_preview, is_favorite, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`
      ).run(docId, uid, folderId || null, title, `${title}.${ext}`, mime, ext, Buffer.byteLength(bodyText), targetPath, bodyText.slice(0, 400), now, now);
    };

    if (workFolder) {
      createSampleFile(workFolder.id, 'خطة المشاريع الربع السنوية (نموذج)', 'txt', 'text/plain', 'تقرير خطة المشاريع الربع السنوية\n1. تطوير البنية الرقمية\n2. مراجعة عقود الموردين\n3. تسليم المرحلة الأولى قبل نهاية الشهر.');
      createSampleFile(workFolder.id, 'جدول ساعات العمل (نموذج)', 'csv', 'text/csv', 'المشروع,الساعات,الحالة\nتطبيق الجوال,42,مكتمل\nمنصة الويب,36,قيد التنفيذ\nالمراجعة الأمنية,18,مجدول');
    }
    if (bankFolder) {
      createSampleFile(bankFolder.id, 'ملخص كشف الحساب البنكي (نموذج)', 'txt', 'text/plain', 'ملخص الرصيد البنكي\nالرصيد الافتتاحي: 24,500 ر.س\nإجمالي الإيداعات: 18,000 ر.س\nإجمالي المصروفات: 7,450 ر.س');
    }
    if (idFolder) {
      createSampleFile(idFolder.id, 'بيانات الجواز والهوية (نموذج)', 'txt', 'text/plain', 'سجل الوثائق الرسمية\nتاريخ التجديد القادم: 2027-08-15\nالحالة: ساري المفعول');
    }

    // Sample transactions
    const txStmt = db.prepare(
      'INSERT INTO transactions (id, user_id, type, title, amount, currency, category, date, payment_method, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    txStmt.run(crypto.randomUUID(), uid, 'income', 'الراتب الشهري (نموذج)', 18500, 'SAR', 'other', today, 'bank', 'نموذج بيانات', now);
    txStmt.run(crypto.randomUUID(), uid, 'expense', 'إيجار السكن الشهري (نموذج)', 4000, 'SAR', 'home', today, 'bank', 'نموذج بيانات', now);
    txStmt.run(crypto.randomUUID(), uid, 'expense', 'مشتريات غذائية (نموذج)', 1800, 'SAR', 'food', today, 'card', 'نموذج بيانات', now);
    txStmt.run(crypto.randomUUID(), uid, 'expense', 'وقود ومواصلات (نموذج)', 900, 'SAR', 'transport', today, 'card', 'نموذج بيانات', now);
    txStmt.run(crypto.randomUUID(), uid, 'expense', 'فواتير الكهرباء والاتصالات (نموذج)', 750, 'SAR', 'bills', today, 'card', 'نموذج بيانات', now);

    // Sample subscriptions
    const nextWeek = new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10);
    const nextMonth = new Date(Date.now() + 24 * 86400000).toISOString().slice(0, 10);
    const subStmt = db.prepare(
      'INSERT INTO subscriptions (id, user_id, service_name, logo_icon, color, price, currency, start_date, renewal_date, billing_cycle, status, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    subStmt.run(crypto.randomUUID(), uid, 'Netflix (نموذج)', 'Tv', '#E50914', 44.99, 'SAR', today, nextMonth, 'monthly', 'active', 'الباقة العائلية', now);
    subStmt.run(crypto.randomUUID(), uid, 'iCloud+ 2TB (نموذج)', 'Cloud', '#3B82F6', 39.99, 'SAR', today, nextWeek, 'monthly', 'expiring', 'تخزين سحابي', now);
    subStmt.run(crypto.randomUUID(), uid, 'Adobe Creative (نموذج)', 'Layers', '#FF0000', 79.00, 'SAR', today, nextWeek, 'monthly', 'expiring', 'تصميم', now);

    // Sample budget & goal
    db.prepare('INSERT INTO budgets (id, user_id, category, period, limit_amount, currency, alert_threshold, created_at) VALUES (?, ?, ?, ?, ?, ?, 80, ?)').run(
      crypto.randomUUID(), uid, 'home', 'monthly', 4500, 'SAR', now
    );
    db.prepare('INSERT INTO budgets (id, user_id, category, period, limit_amount, currency, alert_threshold, created_at) VALUES (?, ?, ?, ?, ?, ?, 80, ?)').run(
      crypto.randomUUID(), uid, 'food', 'monthly', 2200, 'SAR', now
    );
    db.prepare('INSERT INTO savings_goals (id, user_id, title, target_amount, current_amount, currency, deadline, icon_name, color, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(
      crypto.randomUUID(), uid, 'صندوق الطوارئ (نموذج)', 50000, 18500, 'SAR', '2027-06-01', 'ShieldCheck', '#22C55E', now
    );

    // Sample events & tasks
    db.prepare('INSERT INTO events (id, user_id, title, date, start_time, end_time, location, priority, recurrence, description, shared_with_family, reminder_minutes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 30, ?)').run(
      crypto.randomUUID(), uid, 'موعد فحص دوري (نموذج)', today, '10:30', '11:30', 'المركز الطبي', 'high', 'none', 'تذكير نموذجي', now
    );
    db.prepare('INSERT INTO tasks (id, user_id, title, category, priority, due_date, due_time, recurrence, completed, is_goal, progress, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, ?)').run(
      crypto.randomUUID(), uid, 'دفع فاتورة الكهرباء (نموذج)', 'home', 'high', today, '18:00', 'monthly', now
    );

    // Sample purchase & warranty
    db.prepare('INSERT INTO purchases (id, user_id, product_name, price, currency, store, purchase_date, order_number, status, payment_method, category, warranty_months, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(
      crypto.randomUUID(), uid, 'تلفاز ذكي 65 بوصة (نموذج)', 4299, 'SAR', 'جرير', today, 'ORD-8821', 'delivered', 'card', 'electronics', 24, 'نموذج مشتريات', now
    );
    db.prepare('INSERT INTO warranties (id, user_id, product_name, manufacturer, purchase_date, expiry_date, serial_number, service_center, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)').run(
      crypto.randomUUID(), uid, 'ثلاجة LG الذكية (نموذج)', 'LG', today, '2028-05-01', 'SN-LG-99210', 'الناغي للصيانة', 'ضمان الضاغط', now
    );

    logActivity(uid, 'تحميل مساحة عمل نموذجية', 'system');
    res.json({ ok: true });
  });

  // --- DASHBOARD OVERVIEW & TILE ORDER ---
  app.get('/api/dashboard/summary', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const cfg = db.prepare('SELECT tiles_order FROM dashboard_configs WHERE user_id = ?').get(uid) as
      | { tiles_order: string }
      | undefined;

    const monthPrefix = new Date().toISOString().slice(0, 7);
    const expensesMonth = db
      .prepare("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = ? AND type = 'expense' AND date LIKE ?")
      .get(uid, `${monthPrefix}%`) as { total: number };
    const incomeMonth = db
      .prepare("SELECT COALESCE(SUM(amount), 0) as total FROM transactions WHERE user_id = ? AND type = 'income' AND date LIKE ?")
      .get(uid, `${monthPrefix}%`) as { total: number };
    const upcomingEvents = db
      .prepare('SELECT * FROM events WHERE user_id = ? AND date >= ? ORDER BY date ASC, start_time ASC LIMIT 4')
      .all(uid, new Date().toISOString().slice(0, 10));
    const renewingSoon = db
      .prepare("SELECT * FROM subscriptions WHERE user_id = ? AND status IN ('active', 'expiring') ORDER BY renewal_date ASC LIMIT 4")
      .all(uid);
    const pendingTasks = db
      .prepare('SELECT * FROM tasks WHERE user_id = ? AND completed = 0 ORDER BY due_date ASC LIMIT 5')
      .all(uid);
    const totalTasksCount = db.prepare('SELECT COUNT(*) as c FROM tasks WHERE user_id = ?').get(uid) as { c: number };
    const completedTasksCount = db
      .prepare('SELECT COUNT(*) as c FROM tasks WHERE user_id = ? AND completed = 1')
      .get(uid) as { c: number };
    const docCount = db
      .prepare('SELECT COUNT(*) as c FROM documents WHERE user_id = ? AND is_deleted = 0')
      .get(uid) as { c: number };
    const customWidgets = db
      .prepare('SELECT * FROM custom_widgets WHERE user_id = ? ORDER BY sort_order ASC, created_at ASC')
      .all(uid);
    const unreadNotifications = db
      .prepare('SELECT COUNT(*) as c FROM notifications WHERE user_id = ? AND is_read = 0')
      .get(uid) as { c: number };

    res.json({
      tilesOrder: cfg ? JSON.parse(cfg.tiles_order) : DEFAULT_TILE_ORDER,
      expensesMonth: expensesMonth.total,
      incomeMonth: incomeMonth.total,
      upcomingEvents,
      renewingSoon,
      pendingTasks,
      tasksStats: { total: totalTasksCount.c, completed: completedTasksCount.c },
      docCount: docCount.c,
      customWidgets,
      unreadNotifications: unreadNotifications.c,
    });
  });

  app.put('/api/dashboard/order', requireAuth, (req: AuthRequest, res) => {
    const order = Array.isArray(req.body?.order) ? req.body.order : DEFAULT_TILE_ORDER;
    db.prepare('INSERT OR REPLACE INTO dashboard_configs (user_id, tiles_order) VALUES (?, ?)').run(
      req.user!.id,
      JSON.stringify(order)
    );
    res.json({ ok: true });
  });

  // --- GLOBAL SEARCH ---
  app.get('/api/search', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const q = String(req.query.q || '').trim();
    if (!q) {
      res.json({ documents: [], folders: [], transactions: [], subscriptions: [], tasks: [], contacts: [], purchases: [] });
      return;
    }
    const like = `%${q}%`;
    res.json({
      documents: db
        .prepare('SELECT id, name, ext, folder_id, updated_at FROM documents WHERE user_id = ? AND is_deleted = 0 AND (name LIKE ? OR text_preview LIKE ?) LIMIT 10')
        .all(uid, like, like),
      folders: db.prepare('SELECT id, name, color_hex FROM folders WHERE user_id = ? AND name LIKE ? LIMIT 10').all(uid, like),
      transactions: db.prepare('SELECT id, title, amount, type, date FROM transactions WHERE user_id = ? AND (title LIKE ? OR notes LIKE ?) LIMIT 10').all(uid, like, like),
      subscriptions: db.prepare('SELECT id, service_name, price, renewal_date FROM subscriptions WHERE user_id = ? AND service_name LIKE ? LIMIT 10').all(uid, like),
      tasks: db.prepare('SELECT id, title, category, completed FROM tasks WHERE user_id = ? AND title LIKE ? LIMIT 10').all(uid, like),
      contacts: db.prepare('SELECT id, name, phone, email FROM contacts WHERE user_id = ? AND (name LIKE ? OR phone LIKE ? OR email LIKE ?) LIMIT 10').all(uid, like, like, like),
      purchases: db.prepare('SELECT id, product_name, store, price FROM purchases WHERE user_id = ? AND (product_name LIKE ? OR store LIKE ?) LIMIT 10').all(uid, like, like),
    });
  });

  // --- FOLDERS ---
  app.get('/api/folders', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const folders = db
      .prepare('SELECT * FROM folders WHERE user_id = ? ORDER BY sort_order ASC, created_at ASC')
      .all(uid) as Record<string, unknown>[];
    const docs = db
      .prepare(
        'SELECT id, folder_id, name, ext, mime_type, size_bytes, text_preview, is_favorite, updated_at FROM documents WHERE user_id = ? AND is_deleted = 0 ORDER BY updated_at DESC'
      )
      .all(uid) as { folder_id: string | null; id: string; name: string; ext: string; mime_type: string; text_preview: string; updated_at: string }[];

    const enriched = folders.map((f) => {
      const folderDocs = docs.filter((d) => d.folder_id === f.id);
      return {
        ...f,
        file_count: folderDocs.length,
        preview_docs: folderDocs.slice(0, 3),
      };
    });
    res.json({ folders: enriched });
  });

  app.post('/api/folders', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const name = String(req.body?.name || '').trim();
    if (!name) {
      res.status(400).json({ error: 'اسم المجلد مطلوب' });
      return;
    }
    const id = crypto.randomUUID();
    const maxSort = db.prepare('SELECT COALESCE(MAX(sort_order), 0) as m FROM folders WHERE user_id = ?').get(uid) as { m: number };
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO folders (id, user_id, name, color_hex, opacity, icon_name, style, is_favorite, sort_order, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      uid,
      name,
      String(req.body?.color_hex || '#FF7900'),
      Number(req.body?.opacity ?? 84),
      String(req.body?.icon_name || 'Folder'),
      req.body?.style === 'classic' ? 'classic' : 'glass',
      req.body?.is_favorite ? 1 : 0,
      maxSort.m + 1,
      now
    );
    logActivity(uid, 'إنشاء مجلد', 'documents', name);
    res.status(201).json({ folder: db.prepare('SELECT * FROM folders WHERE id = ?').get(id) });
  });

  app.patch('/api/folders/reorder', requireAuth, (req: AuthRequest, res) => {
    const ids = Array.isArray(req.body?.ids) ? req.body.ids : [];
    const stmt = db.prepare('UPDATE folders SET sort_order = ? WHERE id = ? AND user_id = ?');
    ids.forEach((id: string, idx: number) => stmt.run(idx, id, req.user!.id));
    res.json({ ok: true });
  });

  app.patch('/api/folders/:id', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const existing = db.prepare('SELECT * FROM folders WHERE id = ? AND user_id = ?').get(req.params.id, uid) as Record<string, unknown> | undefined;
    if (!existing) {
      res.status(404).json({ error: 'Folder not found' });
      return;
    }
    db.prepare(
      `UPDATE folders SET name=?, color_hex=?, opacity=?, icon_name=?, style=?, is_favorite=? WHERE id=? AND user_id=?`
    ).run(
      req.body?.name !== undefined ? String(req.body.name).trim() : existing.name,
      req.body?.color_hex !== undefined ? String(req.body.color_hex) : existing.color_hex,
      req.body?.opacity !== undefined ? Number(req.body.opacity) : existing.opacity,
      req.body?.icon_name !== undefined ? String(req.body.icon_name) : existing.icon_name,
      req.body?.style !== undefined ? (req.body.style === 'classic' ? 'classic' : 'glass') : existing.style,
      req.body?.is_favorite !== undefined ? (req.body.is_favorite ? 1 : 0) : existing.is_favorite,
      req.params.id,
      uid
    );
    res.json({ folder: db.prepare('SELECT * FROM folders WHERE id = ?').get(req.params.id) });
  });

  app.post('/api/folders/:id/duplicate', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const src = db.prepare('SELECT * FROM folders WHERE id = ? AND user_id = ?').get(req.params.id, uid) as Record<string, unknown> | undefined;
    if (!src) {
      res.status(404).json({ error: 'Folder not found' });
      return;
    }
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    db.prepare(
      `INSERT INTO folders (id, user_id, name, color_hex, opacity, icon_name, style, is_favorite, sort_order, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(id, uid, `${src.name} (نسخة)`, src.color_hex, src.opacity, src.icon_name, src.style, 0, Number(src.sort_order) + 1, now);
    res.status(201).json({ folder: db.prepare('SELECT * FROM folders WHERE id = ?').get(id) });
  });

  app.delete('/api/folders/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM folders WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    logActivity(req.user!.id, 'حذف مجلد', 'documents', req.params.id);
    res.json({ ok: true });
  });

  // --- DOCUMENTS ---
  app.get('/api/documents', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const includeDeleted = req.query.trash === '1';
    const rows = db
      .prepare(
        `SELECT id, folder_id, name, original_name, mime_type, ext, size_bytes, text_preview, is_favorite, is_deleted, deleted_at, share_token, created_at, updated_at
         FROM documents WHERE user_id = ? AND is_deleted = ? ORDER BY updated_at DESC`
      )
      .all(uid, includeDeleted ? 1 : 0);
    res.json({ documents: rows });
  });

  app.post('/api/documents/upload', requireAuth, upload.array('files', 20), (req: AuthRequest, res) => {
    try {
      const uid = req.user!.id;
      const folderId = req.body?.folder_id ? String(req.body.folder_id) : null;
      const files = (req.files as Express.Multer.File[]) || [];
      if (files.length === 0) {
        res.status(400).json({ error: 'لم يتم اختيار أي ملفات' });
        return;
      }

      if (folderId) {
        const folderExists = db.prepare('SELECT id FROM folders WHERE id = ? AND user_id = ?').get(folderId, uid);
        if (!folderExists) {
          res.status(404).json({ error: 'المجلد غير موجود' });
          return;
        }
      }

      const created: unknown[] = [];
      const now = new Date().toISOString();

      for (const file of files) {
        const originalName = Buffer.from(file.originalname, 'latin1').toString('utf8');
        const ext = path.extname(originalName).replace('.', '').toLowerCase() || 'txt';
        if (!ALLOWED_EXTS.has(ext)) {
          res.status(400).json({ error: `صيغة الملف غير مدعومة: .${ext}` });
          return;
        }
        const docId = crypto.randomUUID();
        const storedName = `${docId}.${ext}`;
        const targetPath = resolveUserUploadPath(uid, storedName);
        fs.writeFileSync(targetPath, file.buffer);

        let textPreview = '';
        if (['txt', 'csv', 'json'].includes(ext)) {
          textPreview = file.buffer.toString('utf8').slice(0, 600);
        }

        const displayName = path.basename(originalName, path.extname(originalName));
        db.prepare(
          `INSERT INTO documents (id, user_id, folder_id, name, original_name, mime_type, ext, size_bytes, storage_path, text_preview, is_favorite, is_deleted, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?)`
        ).run(docId, uid, folderId, displayName, originalName, file.mimetype, ext, file.size, targetPath, textPreview, now, now);

        created.push(
          db
            .prepare(
              'SELECT id, folder_id, name, original_name, mime_type, ext, size_bytes, text_preview, is_favorite, created_at, updated_at FROM documents WHERE id = ?'
            )
            .get(docId)
        );
      }

      logActivity(uid, 'رفع مستندات', 'documents', `${files.length} ملف`);
      res.status(201).json({ documents: created });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  app.get('/api/documents/:id/raw', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const doc = db.prepare('SELECT * FROM documents WHERE id = ? AND user_id = ?').get(req.params.id, uid) as
      | { storage_path: string; mime_type: string; original_name: string }
      | undefined;
    if (!doc) {
      res.status(404).json({ error: 'File not found' });
      return;
    }
    try {
      const safePath = resolveExistingUploadPath(uid, doc.storage_path);
      if (!fs.existsSync(safePath)) {
        res.status(404).json({ error: 'File missing on disk' });
        return;
      }
      if (req.query.download === '1') {
        res.download(safePath, doc.original_name);
      } else {
        res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
        res.sendFile(safePath);
      }
    } catch {
      res.status(403).json({ error: 'Access denied' });
    }
  });

  app.patch('/api/documents/:id', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const doc = db.prepare('SELECT * FROM documents WHERE id = ? AND user_id = ?').get(req.params.id, uid) as
      | Record<string, unknown>
      | undefined;
    if (!doc) {
      res.status(404).json({ error: 'Document not found' });
      return;
    }
    const now = new Date().toISOString();
    db.prepare('UPDATE documents SET name=?, folder_id=?, is_favorite=?, updated_at=? WHERE id=? AND user_id=?').run(
      req.body?.name !== undefined ? String(req.body.name) : doc.name,
      req.body?.folder_id !== undefined ? req.body.folder_id : doc.folder_id,
      req.body?.is_favorite !== undefined ? (req.body.is_favorite ? 1 : 0) : doc.is_favorite,
      now,
      req.params.id,
      uid
    );
    res.json({ document: db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id) });
  });

  app.post('/api/documents/:id/copy', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const doc = db.prepare('SELECT * FROM documents WHERE id = ? AND user_id = ?').get(req.params.id, uid) as
      | Record<string, unknown>
      | undefined;
    if (!doc) {
      res.status(404).json({ error: 'Document not found' });
      return;
    }
    const newId = crypto.randomUUID();
    const ext = String(doc.ext);
    const destPath = resolveUserUploadPath(uid, `${newId}.${ext}`);
    const srcPath = resolveExistingUploadPath(uid, String(doc.storage_path));
    if (fs.existsSync(srcPath)) {
      fs.copyFileSync(srcPath, destPath);
    }
    const now = new Date().toISOString();
    const targetFolder = req.body?.folder_id !== undefined ? req.body.folder_id : doc.folder_id;
    db.prepare(
      `INSERT INTO documents (id, user_id, folder_id, name, original_name, mime_type, ext, size_bytes, storage_path, text_preview, is_favorite, is_deleted, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, ?, ?)`
    ).run(newId, uid, targetFolder, `${doc.name} (نسخة)`, doc.original_name, doc.mime_type, ext, doc.size_bytes, destPath, doc.text_preview, now, now);
    res.status(201).json({ document: db.prepare('SELECT * FROM documents WHERE id = ?').get(newId) });
  });

  app.post('/api/documents/:id/share', requireAuth, (req: AuthRequest, res) => {
    const token = crypto.randomBytes(16).toString('hex');
    db.prepare('UPDATE documents SET share_token = ? WHERE id = ? AND user_id = ?').run(token, req.params.id, req.user!.id);
    res.json({ shareToken: token });
  });

  app.get('/api/shared/:token', (req, res) => {
    const doc = db
      .prepare('SELECT id, user_id, name, original_name, mime_type, ext, size_bytes, storage_path FROM documents WHERE share_token = ? AND is_deleted = 0')
      .get(req.params.token) as
      | { user_id: string; storage_path: string; mime_type: string; original_name: string }
      | undefined;
    if (!doc) {
      res.status(404).json({ error: 'Shared document not found' });
      return;
    }
    const safePath = resolveExistingUploadPath(doc.user_id, doc.storage_path);
    if (!fs.existsSync(safePath)) {
      res.status(404).json({ error: 'File unavailable' });
      return;
    }
    res.setHeader('Content-Type', doc.mime_type || 'application/octet-stream');
    res.sendFile(safePath);
  });

  app.delete('/api/documents/:id', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const permanent = req.query.permanent === '1';
    const doc = db.prepare('SELECT * FROM documents WHERE id = ? AND user_id = ?').get(req.params.id, uid) as
      | { storage_path: string }
      | undefined;
    if (!doc) {
      res.status(404).json({ error: 'Document not found' });
      return;
    }
    if (permanent) {
      try {
        const safePath = resolveExistingUploadPath(uid, doc.storage_path);
        if (fs.existsSync(safePath)) fs.unlinkSync(safePath);
      } catch {
        // ignore missing disk file
      }
      db.prepare('DELETE FROM documents WHERE id = ? AND user_id = ?').run(req.params.id, uid);
    } else {
      db.prepare('UPDATE documents SET is_deleted = 1, deleted_at = ? WHERE id = ? AND user_id = ?').run(
        new Date().toISOString(),
        req.params.id,
        uid
      );
    }
    res.json({ ok: true });
  });

  app.post('/api/documents/:id/restore', requireAuth, (req: AuthRequest, res) => {
    db.prepare('UPDATE documents SET is_deleted = 0, deleted_at = NULL WHERE id = ? AND user_id = ?').run(
      req.params.id,
      req.user!.id
    );
    res.json({ ok: true });
  });

  // --- PURCHASES ---
  app.get('/api/purchases', requireAuth, (req: AuthRequest, res) => {
    const rows = db.prepare('SELECT * FROM purchases WHERE user_id = ? ORDER BY purchase_date DESC, created_at DESC').all(req.user!.id);
    res.json({ purchases: rows });
  });

  app.post('/api/purchases', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const productName = String(req.body?.product_name || '').trim();
    if (!productName) {
      res.status(400).json({ error: 'اسم المنتج مطلوب' });
      return;
    }
    db.prepare(
      `INSERT INTO purchases (id, user_id, product_name, image_url, price, currency, store, purchase_date, order_number, status, payment_method, category, warranty_months, invoice_doc_id, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      uid,
      productName,
      String(req.body?.image_url || ''),
      Number(req.body?.price || 0),
      String(req.body?.currency || 'SAR'),
      String(req.body?.store || ''),
      String(req.body?.purchase_date || now.slice(0, 10)),
      String(req.body?.order_number || ''),
      String(req.body?.status || 'delivered'),
      String(req.body?.payment_method || 'card'),
      String(req.body?.category || 'electronics'),
      Number(req.body?.warranty_months || 0),
      req.body?.invoice_doc_id || null,
      String(req.body?.notes || ''),
      now
    );
    logActivity(uid, 'إضافة عملية شراء', 'purchases', productName);
    res.status(201).json({ purchase: db.prepare('SELECT * FROM purchases WHERE id = ?').get(id) });
  });

  app.delete('/api/purchases/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM purchases WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- TRANSACTIONS (EXPENSES & INCOME) ---
  app.get('/api/transactions', requireAuth, (req: AuthRequest, res) => {
    const rows = db.prepare('SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC, created_at DESC').all(req.user!.id);
    res.json({ transactions: rows });
  });

  app.post('/api/transactions', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const type = req.body?.type === 'income' ? 'income' : 'expense';
    const title = String(req.body?.title || '').trim();
    const amount = Number(req.body?.amount || 0);
    if (!title || amount <= 0) {
      res.status(400).json({ error: 'العنوان والمبلغ الصحيح مطلوبان' });
      return;
    }
    db.prepare(
      `INSERT INTO transactions (id, user_id, type, title, amount, currency, category, date, payment_method, invoice_doc_id, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      uid,
      type,
      title,
      amount,
      String(req.body?.currency || 'SAR'),
      String(req.body?.category || 'other'),
      String(req.body?.date || now.slice(0, 10)),
      String(req.body?.payment_method || 'card'),
      req.body?.invoice_doc_id || null,
      String(req.body?.notes || ''),
      now
    );
    logActivity(uid, type === 'income' ? 'إضافة دخل' : 'إضافة مصروف', 'expenses', `${title} (${amount})`);
    res.status(201).json({ transaction: db.prepare('SELECT * FROM transactions WHERE id = ?').get(id) });
  });

  app.patch('/api/transactions/:id', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const row = db.prepare('SELECT * FROM transactions WHERE id = ? AND user_id = ?').get(req.params.id, uid) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db.prepare(
      'UPDATE transactions SET type=?, title=?, amount=?, category=?, date=?, payment_method=?, notes=? WHERE id=? AND user_id=?'
    ).run(
      req.body?.type === 'income' ? 'income' : req.body?.type === 'expense' ? 'expense' : row.type,
      req.body?.title !== undefined ? String(req.body.title) : row.title,
      req.body?.amount !== undefined ? Number(req.body.amount) : row.amount,
      req.body?.category !== undefined ? String(req.body.category) : row.category,
      req.body?.date !== undefined ? String(req.body.date) : row.date,
      req.body?.payment_method !== undefined ? String(req.body.payment_method) : row.payment_method,
      req.body?.notes !== undefined ? String(req.body.notes) : row.notes,
      req.params.id,
      uid
    );
    res.json({ transaction: db.prepare('SELECT * FROM transactions WHERE id = ?').get(req.params.id) });
  });

  app.delete('/api/transactions/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM transactions WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- SUBSCRIPTIONS ---
  app.get('/api/subscriptions', requireAuth, (req: AuthRequest, res) => {
    const rows = db.prepare('SELECT * FROM subscriptions WHERE user_id = ? ORDER BY renewal_date ASC').all(req.user!.id);
    res.json({ subscriptions: rows });
  });

  app.post('/api/subscriptions', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const serviceName = String(req.body?.service_name || '').trim();
    if (!serviceName) {
      res.status(400).json({ error: 'اسم الخدمة مطلوب' });
      return;
    }
    db.prepare(
      `INSERT INTO subscriptions (id, user_id, service_name, logo_icon, color, price, currency, start_date, renewal_date, billing_cycle, status, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      uid,
      serviceName,
      String(req.body?.logo_icon || 'Repeat'),
      String(req.body?.color || '#FF7900'),
      Number(req.body?.price || 0),
      String(req.body?.currency || 'SAR'),
      String(req.body?.start_date || now.slice(0, 10)),
      String(req.body?.renewal_date || now.slice(0, 10)),
      String(req.body?.billing_cycle || 'monthly'),
      String(req.body?.status || 'active'),
      String(req.body?.notes || ''),
      now
    );
    logActivity(uid, 'إضافة اشتراك', 'subscriptions', serviceName);
    res.status(201).json({ subscription: db.prepare('SELECT * FROM subscriptions WHERE id = ?').get(id) });
  });

  app.patch('/api/subscriptions/:id', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const row = db.prepare('SELECT * FROM subscriptions WHERE id = ? AND user_id = ?').get(req.params.id, uid) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db.prepare(
      'UPDATE subscriptions SET status=?, price=?, renewal_date=?, billing_cycle=?, notes=? WHERE id=? AND user_id=?'
    ).run(
      req.body?.status ?? row.status,
      req.body?.price !== undefined ? Number(req.body.price) : row.price,
      req.body?.renewal_date ?? row.renewal_date,
      req.body?.billing_cycle ?? row.billing_cycle,
      req.body?.notes ?? row.notes,
      req.params.id,
      uid
    );
    res.json({ subscription: db.prepare('SELECT * FROM subscriptions WHERE id = ?').get(req.params.id) });
  });

  app.delete('/api/subscriptions/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM subscriptions WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- EVENTS / CALENDAR ---
  app.get('/api/events', requireAuth, (req: AuthRequest, res) => {
    const rows = db.prepare('SELECT * FROM events WHERE user_id = ? ORDER BY date ASC, start_time ASC').all(req.user!.id);
    res.json({ events: rows });
  });

  app.post('/api/events', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const title = String(req.body?.title || '').trim();
    if (!title) {
      res.status(400).json({ error: 'عنوان الموعد مطلوب' });
      return;
    }
    db.prepare(
      `INSERT INTO events (id, user_id, title, date, start_time, end_time, location, priority, recurrence, description, shared_with_family, reminder_minutes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      uid,
      title,
      String(req.body?.date || now.slice(0, 10)),
      String(req.body?.start_time || '09:00'),
      String(req.body?.end_time || '10:00'),
      String(req.body?.location || ''),
      String(req.body?.priority || 'medium'),
      String(req.body?.recurrence || 'none'),
      String(req.body?.description || ''),
      req.body?.shared_with_family ? 1 : 0,
      Number(req.body?.reminder_minutes ?? 30),
      now
    );
    logActivity(uid, 'إضافة موعد', 'calendar', title);
    res.status(201).json({ event: db.prepare('SELECT * FROM events WHERE id = ?').get(id) });
  });

  app.patch('/api/events/:id', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const row = db.prepare('SELECT * FROM events WHERE id = ? AND user_id = ?').get(req.params.id, uid) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db.prepare(
      'UPDATE events SET title=?, date=?, start_time=?, end_time=?, location=?, priority=?, recurrence=?, description=?, shared_with_family=? WHERE id=? AND user_id=?'
    ).run(
      req.body?.title ?? row.title,
      req.body?.date ?? row.date,
      req.body?.start_time ?? row.start_time,
      req.body?.end_time ?? row.end_time,
      req.body?.location ?? row.location,
      req.body?.priority ?? row.priority,
      req.body?.recurrence ?? row.recurrence,
      req.body?.description ?? row.description,
      req.body?.shared_with_family !== undefined ? (req.body.shared_with_family ? 1 : 0) : row.shared_with_family,
      req.params.id,
      uid
    );
    res.json({ event: db.prepare('SELECT * FROM events WHERE id = ?').get(req.params.id) });
  });

  app.delete('/api/events/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM events WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- FAMILY (RBAC + ISOLATION) ---
  app.get('/api/family', requireAuth, (req: AuthRequest, res) => {
    const membership = getFamilyMembership(req.user!.id);
    if (!membership) {
      res.json({ family: null, members: [], items: [], currentMember: null });
      return;
    }
    const members = db.prepare('SELECT * FROM family_members WHERE family_id = ? ORDER BY created_at ASC').all(membership.family_id);
    const items = db.prepare('SELECT * FROM family_items WHERE family_id = ? ORDER BY created_at DESC').all(membership.family_id);
    const perms = JSON.parse(membership.permissions || '{}');
    const filteredItems = (items as Record<string, unknown>[]).filter((it) => {
      if ((it.item_type === 'expense' || it.item_type === 'bill' || it.item_type === 'budget') && !perms.view_budget && membership.role !== 'owner') {
        return false;
      }
      return true;
    });
    res.json({
      family: {
        id: membership.family_id,
        name: membership.family_name,
        invite_code: membership.invite_code,
        owner_id: membership.owner_id,
      },
      members,
      items: filteredItems,
      currentMember: membership,
    });
  });

  app.post('/api/family/create', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    if (getFamilyMembership(uid)) {
      res.status(400).json({ error: 'أنت منضم لمجموعة عائلية بالفعل' });
      return;
    }
    const familyName = String(req.body?.name || '').trim() || 'عائلتي';
    const famId = crypto.randomUUID();
    const inviteCode = `FAM-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
    const now = new Date().toISOString();
    db.prepare('INSERT INTO families (id, name, owner_id, invite_code, created_at) VALUES (?, ?, ?, ?, ?)').run(
      famId,
      familyName,
      uid,
      inviteCode,
      now
    );
    db.prepare(
      `INSERT INTO family_members (id, family_id, user_id, display_name, relation, role, avatar_color, permissions, created_at)
       VALUES (?, ?, ?, ?, 'owner', 'owner', '#FF7900', ?, ?)`
    ).run(
      crypto.randomUUID(),
      famId,
      uid,
      req.user!.name,
      JSON.stringify({ view_budget: true, add_expenses: true, view_calendar: true, manage_tasks: true }),
      now
    );
    logActivity(uid, 'إنشاء مجموعة عائلية', 'family', familyName);
    res.status(201).json({ ok: true, inviteCode });
  });

  app.post('/api/family/join', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const code = String(req.body?.invite_code || '').trim().toUpperCase();
    const fam = db.prepare('SELECT * FROM families WHERE invite_code = ?').get(code) as { id: string; name: string } | undefined;
    if (!fam) {
      res.status(404).json({ error: 'رمز الدعوة غير صالح' });
      return;
    }
    if (getFamilyMembership(uid)) {
      res.status(400).json({ error: 'أنت منضم لمجموعة عائلية بالفعل' });
      return;
    }
    db.prepare(
      `INSERT INTO family_members (id, family_id, user_id, display_name, relation, role, avatar_color, permissions, created_at)
       VALUES (?, ?, ?, ?, ?, 'member', '#3B82F6', ?, ?)`
    ).run(
      crypto.randomUUID(),
      fam.id,
      uid,
      req.user!.name,
      String(req.body?.relation || 'member'),
      JSON.stringify({ view_budget: true, add_expenses: true, view_calendar: true, manage_tasks: true }),
      new Date().toISOString()
    );
    res.json({ ok: true });
  });

  app.post('/api/family/members', requireAuth, (req: AuthRequest, res) => {
    const membership = getFamilyMembership(req.user!.id);
    if (!membership || !['owner', 'admin'].includes(membership.role)) {
      res.status(403).json({ error: 'صلاحية غير كافية لإضافة أفراد' });
      return;
    }
    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO family_members (id, family_id, user_id, display_name, relation, role, avatar_color, permissions, created_at)
       VALUES (?, ?, NULL, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      membership.family_id,
      String(req.body?.display_name || '').trim(),
      String(req.body?.relation || 'member'),
      String(req.body?.role || 'member'),
      String(req.body?.avatar_color || '#8B5CF6'),
      JSON.stringify(req.body?.permissions || { view_budget: true, add_expenses: true, view_calendar: true, manage_tasks: true }),
      new Date().toISOString()
    );
    res.status(201).json({ member: db.prepare('SELECT * FROM family_members WHERE id = ?').get(id) });
  });

  app.patch('/api/family/members/:id', requireAuth, (req: AuthRequest, res) => {
    const membership = getFamilyMembership(req.user!.id);
    if (!membership || !['owner', 'admin'].includes(membership.role)) {
      res.status(403).json({ error: 'صلاحية غير كافية' });
      return;
    }
    db.prepare('UPDATE family_members SET role=?, permissions=? WHERE id=? AND family_id=?').run(
      String(req.body?.role || 'member'),
      JSON.stringify(req.body?.permissions || {}),
      req.params.id,
      membership.family_id
    );
    res.json({ ok: true });
  });

  app.post('/api/family/items', requireAuth, (req: AuthRequest, res) => {
    const membership = getFamilyMembership(req.user!.id);
    if (!membership) {
      res.status(403).json({ error: 'يجب الانضمام لمجموعة عائلية أولاً' });
      return;
    }
    const perms = JSON.parse(membership.permissions || '{}');
    const itemType = String(req.body?.item_type || 'task');
    if ((itemType === 'expense' || itemType === 'bill') && !perms.add_expenses && membership.role !== 'owner') {
      res.status(403).json({ error: 'ليست لديك صلاحية إضافة مصروفات عائلية' });
      return;
    }
    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO family_items (id, family_id, author_user_id, item_type, title, amount, target_amount, due_date, assigned_to, status, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      membership.family_id,
      req.user!.id,
      itemType,
      String(req.body?.title || '').trim(),
      Number(req.body?.amount || 0),
      Number(req.body?.target_amount || 0),
      String(req.body?.due_date || ''),
      String(req.body?.assigned_to || ''),
      String(req.body?.status || 'pending'),
      String(req.body?.notes || ''),
      new Date().toISOString()
    );
    res.status(201).json({ item: db.prepare('SELECT * FROM family_items WHERE id = ?').get(id) });
  });

  app.patch('/api/family/items/:id', requireAuth, (req: AuthRequest, res) => {
    const membership = getFamilyMembership(req.user!.id);
    if (!membership) {
      res.status(403).json({ error: 'غير مصرح' });
      return;
    }
    db.prepare('UPDATE family_items SET status=?, amount=? WHERE id=? AND family_id=?').run(
      String(req.body?.status || 'completed'),
      Number(req.body?.amount || 0),
      req.params.id,
      membership.family_id
    );
    res.json({ ok: true });
  });

  app.delete('/api/family/items/:id', requireAuth, (req: AuthRequest, res) => {
    const membership = getFamilyMembership(req.user!.id);
    if (!membership) {
      res.status(403).json({ error: 'غير مصرح' });
      return;
    }
    db.prepare('DELETE FROM family_items WHERE id = ? AND family_id = ?').run(req.params.id, membership.family_id);
    res.json({ ok: true });
  });

  // --- BUDGETS & SAVINGS ---
  app.get('/api/budgets', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    res.json({
      budgets: db.prepare('SELECT * FROM budgets WHERE user_id = ? ORDER BY created_at DESC').all(uid),
      savings: db.prepare('SELECT * FROM savings_goals WHERE user_id = ? ORDER BY created_at DESC').all(uid),
    });
  });

  app.post('/api/budgets', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      'INSERT INTO budgets (id, user_id, category, period, limit_amount, currency, alert_threshold, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      id,
      req.user!.id,
      String(req.body?.category || 'other'),
      req.body?.period === 'yearly' ? 'yearly' : 'monthly',
      Number(req.body?.limit_amount || 0),
      String(req.body?.currency || 'SAR'),
      Number(req.body?.alert_threshold || 80),
      new Date().toISOString()
    );
    res.status(201).json({ budget: db.prepare('SELECT * FROM budgets WHERE id = ?').get(id) });
  });

  app.delete('/api/budgets/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM budgets WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  app.post('/api/savings', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      'INSERT INTO savings_goals (id, user_id, title, target_amount, current_amount, currency, deadline, icon_name, color, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      id,
      req.user!.id,
      String(req.body?.title || '').trim(),
      Number(req.body?.target_amount || 0),
      Number(req.body?.current_amount || 0),
      String(req.body?.currency || 'SAR'),
      String(req.body?.deadline || ''),
      String(req.body?.icon_name || 'PiggyBank'),
      String(req.body?.color || '#22C55E'),
      new Date().toISOString()
    );
    res.status(201).json({ goal: db.prepare('SELECT * FROM savings_goals WHERE id = ?').get(id) });
  });

  app.patch('/api/savings/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('UPDATE savings_goals SET current_amount = ? WHERE id = ? AND user_id = ?').run(
      Number(req.body?.current_amount || 0),
      req.params.id,
      req.user!.id
    );
    res.json({ ok: true });
  });

  app.delete('/api/savings/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM savings_goals WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- WARRANTIES & MAINTENANCE ---
  app.get('/api/warranties', requireAuth, (req: AuthRequest, res) => {
    res.json({ warranties: db.prepare('SELECT * FROM warranties WHERE user_id = ? ORDER BY expiry_date ASC').all(req.user!.id) });
  });

  app.post('/api/warranties', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO warranties (id, user_id, product_name, manufacturer, purchase_date, expiry_date, serial_number, service_center, invoice_doc_id, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      req.user!.id,
      String(req.body?.product_name || '').trim(),
      String(req.body?.manufacturer || ''),
      String(req.body?.purchase_date || new Date().toISOString().slice(0, 10)),
      String(req.body?.expiry_date || new Date().toISOString().slice(0, 10)),
      String(req.body?.serial_number || ''),
      String(req.body?.service_center || ''),
      req.body?.invoice_doc_id || null,
      String(req.body?.notes || ''),
      new Date().toISOString()
    );
    res.status(201).json({ warranty: db.prepare('SELECT * FROM warranties WHERE id = ?').get(id) });
  });

  app.delete('/api/warranties/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM warranties WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  app.get('/api/maintenance', requireAuth, (req: AuthRequest, res) => {
    res.json({ logs: db.prepare('SELECT * FROM maintenance_logs WHERE user_id = ? ORDER BY scheduled_date DESC').all(req.user!.id) });
  });

  app.post('/api/maintenance', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      'INSERT INTO maintenance_logs (id, user_id, category, title, service_center, scheduled_date, cost, status, notes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      id,
      req.user!.id,
      String(req.body?.category || 'home'),
      String(req.body?.title || '').trim(),
      String(req.body?.service_center || ''),
      String(req.body?.scheduled_date || new Date().toISOString().slice(0, 10)),
      Number(req.body?.cost || 0),
      String(req.body?.status || 'scheduled'),
      String(req.body?.notes || ''),
      new Date().toISOString()
    );
    res.status(201).json({ log: db.prepare('SELECT * FROM maintenance_logs WHERE id = ?').get(id) });
  });

  app.patch('/api/maintenance/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('UPDATE maintenance_logs SET status = ?, cost = ? WHERE id = ? AND user_id = ?').run(
      String(req.body?.status || 'completed'),
      Number(req.body?.cost || 0),
      req.params.id,
      req.user!.id
    );
    res.json({ ok: true });
  });

  app.delete('/api/maintenance/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM maintenance_logs WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- PROPERTIES ---
  app.get('/api/properties', requireAuth, (req: AuthRequest, res) => {
    res.json({ properties: db.prepare('SELECT * FROM properties WHERE user_id = ? ORDER BY created_at DESC').all(req.user!.id) });
  });

  app.post('/api/properties', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO properties (id, user_id, name, address, image_url, value, lease_start, lease_end, monthly_rent, expenses_total, revenue_total, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      req.user!.id,
      String(req.body?.name || '').trim(),
      String(req.body?.address || '').trim(),
      String(req.body?.image_url || ''),
      Number(req.body?.value || 0),
      String(req.body?.lease_start || ''),
      String(req.body?.lease_end || ''),
      Number(req.body?.monthly_rent || 0),
      Number(req.body?.expenses_total || 0),
      Number(req.body?.revenue_total || 0),
      String(req.body?.notes || ''),
      new Date().toISOString()
    );
    res.status(201).json({ property: db.prepare('SELECT * FROM properties WHERE id = ?').get(id) });
  });

  app.delete('/api/properties/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM properties WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- TRIPS ---
  app.get('/api/trips', requireAuth, (req: AuthRequest, res) => {
    res.json({ trips: db.prepare('SELECT * FROM trips WHERE user_id = ? ORDER BY departure_date ASC').all(req.user!.id) });
  });

  app.post('/api/trips', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO trips (id, user_id, destination, departure_date, return_date, flight_info, hotel_info, budget, spent, checklist_json, notes, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      id,
      req.user!.id,
      String(req.body?.destination || '').trim(),
      String(req.body?.departure_date || new Date().toISOString().slice(0, 10)),
      String(req.body?.return_date || new Date().toISOString().slice(0, 10)),
      String(req.body?.flight_info || ''),
      String(req.body?.hotel_info || ''),
      Number(req.body?.budget || 0),
      Number(req.body?.spent || 0),
      JSON.stringify(req.body?.checklist || [{ id: crypto.randomUUID(), text: 'جواز السفر والتأشيرة', done: false }]),
      String(req.body?.notes || ''),
      new Date().toISOString()
    );
    res.status(201).json({ trip: db.prepare('SELECT * FROM trips WHERE id = ?').get(id) });
  });

  app.patch('/api/trips/:id', requireAuth, (req: AuthRequest, res) => {
    const row = db.prepare('SELECT * FROM trips WHERE id = ? AND user_id = ?').get(req.params.id, req.user!.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db.prepare('UPDATE trips SET spent=?, checklist_json=? WHERE id=? AND user_id=?').run(
      req.body?.spent !== undefined ? Number(req.body.spent) : row.spent,
      req.body?.checklist !== undefined ? JSON.stringify(req.body.checklist) : row.checklist_json,
      req.params.id,
      req.user!.id
    );
    res.json({ trip: db.prepare('SELECT * FROM trips WHERE id = ?').get(req.params.id) });
  });

  app.delete('/api/trips/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM trips WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- TASKS & GOALS ---
  app.get('/api/tasks', requireAuth, (req: AuthRequest, res) => {
    res.json({ tasks: db.prepare('SELECT * FROM tasks WHERE user_id = ? ORDER BY completed ASC, due_date ASC, created_at DESC').all(req.user!.id) });
  });

  app.post('/api/tasks', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      `INSERT INTO tasks (id, user_id, title, category, priority, due_date, due_time, recurrence, completed, is_goal, progress, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?, ?)`
    ).run(
      id,
      req.user!.id,
      String(req.body?.title || '').trim(),
      String(req.body?.category || 'daily'),
      String(req.body?.priority || 'medium'),
      String(req.body?.due_date || ''),
      String(req.body?.due_time || ''),
      String(req.body?.recurrence || 'none'),
      req.body?.is_goal ? 1 : 0,
      Number(req.body?.progress || 0),
      new Date().toISOString()
    );
    res.status(201).json({ task: db.prepare('SELECT * FROM tasks WHERE id = ?').get(id) });
  });

  app.patch('/api/tasks/:id', requireAuth, (req: AuthRequest, res) => {
    const row = db.prepare('SELECT * FROM tasks WHERE id = ? AND user_id = ?').get(req.params.id, req.user!.id) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db.prepare('UPDATE tasks SET completed=?, progress=?, title=?, priority=? WHERE id=? AND user_id=?').run(
      req.body?.completed !== undefined ? (req.body.completed ? 1 : 0) : row.completed,
      req.body?.progress !== undefined ? Number(req.body.progress) : row.progress,
      req.body?.title !== undefined ? String(req.body.title) : row.title,
      req.body?.priority !== undefined ? String(req.body.priority) : row.priority,
      req.params.id,
      req.user!.id
    );
    res.json({ task: db.prepare('SELECT * FROM tasks WHERE id = ?').get(req.params.id) });
  });

  app.delete('/api/tasks/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM tasks WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- CONTACTS ---
  app.get('/api/contacts', requireAuth, (req: AuthRequest, res) => {
    res.json({ contacts: db.prepare('SELECT * FROM contacts WHERE user_id = ? ORDER BY is_favorite DESC, name ASC').all(req.user!.id) });
  });

  app.post('/api/contacts', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      'INSERT INTO contacts (id, user_id, name, phone, email, relationship, company, notes, is_favorite, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      id,
      req.user!.id,
      String(req.body?.name || '').trim(),
      String(req.body?.phone || ''),
      String(req.body?.email || ''),
      String(req.body?.relationship || ''),
      String(req.body?.company || ''),
      String(req.body?.notes || ''),
      req.body?.is_favorite ? 1 : 0,
      new Date().toISOString()
    );
    res.status(201).json({ contact: db.prepare('SELECT * FROM contacts WHERE id = ?').get(id) });
  });

  app.patch('/api/contacts/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('UPDATE contacts SET is_favorite = ? WHERE id = ? AND user_id = ?').run(
      req.body?.is_favorite ? 1 : 0,
      req.params.id,
      req.user!.id
    );
    res.json({ ok: true });
  });

  app.delete('/api/contacts/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM contacts WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- VAULT (المحفوظات) ---
  app.get('/api/vault', requireAuth, (req: AuthRequest, res) => {
    res.json({ items: db.prepare('SELECT * FROM vault_items WHERE user_id = ? ORDER BY created_at DESC').all(req.user!.id) });
  });

  app.post('/api/vault', requireAuth, (req: AuthRequest, res) => {
    const id = crypto.randomUUID();
    db.prepare(
      'INSERT INTO vault_items (id, user_id, type, title, content, url, doc_id, is_favorite, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      id,
      req.user!.id,
      String(req.body?.type || 'note'),
      String(req.body?.title || '').trim(),
      String(req.body?.content || ''),
      String(req.body?.url || ''),
      req.body?.doc_id || null,
      req.body?.is_favorite ? 1 : 0,
      new Date().toISOString()
    );
    res.status(201).json({ item: db.prepare('SELECT * FROM vault_items WHERE id = ?').get(id) });
  });

  app.patch('/api/vault/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('UPDATE vault_items SET is_favorite = ? WHERE id = ? AND user_id = ?').run(
      req.body?.is_favorite ? 1 : 0,
      req.params.id,
      req.user!.id
    );
    res.json({ ok: true });
  });

  app.delete('/api/vault/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM vault_items WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- CUSTOM WIDGETS & ICON PREFS ---
  app.get('/api/widgets', requireAuth, (req: AuthRequest, res) => {
    res.json({ widgets: db.prepare('SELECT * FROM custom_widgets WHERE user_id = ? ORDER BY sort_order ASC, created_at ASC').all(req.user!.id) });
  });

  app.post('/api/widgets', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const id = crypto.randomUUID();
    const maxSort = db.prepare('SELECT COALESCE(MAX(sort_order), 0) as m FROM custom_widgets WHERE user_id = ?').get(uid) as { m: number };
    db.prepare(
      `INSERT INTO custom_widgets (id, user_id, name, icon_name, icon_color, bg_color, style, opacity, widget_type, config_json, data_json, is_favorite, sort_order, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)`
    ).run(
      id,
      uid,
      String(req.body?.name || '').trim(),
      String(req.body?.icon_name || 'Sparkles'),
      String(req.body?.icon_color || '#FF7900'),
      String(req.body?.bg_color || '#151515'),
      req.body?.style === 'classic' ? 'classic' : 'glass',
      Number(req.body?.opacity ?? 82),
      String(req.body?.widget_type || 'checklist'),
      JSON.stringify(req.body?.config || {}),
      JSON.stringify(req.body?.data || { count: 0, items: [], note: '' }),
      maxSort.m + 1,
      new Date().toISOString()
    );
    logActivity(uid, 'إنشاء أداة مخصصة', 'tools', String(req.body?.name || ''));
    res.status(201).json({ widget: db.prepare('SELECT * FROM custom_widgets WHERE id = ?').get(id) });
  });

  app.patch('/api/widgets/:id', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const row = db.prepare('SELECT * FROM custom_widgets WHERE id = ? AND user_id = ?').get(req.params.id, uid) as Record<string, unknown> | undefined;
    if (!row) {
      res.status(404).json({ error: 'Not found' });
      return;
    }
    db.prepare(
      'UPDATE custom_widgets SET name=?, icon_name=?, icon_color=?, bg_color=?, style=?, opacity=?, widget_type=?, data_json=?, is_favorite=? WHERE id=? AND user_id=?'
    ).run(
      req.body?.name ?? row.name,
      req.body?.icon_name ?? row.icon_name,
      req.body?.icon_color ?? row.icon_color,
      req.body?.bg_color ?? row.bg_color,
      req.body?.style ?? row.style,
      req.body?.opacity !== undefined ? Number(req.body.opacity) : row.opacity,
      req.body?.widget_type ?? row.widget_type,
      req.body?.data !== undefined ? JSON.stringify(req.body.data) : row.data_json,
      req.body?.is_favorite !== undefined ? (req.body.is_favorite ? 1 : 0) : row.is_favorite,
      req.params.id,
      uid
    );
    res.json({ widget: db.prepare('SELECT * FROM custom_widgets WHERE id = ?').get(req.params.id) });
  });

  app.delete('/api/widgets/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM custom_widgets WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  app.get('/api/icons/prefs', requireAuth, (req: AuthRequest, res) => {
    const row = db.prepare('SELECT favorites_json, recent_json FROM icon_prefs WHERE user_id = ?').get(req.user!.id) as
      | { favorites_json: string; recent_json: string }
      | undefined;
    res.json({
      favorites: row ? JSON.parse(row.favorites_json) : [],
      recent: row ? JSON.parse(row.recent_json) : [],
    });
  });

  app.put('/api/icons/prefs', requireAuth, (req: AuthRequest, res) => {
    const favorites = Array.isArray(req.body?.favorites) ? req.body.favorites.slice(0, 100) : [];
    const recent = Array.isArray(req.body?.recent) ? req.body.recent.slice(0, 30) : [];
    db.prepare('INSERT OR REPLACE INTO icon_prefs (user_id, favorites_json, recent_json) VALUES (?, ?, ?)').run(
      req.user!.id,
      JSON.stringify(favorites),
      JSON.stringify(recent)
    );
    res.json({ ok: true });
  });

  // --- BACKUPS (ENCRYPTED AES-256-GCM) ---
  app.get('/api/backups', requireAuth, (req: AuthRequest, res) => {
    res.json({
      backups: db
        .prepare('SELECT id, label, encrypted, size_bytes, created_at FROM backups WHERE user_id = ? ORDER BY created_at DESC')
        .all(req.user!.id),
    });
  });

  app.post('/api/backups/create', requireAuth, (req: AuthRequest, res) => {
    const uid = req.user!.id;
    const label = String(req.body?.label || `نسخة احتياطية ${new Date().toLocaleDateString('ar-SA')}`);
    const passphrase = typeof req.body?.passphrase === 'string' ? req.body.passphrase : '';
    const encrypted = req.body?.encrypted !== false;

    const snapshot = {
      version: 1,
      createdAt: new Date().toISOString(),
      folders: db.prepare('SELECT * FROM folders WHERE user_id = ?').all(uid),
      purchases: db.prepare('SELECT * FROM purchases WHERE user_id = ?').all(uid),
      transactions: db.prepare('SELECT * FROM transactions WHERE user_id = ?').all(uid),
      subscriptions: db.prepare('SELECT * FROM subscriptions WHERE user_id = ?').all(uid),
      events: db.prepare('SELECT * FROM events WHERE user_id = ?').all(uid),
      budgets: db.prepare('SELECT * FROM budgets WHERE user_id = ?').all(uid),
      savings_goals: db.prepare('SELECT * FROM savings_goals WHERE user_id = ?').all(uid),
      warranties: db.prepare('SELECT * FROM warranties WHERE user_id = ?').all(uid),
      maintenance_logs: db.prepare('SELECT * FROM maintenance_logs WHERE user_id = ?').all(uid),
      properties: db.prepare('SELECT * FROM properties WHERE user_id = ?').all(uid),
      trips: db.prepare('SELECT * FROM trips WHERE user_id = ?').all(uid),
      tasks: db.prepare('SELECT * FROM tasks WHERE user_id = ?').all(uid),
      contacts: db.prepare('SELECT * FROM contacts WHERE user_id = ?').all(uid),
      vault_items: db.prepare('SELECT * FROM vault_items WHERE user_id = ?').all(uid),
      custom_widgets: db.prepare('SELECT * FROM custom_widgets WHERE user_id = ?').all(uid),
    };

    const rawJson = JSON.stringify(snapshot);
    const payload = encrypted ? encryptBackupData(rawJson, passphrase) : rawJson;
    const id = crypto.randomUUID();
    const size = Buffer.byteLength(payload, 'utf8');
    db.prepare('INSERT INTO backups (id, user_id, label, encrypted, size_bytes, payload, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)').run(
      id,
      uid,
      label,
      encrypted ? 1 : 0,
      size,
      payload,
      new Date().toISOString()
    );
    logActivity(uid, 'إنشاء نسخة احتياطية', 'backup', label);
    res.status(201).json({
      backup: { id, label, encrypted: encrypted ? 1 : 0, size_bytes: size, created_at: new Date().toISOString() },
    });
  });

  app.get('/api/backups/:id/download', requireAuth, (req: AuthRequest, res) => {
    const row = db.prepare('SELECT label, payload FROM backups WHERE id = ? AND user_id = ?').get(req.params.id, req.user!.id) as
      | { label: string; payload: string }
      | undefined;
    if (!row) {
      res.status(404).json({ error: 'Backup not found' });
      return;
    }
    res.setHeader('Content-Disposition', `attachment; filename="mylife-backup-${req.params.id.slice(0, 8)}.mylife.json"`);
    res.setHeader('Content-Type', 'application/json');
    res.send(row.payload);
  });

  app.post('/api/backups/restore', requireAuth, (req: AuthRequest, res) => {
    try {
      const uid = req.user!.id;
      const passphrase = typeof req.body?.passphrase === 'string' ? req.body.passphrase : '';
      let rawPayload = '';

      if (req.body?.backupId) {
        const row = db.prepare('SELECT payload, encrypted FROM backups WHERE id = ? AND user_id = ?').get(String(req.body.backupId), uid) as
          | { payload: string; encrypted: number }
          | undefined;
        if (!row) {
          res.status(404).json({ error: 'النسخة غير موجودة' });
          return;
        }
        rawPayload = row.encrypted ? decryptBackupData(row.payload, passphrase) : row.payload;
      } else if (req.body?.payload) {
        const incoming = String(req.body.payload);
        const parsed = JSON.parse(incoming);
        rawPayload = parsed.alg === 'aes-256-gcm' ? decryptBackupData(incoming, passphrase) : incoming;
      } else {
        res.status(400).json({ error: 'بيانات النسخة مطلوبة' });
        return;
      }

      const snap = JSON.parse(rawPayload);
      const tx = db.transaction(() => {
        const restoreList = (table: string, cols: string[], rows: Record<string, unknown>[]) => {
          if (!Array.isArray(rows)) return;
          db.prepare(`DELETE FROM ${table} WHERE user_id = ?`).run(uid);
          const placeholders = cols.map(() => '?').join(',');
          const stmt = db.prepare(`INSERT OR IGNORE INTO ${table} (${cols.join(',')}) VALUES (${placeholders})`);
          for (const r of rows) {
            stmt.run(...cols.map((c) => (c === 'user_id' ? uid : r[c] ?? null)));
          }
        };
        restoreList('folders', ['id', 'user_id', 'name', 'color_hex', 'opacity', 'icon_name', 'style', 'is_favorite', 'sort_order', 'created_at'], snap.folders);
        restoreList('purchases', ['id', 'user_id', 'product_name', 'image_url', 'price', 'currency', 'store', 'purchase_date', 'order_number', 'status', 'payment_method', 'category', 'warranty_months', 'invoice_doc_id', 'notes', 'created_at'], snap.purchases);
        restoreList('transactions', ['id', 'user_id', 'type', 'title', 'amount', 'currency', 'category', 'date', 'payment_method', 'invoice_doc_id', 'notes', 'created_at'], snap.transactions);
        restoreList('subscriptions', ['id', 'user_id', 'service_name', 'logo_icon', 'color', 'price', 'currency', 'start_date', 'renewal_date', 'billing_cycle', 'status', 'notes', 'created_at'], snap.subscriptions);
        restoreList('events', ['id', 'user_id', 'title', 'date', 'start_time', 'end_time', 'location', 'priority', 'recurrence', 'description', 'shared_with_family', 'reminder_minutes', 'created_at'], snap.events);
        restoreList('budgets', ['id', 'user_id', 'category', 'period', 'limit_amount', 'currency', 'alert_threshold', 'created_at'], snap.budgets);
        restoreList('savings_goals', ['id', 'user_id', 'title', 'target_amount', 'current_amount', 'currency', 'deadline', 'icon_name', 'color', 'created_at'], snap.savings_goals);
        restoreList('warranties', ['id', 'user_id', 'product_name', 'manufacturer', 'purchase_date', 'expiry_date', 'serial_number', 'service_center', 'invoice_doc_id', 'notes', 'created_at'], snap.warranties);
        restoreList('maintenance_logs', ['id', 'user_id', 'category', 'title', 'service_center', 'scheduled_date', 'cost', 'status', 'notes', 'created_at'], snap.maintenance_logs);
        restoreList('properties', ['id', 'user_id', 'name', 'address', 'image_url', 'value', 'lease_start', 'lease_end', 'monthly_rent', 'expenses_total', 'revenue_total', 'notes', 'created_at'], snap.properties);
        restoreList('trips', ['id', 'user_id', 'destination', 'departure_date', 'return_date', 'flight_info', 'hotel_info', 'budget', 'spent', 'checklist_json', 'notes', 'created_at'], snap.trips);
        restoreList('tasks', ['id', 'user_id', 'title', 'category', 'priority', 'due_date', 'due_time', 'recurrence', 'completed', 'is_goal', 'progress', 'created_at'], snap.tasks);
        restoreList('contacts', ['id', 'user_id', 'name', 'phone', 'email', 'relationship', 'company', 'notes', 'is_favorite', 'created_at'], snap.contacts);
        restoreList('vault_items', ['id', 'user_id', 'type', 'title', 'content', 'url', 'doc_id', 'is_favorite', 'created_at'], snap.vault_items);
        restoreList('custom_widgets', ['id', 'user_id', 'name', 'icon_name', 'icon_color', 'bg_color', 'style', 'opacity', 'widget_type', 'config_json', 'data_json', 'is_favorite', 'sort_order', 'created_at'], snap.custom_widgets);
      });
      tx();
      logActivity(uid, 'استعادة نسخة احتياطية', 'backup');
      res.json({ ok: true });
    } catch {
      res.status(400).json({ error: 'فشل فك التشفير أو قراءة النسخة الاحتياطية. تحقق من كلمة المرور.' });
    }
  });

  app.delete('/api/backups/:id', requireAuth, (req: AuthRequest, res) => {
    db.prepare('DELETE FROM backups WHERE id = ? AND user_id = ?').run(req.params.id, req.user!.id);
    res.json({ ok: true });
  });

  // --- NOTIFICATIONS, ACTIVITY, PLANS ---
  app.get('/api/notifications', requireAuth, (req: AuthRequest, res) => {
    res.json({
      notifications: db.prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 30').all(req.user!.id),
    });
  });

  app.post('/api/notifications/read-all', requireAuth, (req: AuthRequest, res) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE user_id = ?').run(req.user!.id);
    res.json({ ok: true });
  });

  app.get('/api/activity', requireAuth, (req: AuthRequest, res) => {
    res.json({
      logs: db.prepare('SELECT * FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT 50').all(req.user!.id),
    });
  });

  app.get('/api/plans', requireAuth, (req: AuthRequest, res) => {
    res.json({
      currentPlan: req.user!.plan,
      billingHistory: db.prepare('SELECT * FROM billing_history WHERE user_id = ? ORDER BY created_at DESC').all(req.user!.id),
    });
  });

  app.post('/api/plans/select', requireAuth, (req: AuthRequest, res) => {
    const plan = String(req.body?.plan || 'FREE').toUpperCase();
    const prices: Record<string, number> = { FREE: 0, PLUS: 29, FAMILY: 49, BUSINESS: 99 };
    if (!(plan in prices)) {
      res.status(400).json({ error: 'باقة غير صالحة' });
      return;
    }
    db.prepare('UPDATE users SET plan = ? WHERE id = ?').run(plan, req.user!.id);
    db.prepare(
      'INSERT INTO billing_history (id, user_id, plan, amount, currency, status, invoice_number, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      crypto.randomUUID(),
      req.user!.id,
      plan,
      prices[plan],
      'SAR',
      plan === 'FREE' ? 'free_tier' : 'pending_payment_gateway',
      `INV-${Date.now().toString().slice(-6)}`,
      new Date().toISOString()
    );
    logActivity(req.user!.id, 'تحديث الباقة', 'plans', plan);
    res.json({ plan });
  });

  // --- SMART ASSISTANT (SERVER-SIDE GEMINI WITH PERMISSION ENFORCEMENT) ---
  app.post('/api/assistant/chat', requireAuth, async (req: AuthRequest, res) => {
    try {
      const uid = req.user!.id;
      const message = String(req.body?.message || '').trim();
      const lang = req.user!.language === 'en' ? 'en' : 'ar';
      if (!message) {
        res.status(400).json({ error: 'الرسالة مطلوبة' });
        return;
      }

      if (!process.env.GEMINI_API_KEY) {
        res.status(503).json({
          error: 'GEMINI_API_KEY غير مهيأ على الخادم. يرجى إعداده في Settings > Secrets لتفعيل المساعد الذكي.',
        });
        return;
      }

      const consent = JSON.parse(req.user!.assistant_consent || '{}');
      const context: Record<string, unknown> = {
        permittedModules: Object.keys(consent).filter((k) => consent[k]),
        deniedModules: Object.keys(consent).filter((k) => !consent[k]),
      };

      if (consent.documents) {
        context.documents = db
          .prepare('SELECT name, ext, size_bytes, text_preview, updated_at FROM documents WHERE user_id = ? AND is_deleted = 0 ORDER BY updated_at DESC LIMIT 15')
          .all(uid);
      }
      if (consent.expenses) {
        context.transactions = db
          .prepare('SELECT type, title, amount, currency, category, date FROM transactions WHERE user_id = ? ORDER BY date DESC LIMIT 25')
          .all(uid);
      }
      if (consent.subscriptions) {
        context.subscriptions = db
          .prepare('SELECT service_name, price, currency, renewal_date, billing_cycle, status FROM subscriptions WHERE user_id = ?')
          .all(uid);
      }
      if (consent.calendar) {
        context.events = db
          .prepare('SELECT title, date, start_time, location, priority FROM events WHERE user_id = ? ORDER BY date ASC LIMIT 15')
          .all(uid);
      }
      if (consent.tasks) {
        context.tasks = db
          .prepare('SELECT title, category, priority, due_date, completed FROM tasks WHERE user_id = ? ORDER BY created_at DESC LIMIT 20')
          .all(uid);
      }
      if (consent.warranties) {
        context.warranties = db
          .prepare('SELECT product_name, expiry_date, service_center FROM warranties WHERE user_id = ?')
          .all(uid);
      }

      const ai = new GoogleGenAI({
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: { 'User-Agent': 'aistudio-build' },
        },
      });

      const systemInstruction = `You are the built-in Smart Assistant inside MY LIFE ("نظام الحياة الرقمية المتكامل").
Respond in ${lang === 'ar' ? 'Arabic' : 'English'} with clear, helpful, structured prose.
STRICT PRIVACY RULE: You ONLY have access to the modules listed in permittedModules below.
If the user asks about a module listed in deniedModules (e.g., expenses or documents when permission is OFF), politely tell them that access to that section is currently disabled in Assistant Privacy Controls and do NOT guess or fabricate numbers.
Never fabricate user data that is not present in the JSON context. If a section has empty arrays, state that no records have been added there yet.

USER PERMITTED DATA CONTEXT:
${JSON.stringify(context)}`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: message,
        config: { systemInstruction },
      });

      res.json({ reply: response.text || '' });
    } catch (err) {
      res.status(500).json({ error: (err as Error).message || 'Assistant request failed' });
    }
  });

  // --- VITE MIDDLEWARE (DEV) OR STATIC (PROD) ---
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MY LIFE server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
