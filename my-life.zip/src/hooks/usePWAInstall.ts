import { useEffect, useState } from 'react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export type PlatformKind = 'android' | 'iphone' | 'ipad' | 'windows' | 'macos' | 'other';

export function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  return isOnline;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [platform, setPlatform] = useState<PlatformKind>('other');
  const [isSafariOnIOS, setIsSafariOnIOS] = useState(true);
  const [justInstalled, setJustInstalled] = useState(false);

  const checkStandalone = () => {
    if (typeof window === 'undefined') return false;
    const standaloneMatch = window.matchMedia('(display-mode: standalone)').matches;
    const iosStandalone = (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    return standaloneMatch || iosStandalone;
  };

  useEffect(() => {
    setIsInstalled(checkStandalone());

    const ua = window.navigator.userAgent;
    const lower = ua.toLowerCase();
    const isIpad = /ipad/.test(lower) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const isIphone = /iphone|ipod/.test(lower);
    const isAndroid = /android/.test(lower);
    const isWindows = /windows/.test(lower);
    const isMac = /macintosh|mac os/.test(lower) && !isIpad;

    if (isIphone) setPlatform('iphone');
    else if (isIpad) setPlatform('ipad');
    else if (isAndroid) setPlatform('android');
    else if (isWindows) setPlatform('windows');
    else if (isMac) setPlatform('macos');
    else setPlatform('other');

    if (isIphone || isIpad) {
      const isCriOS = /crios|fxios|edgios|opios|gsa/i.test(ua);
      const isSafari = /safari/i.test(ua) && !isCriOS;
      setIsSafariOnIOS(isSafari);
    }

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setJustInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const install = async (): Promise<'accepted' | 'dismissed' | 'unavailable'> => {
    if (!deferredPrompt) return 'unavailable';
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setJustInstalled(true);
      setDeferredPrompt(null);
      return 'accepted';
    }
    return 'dismissed';
  };

  const recheckInstalled = () => {
    const standalone = checkStandalone();
    setIsInstalled(standalone);
    return standalone;
  };

  return {
    isInstallable: Boolean(deferredPrompt),
    isInstalled,
    justInstalled,
    platform,
    isIOS: platform === 'iphone' || platform === 'ipad',
    isSafariOnIOS,
    install,
    recheckInstalled,
  };
}
