import type { Language, ModuleId } from '../types';

export interface SectionMeta {
  id: ModuleId;
  ar: string;
  en: string;
  icon: string;
  color: string;
}

export const CORE_SECTIONS: SectionMeta[] = [
  { id: 'documents', ar: 'المستندات', en: 'Documents', icon: 'FolderOpen', color: '#38BDF8' },
  { id: 'calendar', ar: 'المواعيد', en: 'Calendar', icon: 'CalendarDays', color: '#EF4444' },
  { id: 'subscriptions', ar: 'الاشتراكات', en: 'Subscriptions', icon: 'Layers', color: '#F59E0B' },
  { id: 'purchases', ar: 'المشتريات', en: 'Purchases', icon: 'ShoppingCart', color: '#A3E635' },
  { id: 'expenses', ar: 'المصروفات', en: 'Expenses', icon: 'BarChart3', color: '#FF7900' },
  { id: 'family', ar: 'العائلة', en: 'Family', icon: 'Users', color: '#A855F7' },
  { id: 'budget', ar: 'الميزانية', en: 'Budget', icon: 'Wallet', color: '#10B981' },
  { id: 'warranties', ar: 'الضمانات', en: 'Warranties', icon: 'ShieldCheck', color: '#3B82F6' },
  { id: 'maintenance', ar: 'الصيانة', en: 'Maintenance', icon: 'Wrench', color: '#EC4899' },
  { id: 'properties', ar: 'العقارات', en: 'Properties', icon: 'Building2', color: '#14B8A6' },
  { id: 'travel', ar: 'السفر', en: 'Travel', icon: 'Plane', color: '#C084FC' },
  { id: 'goals', ar: 'الأهداف', en: 'Goals', icon: 'Target', color: '#FB7185' },
  { id: 'tasks', ar: 'المهام', en: 'Tasks', icon: 'CheckSquare', color: '#FBBF24' },
  { id: 'mylife', ar: 'My Life', en: 'My Life', icon: 'Compass', color: '#FF7900' },
  { id: 'assistant', ar: 'المساعد الذكي', en: 'Smart Assistant', icon: 'Sparkles', color: '#818CF8' },
  { id: 'reports', ar: 'التقارير', en: 'Reports', icon: 'PieChart', color: '#2DD4BF' },
  { id: 'contacts', ar: 'جهات الاتصال', en: 'Contacts', icon: 'Contact', color: '#60A5FA' },
  { id: 'backup', ar: 'النسخ الاحتياطي', en: 'Backup', icon: 'DatabaseBackup', color: '#34D399' },
  { id: 'vault', ar: 'المحفوظات', en: 'Vault', icon: 'Archive', color: '#F472B6' },
  { id: 'favorites', ar: 'المفضلة', en: 'Favorites', icon: 'Star', color: '#FACC15' },
  { id: 'tools', ar: 'أدوات أخرى', en: 'More Tools', icon: 'Grid2x2Plus', color: '#94A3B8' },
];

export const LABELS: Record<Language, Record<string, string>> = {
  ar: {
    brand: 'MY LIFE',
    tagline: 'YOUR LIFE, ORGANIZED.',
    subtitle: 'منظم حياتك المتكامل',
    description: 'Your Entire Digital Life. One Place.',
    welcome: 'مرحبًا',
    searchPlaceholder: 'ابحث في المستندات، المصروفات، الاشتراكات، المهام...',
    quickAdd: 'إضافة سريعة',
    home: 'الرئيسية',
    documents: 'المستندات',
    add: 'إضافة',
    reports: 'التقارير',
    more: 'المزيد',
    settings: 'الإعدادات',
    plans: 'الباقات والاشتراكات',
    iconLibrary: 'مكتبة الأيقونات (500+)',
    widgetBuilder: 'إضافة أداة مخصصة',
    expensesMonth: 'مصروفات الشهر',
    upcomingEvents: 'المواعيد القادمة',
    renewingSoon: 'تجديدات قريبة',
    tasksProgress: 'إنجاز المهام',
    save: 'حفظ',
    cancel: 'إلغاء',
    delete: 'حذف',
    edit: 'تعديل',
    close: 'إغلاق',
    loading: 'جارٍ التحميل...',
    noData: 'لا توجد بيانات بعد',
    loadSample: 'تعبئة مساحة عمل نموذجية للتجربة',
    currency: 'ر.س',
    offlineBanner: 'وضع عدم الاتصال — يتم عرض البيانات المحفوظة محليًا',
    installTitle: 'Install MY LIFE',
    installAction: 'تثبيت التطبيق',
    iosInstallTitle: 'Add MY LIFE to Home Screen',
    iosInstallAction: 'طريقة التثبيت',
    later: 'لاحقًا',
    logout: 'تسجيل الخروج',
  },
  en: {
    brand: 'MY LIFE',
    tagline: 'YOUR LIFE, ORGANIZED.',
    subtitle: 'Your Entire Digital Life. One Place.',
    description: 'Your Entire Digital Life. One Place.',
    welcome: 'Welcome',
    searchPlaceholder: 'Search documents, expenses, subscriptions, tasks...',
    quickAdd: 'Quick Add',
    home: 'Home',
    documents: 'Documents',
    add: 'Add',
    reports: 'Reports',
    more: 'More',
    settings: 'Settings',
    plans: 'Plans & Billing',
    iconLibrary: 'Icon Library (500+)',
    widgetBuilder: 'Custom Widget Builder',
    expensesMonth: 'Monthly Expenses',
    upcomingEvents: 'Upcoming Events',
    renewingSoon: 'Renewing Soon',
    tasksProgress: 'Tasks Progress',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    close: 'Close',
    loading: 'Loading...',
    noData: 'No records yet',
    loadSample: 'Load Sample Workspace',
    currency: 'SAR',
    offlineBanner: 'Offline Mode — Cached local data active',
    installTitle: 'Install MY LIFE',
    installAction: 'Install App',
    iosInstallTitle: 'Add MY LIFE to Home Screen',
    iosInstallAction: 'How to Install',
    later: 'Later',
    logout: 'Sign Out',
  },
};

export function formatCurrency(val: number, lang: Language = 'ar'): string {
  const num = Number(val || 0).toLocaleString(lang === 'ar' ? 'en-US' : 'en-US', {
    maximumFractionDigits: 2,
  });
  return `${num} ${LABELS[lang].currency}`;
}
