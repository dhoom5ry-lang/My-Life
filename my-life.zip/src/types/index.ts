export type Language = 'ar' | 'en';
export type ThemeMode = 'dark' | 'light';
export type IconShape = 'squircle' | 'circle' | 'rounded' | 'sharp';
export type CardStyle = 'glass' | 'classic';

export type ModuleId =
  | 'dashboard'
  | 'documents'
  | 'calendar'
  | 'subscriptions'
  | 'purchases'
  | 'expenses'
  | 'family'
  | 'budget'
  | 'warranties'
  | 'maintenance'
  | 'properties'
  | 'travel'
  | 'goals'
  | 'tasks'
  | 'mylife'
  | 'assistant'
  | 'reports'
  | 'contacts'
  | 'backup'
  | 'vault'
  | 'favorites'
  | 'tools'
  | 'settings'
  | 'plans'
  | 'widget_builder'
  | 'icon_library'
  | 'custom_widget';

export interface AssistantConsent {
  documents: boolean;
  expenses: boolean;
  subscriptions: boolean;
  calendar: boolean;
  tasks: boolean;
  warranties: boolean;
}

export interface User {
  id: string;
  email: string;
  name: string;
  avatar_url: string;
  language: Language;
  theme: ThemeMode;
  accent_color: string;
  icon_shape: IconShape;
  card_style: CardStyle;
  plan: 'FREE' | 'PLUS' | 'FAMILY' | 'BUSINESS';
  assistant_consent: string;
  notifications_enabled: number;
  privacy_mode: number;
  created_at: string;
}

export interface DocumentItem {
  id: string;
  folder_id: string | null;
  name: string;
  original_name: string;
  mime_type: string;
  ext: string;
  size_bytes: number;
  text_preview: string;
  is_favorite: number;
  is_deleted: number;
  deleted_at: string | null;
  share_token: string | null;
  created_at: string;
  updated_at: string;
}

export interface FolderItem {
  id: string;
  name: string;
  color_hex: string;
  opacity: number;
  icon_name: string;
  style: CardStyle;
  is_favorite: number;
  sort_order: number;
  file_count: number;
  preview_docs: DocumentItem[];
  created_at: string;
}

export interface PurchaseItem {
  id: string;
  product_name: string;
  image_url: string;
  price: number;
  currency: string;
  store: string;
  purchase_date: string;
  order_number: string;
  status: string;
  payment_method: string;
  category: string;
  warranty_months: number;
  invoice_doc_id: string | null;
  notes: string;
}

export interface TransactionItem {
  id: string;
  type: 'expense' | 'income';
  title: string;
  amount: number;
  currency: string;
  category: string;
  date: string;
  payment_method: string;
  invoice_doc_id: string | null;
  notes: string;
}

export interface SubscriptionItem {
  id: string;
  service_name: string;
  logo_icon: string;
  color: string;
  price: number;
  currency: string;
  start_date: string;
  renewal_date: string;
  billing_cycle: 'monthly' | 'yearly' | 'weekly';
  status: 'active' | 'expiring' | 'expired' | 'cancelled';
  notes: string;
}

export interface CalendarEventItem {
  id: string;
  title: string;
  date: string;
  start_time: string;
  end_time: string;
  location: string;
  priority: 'low' | 'medium' | 'high';
  recurrence: 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';
  description: string;
  shared_with_family: number;
  reminder_minutes: number;
}

export interface FamilyMember {
  id: string;
  family_id: string;
  user_id: string | null;
  display_name: string;
  relation: string;
  role: 'owner' | 'admin' | 'member' | 'viewer';
  avatar_color: string;
  permissions: string;
}

export interface FamilyItem {
  id: string;
  family_id: string;
  item_type: 'expense' | 'task' | 'purchase' | 'bill' | 'goal';
  title: string;
  amount: number;
  target_amount: number;
  due_date: string;
  assigned_to: string;
  status: string;
  notes: string;
  created_at: string;
}

export interface BudgetItem {
  id: string;
  category: string;
  period: 'monthly' | 'yearly';
  limit_amount: number;
  currency: string;
  alert_threshold: number;
}

export interface SavingsGoal {
  id: string;
  title: string;
  target_amount: number;
  current_amount: number;
  currency: string;
  deadline: string;
  icon_name: string;
  color: string;
}

export interface WarrantyItem {
  id: string;
  product_name: string;
  manufacturer: string;
  purchase_date: string;
  expiry_date: string;
  serial_number: string;
  service_center: string;
  invoice_doc_id: string | null;
  notes: string;
}

export interface MaintenanceItem {
  id: string;
  category: 'car' | 'home' | 'appliances' | 'ac' | 'equipment' | 'other';
  title: string;
  service_center: string;
  scheduled_date: string;
  cost: number;
  status: 'scheduled' | 'in_progress' | 'completed';
  notes: string;
}

export interface PropertyItem {
  id: string;
  name: string;
  address: string;
  image_url: string;
  value: number;
  lease_start: string;
  lease_end: string;
  monthly_rent: number;
  expenses_total: number;
  revenue_total: number;
  notes: string;
}

export interface TripItem {
  id: string;
  destination: string;
  departure_date: string;
  return_date: string;
  flight_info: string;
  hotel_info: string;
  budget: number;
  spent: number;
  checklist_json: string;
  notes: string;
}

export interface TaskItem {
  id: string;
  title: string;
  category: 'daily' | 'work' | 'study' | 'home' | 'family' | 'shopping' | 'responsibility';
  priority: 'low' | 'medium' | 'high';
  due_date: string;
  due_time: string;
  recurrence: 'none' | 'daily' | 'weekly' | 'monthly';
  completed: number;
  is_goal: number;
  progress: number;
}

export interface ContactItem {
  id: string;
  name: string;
  phone: string;
  email: string;
  relationship: string;
  company: string;
  notes: string;
  is_favorite: number;
}

export interface VaultItem {
  id: string;
  type: 'photo' | 'video' | 'document' | 'link' | 'note';
  title: string;
  content: string;
  url: string;
  doc_id: string | null;
  is_favorite: number;
  created_at: string;
}

export interface CustomWidget {
  id: string;
  name: string;
  icon_name: string;
  icon_color: string;
  bg_color: string;
  style: CardStyle;
  opacity: number;
  widget_type: 'checklist' | 'counter' | 'notes' | 'quick_expense' | 'link' | 'tracker';
  config_json: string;
  data_json: string;
  is_favorite: number;
  sort_order: number;
}

export interface NotificationItem {
  id: string;
  title: string;
  body: string;
  type: string;
  is_read: number;
  link_module: string;
  created_at: string;
}

export interface DashboardSummary {
  tilesOrder: string[];
  expensesMonth: number;
  incomeMonth: number;
  upcomingEvents: CalendarEventItem[];
  renewingSoon: SubscriptionItem[];
  pendingTasks: TaskItem[];
  tasksStats: { total: number; completed: number };
  docCount: number;
  customWidgets: CustomWidget[];
  unreadNotifications: number;
}
