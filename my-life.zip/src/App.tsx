import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  Check,
  Crown,
  Download,
  GripVertical,
  Home,
  LayoutGrid,
  PieChart,
  Plus,
  Search,
  Settings,
  Sparkles,
  FolderOpen,
  WifiOff,
  Activity,
} from 'lucide-react';
import { apiFetch, setAuthToken } from './lib/api';
import { CORE_SECTIONS, formatCurrency, LABELS } from './lib/i18n';
import type {
  CustomWidget,
  DashboardSummary,
  Language,
  ModuleId,
  NotificationItem,
  User,
} from './types';
import { useOnlineStatus, usePWAInstall } from './hooks/usePWAInstall';
import { PWAInstallModal } from './components/PWAInstallModal';
import { AuthOnboarding } from './components/AuthOnboarding';
import { DynamicIcon } from './components/DynamicIcon';
import { GlassCard, GlassModal, PrimaryButton } from './components/GlassUI';
import { IconLibraryView } from './components/IconPickerModal';
import { DocumentsModule } from './modules/DocumentsModule';
import { PurchasesModule } from './modules/PurchasesModule';
import { ExpensesModule } from './modules/ExpensesModule';
import { SubscriptionsModule } from './modules/SubscriptionsModule';
import { BudgetModule } from './modules/BudgetModule';
import { CalendarModule } from './modules/CalendarModule';
import { FamilyModule } from './modules/FamilyModule';
import { TasksAndLifeModule } from './modules/TasksAndLifeModule';
import {
  MaintenanceModule,
  PropertiesModule,
  TravelModule,
  WarrantiesModule,
} from './modules/AssetsModules';
import { AssistantModule } from './modules/AssistantModule';
import { ReportsModule } from './modules/ReportsModule';
import {
  BackupModule,
  ContactsModule,
  FavoritesModule,
  VaultModule,
} from './modules/VaultContactsBackupModule';
import { CustomWidgetRunner, WidgetBuilderModule } from './modules/WidgetBuilderModule';
import { PlansModule, SettingsModule } from './modules/SettingsAndPlansModule';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const [guestLang, setGuestLang] = useState<Language>('ar');
  const [activeModule, setActiveModule] = useState<ModuleId>('dashboard');
  const [activeCustomWidget, setActiveCustomWidget] = useState<CustomWidget | null>(null);
  const [editingWidget, setEditingWidget] = useState<CustomWidget | null>(null);

  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Record<string, unknown[]> | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [installModalOpen, setInstallModalOpen] = useState(false);
  const [activityLogs, setActivityLogs] = useState<{ id: string; action: string; module: string; details: string; created_at: string }[]>([]);
  const [activityOpen, setActivityOpen] = useState(false);

  const [draggedTileId, setDraggedTileId] = useState<string | null>(null);
  const [loadingSample, setLoadingSample] = useState(false);

  const isOnline = useOnlineStatus();
  const pwa = usePWAInstall();

  const lang: Language = user?.language === 'en' ? 'en' : user ? 'ar' : guestLang;
  const isAr = lang === 'ar';
  const t = LABELS[lang];

  // Sync HTML dir, lang, and dark/light theme
  useEffect(() => {
    const html = document.documentElement;
    html.lang = lang;
    html.dir = isAr ? 'rtl' : 'ltr';
    if (user?.theme === 'light') html.classList.remove('dark');
    else html.classList.add('dark');
  }, [lang, isAr, user?.theme]);

  const loadSummary = useCallback(async () => {
    try {
      const data = await apiFetch<DashboardSummary>('/api/dashboard/summary');
      setSummary(data);
    } catch {
      // ignore if offline
    }
  }, []);

  useEffect(() => {
    apiFetch<{ user: User }>('/api/auth/me')
      .then((res) => {
        setUser(res.user);
      })
      .catch(() => {
        setUser(null);
      })
      .finally(() => setCheckingAuth(false));
  }, []);

  useEffect(() => {
    if (user) {
      loadSummary();
    }
  }, [user, activeModule, loadSummary]);

  // Global live search
  useEffect(() => {
    if (!user || !searchQuery.trim()) {
      setSearchResults(null);
      return;
    }
    const timer = setTimeout(async () => {
      try {
        const res = await apiFetch<Record<string, unknown[]>>(`/api/search?q=${encodeURIComponent(searchQuery.trim())}`);
        setSearchResults(res);
      } catch {
        // ignore
      }
    }, 220);
    return () => clearTimeout(timer);
  }, [searchQuery, user]);

  // Subtle PWA Install prompt after dwell (only if installable or iOS & not installed)
  useEffect(() => {
    if (!user || pwa.isInstalled) return;
    const dismissed = sessionStorage.getItem('mylife_install_prompted');
    if (dismissed) return;
    if (pwa.isInstallable || pwa.isIOS) {
      const timer = setTimeout(() => {
        setInstallModalOpen(true);
        sessionStorage.setItem('mylife_install_prompted', '1');
      }, 12000);
      return () => clearTimeout(timer);
    }
  }, [user, pwa.isInstalled, pwa.isInstallable, pwa.isIOS]);

  const orderedTiles = useMemo(() => {
    const order = summary?.tilesOrder || CORE_SECTIONS.map((s) => s.id);
    const map = new Map(CORE_SECTIONS.map((s) => [s.id, s]));
    const list = order.map((id) => map.get(id as ModuleId)).filter((x): x is NonNullable<typeof x> => Boolean(x));
    for (const s of CORE_SECTIONS) {
      if (!list.find((x) => x.id === s.id)) list.push(s);
    }
    return list;
  }, [summary?.tilesOrder]);

  const handleTileDrop = async (targetId: string) => {
    if (!draggedTileId || draggedTileId === targetId || !summary) return;
    const currentOrder = orderedTiles.map((x) => x.id);
    const fromIdx = currentOrder.indexOf(draggedTileId as ModuleId);
    const toIdx = currentOrder.indexOf(targetId as ModuleId);
    if (fromIdx === -1 || toIdx === -1) return;
    const next = [...currentOrder];
    const [moved] = next.splice(fromIdx, 1);
    next.splice(toIdx, 0, moved);
    setSummary({ ...summary, tilesOrder: next });
    setDraggedTileId(null);
    await apiFetch('/api/dashboard/order', {
      method: 'PUT',
      body: JSON.stringify({ order: next }),
    });
  };

  const openNotifications = async () => {
    const res = await apiFetch<{ notifications: NotificationItem[] }>('/api/notifications');
    setNotifications(res.notifications || []);
    setNotifOpen(true);
    await apiFetch('/api/notifications/read-all', { method: 'POST' });
    loadSummary();
  };

  const handleLogout = async () => {
    try {
      await apiFetch('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    setAuthToken(null);
    setUser(null);
    setActiveModule('dashboard');
  };

  if (checkingAuth) {
    return (
      <div className="min-h-screen bg-[#080808] text-white flex flex-col items-center justify-center gap-4">
        <img src="/icon-192.png" alt="MY LIFE" className="w-16 h-16 rounded-2xl shadow-xl shadow-[#FF7900]/30" />
        <p className="text-sm font-bold tracking-widest">MY LIFE</p>
      </div>
    );
  }

  if (!user) {
    return (
      <AuthOnboarding
        lang={guestLang}
        onChangeLang={setGuestLang}
        onAuthenticated={(u) => setUser(u)}
      />
    );
  }

  const accent = user.accent_color || '#FF7900';
  const iconRadius =
    user.icon_shape === 'circle'
      ? 'rounded-full'
      : user.icon_shape === 'rounded'
      ? 'rounded-xl'
      : 'rounded-2xl';

  const currentSectionMeta = CORE_SECTIONS.find((s) => s.id === activeModule);
  const currentTitle =
    activeModule === 'dashboard'
      ? t.brand
      : activeModule === 'settings'
      ? t.settings
      : activeModule === 'plans'
      ? t.plans
      : activeModule === 'icon_library'
      ? t.iconLibrary
      : activeModule === 'widget_builder'
      ? t.widgetBuilder
      : activeModule === 'custom_widget'
      ? activeCustomWidget?.name || ''
      : currentSectionMeta
      ? isAr
        ? currentSectionMeta.ar
        : currentSectionMeta.en
      : t.brand;

  const isBrandNewWorkspace = summary && summary.docCount === 0 && summary.expensesMonth === 0 && summary.tasksStats.total === 0;

  return (
    <div className="min-h-screen flex flex-col lg:flex-row relative">
      {/* Subtle Top-Right Glass Ambient Glow (non-nature, calm dark luxury) */}
      <div
        className="pointer-events-none fixed -top-48 -right-40 w-[460px] h-[460px] rounded-full opacity-15 blur-[140px]"
        style={{ background: `radial-gradient(circle, ${accent} 0%, transparent 70%)` }}
      />

      {/* Desktop Left/Right Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 border-e border-white/10 bg-[#0d0d0f]/85 backdrop-blur-2xl z-30 p-4 justify-between">
        <div className="space-y-6 overflow-y-auto">
          <button
            onClick={() => setActiveModule('dashboard')}
            className="flex items-center gap-3 px-2 py-1 text-start cursor-pointer"
          >
            <img src="/icon-192.png" alt="MY LIFE" className="w-10 h-10 rounded-xl border border-[#FF7900]/40" />
            <div>
              <span className="block font-bold text-base tracking-tight">MY LIFE</span>
              <span className="block text-[10px] opacity-55 tracking-wider">YOUR LIFE, ORGANIZED.</span>
            </div>
          </button>

          <nav className="space-y-1">
            <button
              onClick={() => setActiveModule('dashboard')}
              className={`w-full min-h-[42px] px-3 rounded-xl flex items-center gap-3 text-xs font-semibold cursor-pointer transition ${
                activeModule === 'dashboard' ? 'bg-[#FF7900] text-white' : 'hover:bg-white/8 opacity-80'
              }`}
            >
              <Home size={17} />
              <span>{t.home}</span>
            </button>
            {CORE_SECTIONS.slice(0, 10).map((sec) => (
              <button
                key={sec.id}
                onClick={() => setActiveModule(sec.id)}
                className={`w-full min-h-[40px] px-3 rounded-xl flex items-center gap-3 text-xs font-medium cursor-pointer transition ${
                  activeModule === sec.id ? 'bg-[#FF7900] text-white font-semibold' : 'hover:bg-white/8 opacity-75 hover:opacity-100'
                }`}
              >
                <DynamicIcon name={sec.icon} size={16} color={activeModule === sec.id ? '#FFFFFF' : sec.color} />
                <span className="truncate">{isAr ? sec.ar : sec.en}</span>
              </button>
            ))}
            <button
              onClick={() => setActiveModule('assistant')}
              className={`w-full min-h-[40px] px-3 rounded-xl flex items-center gap-3 text-xs font-medium cursor-pointer transition ${
                activeModule === 'assistant' ? 'bg-[#FF7900] text-white font-semibold' : 'hover:bg-white/8 opacity-75'
              }`}
            >
              <Sparkles size={16} className="text-indigo-400" />
              <span>{isAr ? 'المساعد الذكي' : 'Smart Assistant'}</span>
            </button>
            <button
              onClick={() => setActiveModule('reports')}
              className={`w-full min-h-[40px] px-3 rounded-xl flex items-center gap-3 text-xs font-medium cursor-pointer transition ${
                activeModule === 'reports' ? 'bg-[#FF7900] text-white font-semibold' : 'hover:bg-white/8 opacity-75'
              }`}
            >
              <PieChart size={16} className="text-teal-400" />
              <span>{t.reports}</span>
            </button>
            <button
              onClick={() => setActiveModule('tools')}
              className={`w-full min-h-[40px] px-3 rounded-xl flex items-center gap-3 text-xs font-medium cursor-pointer transition ${
                activeModule === 'tools' ? 'bg-[#FF7900] text-white font-semibold' : 'hover:bg-white/8 opacity-75'
              }`}
            >
              <LayoutGrid size={16} />
              <span>{isAr ? 'جميع الأقسام والأدوات' : 'All Sections & Tools'}</span>
            </button>
          </nav>
        </div>

        <div className="space-y-2 pt-3 border-t border-white/10">
          {!pwa.isInstalled && (
            <button
              onClick={() => setInstallModalOpen(true)}
              className="w-full min-h-[40px] px-3 rounded-xl bg-[#FF7900]/15 border border-[#FF7900]/35 text-[#FF7900] text-xs font-semibold flex items-center gap-2 cursor-pointer"
            >
              <Download size={15} />
              <span>{isAr ? 'تثبيت التطبيق' : 'Install MY LIFE'}</span>
            </button>
          )}
          <button
            onClick={() => setActiveModule('plans')}
            className="w-full min-h-[38px] px-3 rounded-xl hover:bg-white/8 text-xs flex items-center justify-between cursor-pointer"
          >
            <span className="flex items-center gap-2">
              <Crown size={15} className="text-amber-400" />
              <span>{user.plan}</span>
            </span>
            <span className="opacity-55 text-[11px]">{isAr ? 'الباقة' : 'Plan'}</span>
          </button>
          <button
            onClick={() => setActiveModule('settings')}
            className={`w-full min-h-[40px] px-3 rounded-xl flex items-center gap-2.5 text-xs font-medium cursor-pointer ${
              activeModule === 'settings' ? 'bg-[#FF7900] text-white' : 'hover:bg-white/8 opacity-80'
            }`}
          >
            <Settings size={16} />
            <span>{t.settings}</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className={`flex-1 flex flex-col min-w-0 ${isAr ? 'lg:mr-64' : 'lg:ml-64'} pb-24 lg:pb-10`}>
        {/* Top Bar (Compact 1-row, < 60px) */}
        <header className="sticky top-0 z-20 px-4 sm:px-6 py-3 bg-[#080808]/80 backdrop-blur-xl border-b border-white/10 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            {activeModule !== 'dashboard' ? (
              <button
                onClick={() => setActiveModule('dashboard')}
                className="min-h-[40px] min-w-[40px] rounded-xl bg-white/8 hover:bg-white/14 flex items-center justify-center cursor-pointer"
                aria-label="Back"
              >
                {isAr ? <ArrowRight size={18} /> : <ArrowLeft size={18} />}
              </button>
            ) : (
              <img src="/icon-192.png" alt="MY LIFE" className="w-9 h-9 rounded-xl lg:hidden" />
            )}
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-bold truncate">{currentTitle}</h2>
              {activeModule === 'dashboard' && (
                <p className="text-[11px] opacity-55 hidden sm:block">
                  {t.welcome}، {user.name}
                </p>
              )}
            </div>
          </div>

          {/* Search Bar on Desktop/Tablet */}
          <div className="hidden md:block relative flex-1 max-w-md">
            <Search size={15} className="absolute top-3 right-3.5 opacity-50" />
            <input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full min-h-[38px] rounded-xl bg-white/[0.06] border border-white/12 pr-9 pl-4 text-xs focus:outline-none focus:border-[#FF7900]"
            />
            {searchResults && (
              <div className="absolute top-11 inset-x-0 glass-panel rounded-2xl p-3 space-y-2 z-50 max-h-80 overflow-y-auto">
                {Object.entries(searchResults).every(([, arr]) => arr.length === 0) ? (
                  <p className="text-xs opacity-60 text-center py-3">{isAr ? 'لا توجد نتائج مطابقة' : 'No matching records'}</p>
                ) : (
                  Object.entries(searchResults).map(([group, arr]) =>
                    arr.length > 0 ? (
                      <div key={group} className="space-y-1">
                        <p className="text-[10px] font-bold uppercase text-[#FF7900]">{group}</p>
                        {arr.map((item: unknown, idx) => {
                          const rec = item as Record<string, string>;
                          const label = rec.name || rec.title || rec.service_name || rec.product_name || 'Item';
                          return (
                            <button
                              key={idx}
                              onClick={() => {
                                setSearchQuery('');
                                setSearchResults(null);
                                if (group === 'documents' || group === 'folders') setActiveModule('documents');
                                else if (group === 'transactions') setActiveModule('expenses');
                                else if (group === 'subscriptions') setActiveModule('subscriptions');
                                else if (group === 'tasks') setActiveModule('tasks');
                                else if (group === 'contacts') setActiveModule('contacts');
                                else if (group === 'purchases') setActiveModule('purchases');
                              }}
                              className="w-full text-start px-2.5 py-1.5 rounded-lg hover:bg-white/10 text-xs truncate cursor-pointer"
                            >
                              {label}
                            </button>
                          );
                        })}
                      </div>
                    ) : null
                  )
                )}
              </div>
            )}
          </div>

          {/* Right Action Controls */}
          <div className="flex items-center gap-2 shrink-0">
            {!pwa.isInstalled && (
              <button
                onClick={() => setInstallModalOpen(true)}
                className="lg:hidden min-h-[38px] px-3 rounded-xl bg-[#FF7900]/15 border border-[#FF7900]/35 text-[#FF7900] text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Download size={14} />
                <span>{isAr ? 'تثبيت' : 'Install'}</span>
              </button>
            )}
            <button
              onClick={openNotifications}
              aria-label="Notifications"
              className="relative min-h-[40px] min-w-[40px] rounded-xl bg-white/[0.06] hover:bg-white/12 border border-white/10 flex items-center justify-center cursor-pointer"
            >
              <Bell size={17} />
              {(summary?.unreadNotifications || 0) > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-[#FF7900] text-[10px] font-bold text-white flex items-center justify-center">
                  {summary?.unreadNotifications}
                </span>
              )}
            </button>
            <button
              onClick={() => setQuickAddOpen(true)}
              className="hidden sm:inline-flex min-h-[40px] px-3.5 rounded-xl bg-[#FF7900] text-white text-xs font-semibold items-center gap-1.5 cursor-pointer"
            >
              <Plus size={16} />
              <span>{t.quickAdd}</span>
            </button>
            <button
              onClick={() => setActiveModule('settings')}
              title={user.name}
              className="w-9 h-9 rounded-full bg-gradient-to-br from-[#FF7900] to-amber-600 text-white font-bold text-xs flex items-center justify-center border border-white/20 cursor-pointer shrink-0"
            >
              {user.name.slice(0, 1).toUpperCase()}
            </button>
          </div>
        </header>

        {/* Main Viewport */}
        <main className="flex-1 p-4 sm:p-6 max-w-7xl w-full mx-auto space-y-6">
          {activeModule === 'dashboard' && (
            <>
              {/* Mobile Search Input */}
              <div className="md:hidden relative">
                <Search size={16} className="absolute top-3.5 right-3.5 opacity-50" />
                <input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.searchPlaceholder}
                  className="w-full min-h-[44px] rounded-2xl bg-white/[0.06] border border-white/12 pr-10 pl-4 text-sm focus:outline-none focus:border-[#FF7900]"
                />
              </div>

              {/* Optional First-Time Starter Template Banner */}
              {isBrandNewWorkspace && (
                <GlassCard className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-[#FF7900]/35">
                  <div>
                    <h4 className="font-bold text-sm">
                      {isAr ? 'مساحتك الشخصية جاهزة ونظيفة!' : 'Your personal workspace is clean and ready!'}
                    </h4>
                    <p className="text-xs opacity-65 mt-0.5">
                      {isAr
                        ? 'ابدأ برفع ملفاتك وإضافة مصروفاتك، أو اضغط لتعبئة مساحة نموذجية للتجربة السريعة.'
                        : 'Start adding your real records, or optionally load a sample workspace to explore charts & paper previews.'}
                    </p>
                  </div>
                  <PrimaryButton
                    disabled={loadingSample}
                    onClick={async () => {
                      setLoadingSample(true);
                      await apiFetch('/api/auth/load-sample-workspace', { method: 'POST' });
                      await loadSummary();
                      setLoadingSample(false);
                    }}
                  >
                    {loadingSample ? t.loading : t.loadSample}
                  </PrimaryButton>
                </GlassCard>
              )}

              {/* 4 Live Summary KPI Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
                <GlassCard
                  cardStyle={user.card_style}
                  onClick={() => setActiveModule('expenses')}
                  className="p-4 space-y-1"
                >
                  <p className="text-xs opacity-60">{t.expensesMonth}</p>
                  <p className="text-lg sm:text-xl font-bold font-mono-num text-[#FF7900]">
                    {formatCurrency(summary?.expensesMonth || 0, lang)}
                  </p>
                  <p className="text-[11px] opacity-55 font-mono-num">
                    {isAr ? 'الدخل:' : 'Income:'} {formatCurrency(summary?.incomeMonth || 0, lang)}
                  </p>
                </GlassCard>

                <GlassCard
                  cardStyle={user.card_style}
                  onClick={() => setActiveModule('calendar')}
                  className="p-4 space-y-1"
                >
                  <p className="text-xs opacity-60">{t.upcomingEvents}</p>
                  <p className="text-lg sm:text-xl font-bold font-mono-num">
                    {summary?.upcomingEvents?.length || 0}
                  </p>
                  <p className="text-[11px] opacity-55 truncate">
                    {summary?.upcomingEvents?.[0]?.title || (isAr ? 'لا توجد مواعيد قريبة' : 'No upcoming events')}
                  </p>
                </GlassCard>

                <GlassCard
                  cardStyle={user.card_style}
                  onClick={() => setActiveModule('subscriptions')}
                  className="p-4 space-y-1"
                >
                  <p className="text-xs opacity-60">{t.renewingSoon}</p>
                  <p className="text-lg sm:text-xl font-bold font-mono-num text-amber-400">
                    {summary?.renewingSoon?.length || 0}
                  </p>
                  <p className="text-[11px] opacity-55 truncate">
                    {summary?.renewingSoon?.[0]
                      ? `${summary.renewingSoon[0].service_name} · ${summary.renewingSoon[0].renewal_date}`
                      : isAr
                      ? 'لا توجد تجديدات قريبة'
                      : 'All clear'}
                  </p>
                </GlassCard>

                <GlassCard
                  cardStyle={user.card_style}
                  onClick={() => setActiveModule('tasks')}
                  className="p-4 space-y-1"
                >
                  <p className="text-xs opacity-60">{t.tasksProgress}</p>
                  <p className="text-lg sm:text-xl font-bold font-mono-num text-emerald-400">
                    {summary?.tasksStats.completed || 0} / {summary?.tasksStats.total || 0}
                  </p>
                  <p className="text-[11px] opacity-55 truncate">
                    {summary?.pendingTasks?.[0]?.title || (isAr ? 'جميع المهام مكتملة' : 'All tasks completed')}
                  </p>
                </GlassCard>
              </div>

              {/* Custom Widgets Row (if user created any) */}
              {(summary?.customWidgets?.length || 0) > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold opacity-80">{isAr ? 'أدواتي المخصصة' : 'My Custom Widgets'}</h3>
                    <button
                      onClick={() => {
                        setEditingWidget(null);
                        setActiveModule('widget_builder');
                      }}
                      className="text-xs text-[#FF7900] font-semibold cursor-pointer"
                    >
                      + {isAr ? 'أداة جديدة' : 'New Widget'}
                    </button>
                  </div>
                  <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-3">
                    {summary?.customWidgets.map((w) => (
                      <button
                        key={w.id}
                        onClick={() => {
                          setActiveCustomWidget(w);
                          setActiveModule('custom_widget');
                        }}
                        style={{
                          backgroundColor: w.bg_color,
                          opacity: (w.opacity || 85) / 100,
                        }}
                        className="glass-highlight rounded-3xl p-4 flex flex-col items-center justify-center gap-2.5 border border-white/12 hover:border-[#FF7900]/50 transition cursor-pointer"
                      >
                        <div className={`w-11 h-11 ${iconRadius} bg-white/10 flex items-center justify-center`}>
                          <DynamicIcon name={w.icon_name} size={22} color={w.icon_color} />
                        </div>
                        <span className="text-xs font-bold truncate w-full text-center">{w.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 21 Core Glass Tiles Grid (Drag & Drop Reorderable) */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold opacity-80">
                    {isAr ? 'أقسام MY LIFE (اسحب وأفلت لإعادة الترتيب)' : 'MY LIFE Sections (Drag & drop to reorder)'}
                  </h3>
                  <button
                    onClick={() => {
                      setEditingWidget(null);
                      setActiveModule('widget_builder');
                    }}
                    className="text-xs text-[#FF7900] font-semibold cursor-pointer"
                  >
                    + {t.widgetBuilder}
                  </button>
                </div>

                <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-7 gap-3 sm:gap-4">
                  {orderedTiles.map((sec) => (
                    <div
                      key={sec.id}
                      draggable
                      onDragStart={() => setDraggedTileId(sec.id)}
                      onDragOver={(e) => e.preventDefault()}
                      onDrop={() => handleTileDrop(sec.id)}
                      onClick={() => setActiveModule(sec.id)}
                      className={`group relative ${
                        user.card_style === 'classic' ? 'classic-panel' : 'glass-tile'
                      } glass-highlight rounded-3xl p-4 sm:p-5 flex flex-col items-center justify-center gap-3 cursor-pointer hover:-translate-y-0.5 hover:border-[#FF7900]/45 transition-all duration-200`}
                    >
                      <GripVertical
                        size={12}
                        className="absolute top-2.5 left-2.5 opacity-0 group-hover:opacity-45 transition-opacity"
                      />
                      <div
                        className={`w-12 h-12 ${iconRadius} flex items-center justify-center border border-white/12 shadow-inner`}
                        style={{ backgroundColor: `${sec.color}1E` }}
                      >
                        <DynamicIcon name={sec.icon} size={24} color={sec.color} />
                      </div>
                      <span className="text-xs sm:text-sm font-semibold text-center leading-tight line-clamp-1">
                        {isAr ? sec.ar : sec.en}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}

          {activeModule === 'documents' && <DocumentsModule lang={lang} />}
          {activeModule === 'purchases' && <PurchasesModule lang={lang} />}
          {activeModule === 'expenses' && <ExpensesModule lang={lang} />}
          {activeModule === 'subscriptions' && <SubscriptionsModule lang={lang} />}
          {activeModule === 'budget' && <BudgetModule lang={lang} />}
          {activeModule === 'calendar' && <CalendarModule lang={lang} />}
          {activeModule === 'family' && <FamilyModule lang={lang} />}
          {activeModule === 'tasks' && <TasksAndLifeModule lang={lang} mode="tasks" />}
          {activeModule === 'goals' && <TasksAndLifeModule lang={lang} mode="goals" />}
          {activeModule === 'mylife' && <TasksAndLifeModule lang={lang} mode="mylife" />}
          {activeModule === 'warranties' && <WarrantiesModule lang={lang} />}
          {activeModule === 'maintenance' && <MaintenanceModule lang={lang} />}
          {activeModule === 'properties' && <PropertiesModule lang={lang} />}
          {activeModule === 'travel' && <TravelModule lang={lang} />}
          {activeModule === 'assistant' && <AssistantModule user={user} lang={lang} onUserUpdate={setUser} />}
          {activeModule === 'reports' && <ReportsModule lang={lang} />}
          {activeModule === 'contacts' && <ContactsModule lang={lang} />}
          {activeModule === 'vault' && <VaultModule lang={lang} />}
          {activeModule === 'favorites' && <FavoritesModule lang={lang} onNavigate={setActiveModule} />}
          {activeModule === 'backup' && <BackupModule lang={lang} />}
          {activeModule === 'icon_library' && <IconLibraryView lang={lang} />}
          {activeModule === 'widget_builder' && (
            <WidgetBuilderModule
              lang={lang}
              editingWidget={editingWidget}
              onSaved={() => {
                setEditingWidget(null);
                loadSummary();
                setActiveModule('dashboard');
              }}
            />
          )}
          {activeModule === 'custom_widget' && activeCustomWidget && (
            <CustomWidgetRunner
              widget={activeCustomWidget}
              lang={lang}
              onUpdate={loadSummary}
              onEdit={() => {
                setEditingWidget(activeCustomWidget);
                setActiveModule('widget_builder');
              }}
              onDelete={async () => {
                await apiFetch(`/api/widgets/${activeCustomWidget.id}`, { method: 'DELETE' });
                setActiveCustomWidget(null);
                loadSummary();
                setActiveModule('dashboard');
              }}
            />
          )}
          {activeModule === 'settings' && (
            <SettingsModule
              user={user}
              lang={lang}
              onUserUpdate={setUser}
              onNavigate={setActiveModule}
              onOpenInstall={() => setInstallModalOpen(true)}
              onLogout={handleLogout}
              pwa={pwa}
            />
          )}
          {activeModule === 'plans' && <PlansModule user={user} lang={lang} onUserUpdate={setUser} />}

          {activeModule === 'tools' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <GlassCard onClick={() => setActiveModule('icon_library')} className="p-5 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-[#FF7900]/18 text-[#FF7900] flex items-center justify-center">
                    <Sparkles size={22} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{t.iconLibrary}</h4>
                    <p className="text-xs opacity-60">{isAr ? '30 تصنيفًا · أيقونات متجهة قابلة للتخصيص' : '30 categories · Customizable SVGs'}</p>
                  </div>
                </GlassCard>

                <GlassCard
                  onClick={() => {
                    setEditingWidget(null);
                    setActiveModule('widget_builder');
                  }}
                  className="p-5 flex items-center gap-4"
                >
                  <div className="w-12 h-12 rounded-2xl bg-purple-500/18 text-purple-300 flex items-center justify-center">
                    <Plus size={22} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{t.widgetBuilder}</h4>
                    <p className="text-xs opacity-60">{isAr ? 'أنشئ أداة مخصصة تفاعلية على شاشتك' : 'Build interactive custom widgets'}</p>
                  </div>
                </GlassCard>

                <GlassCard onClick={() => setActiveModule('plans')} className="p-5 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/18 text-amber-400 flex items-center justify-center">
                    <Crown size={22} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{t.plans}</h4>
                    <p className="text-xs opacity-60">FREE · PLUS · FAMILY · BUSINESS</p>
                  </div>
                </GlassCard>

                <GlassCard onClick={() => setActiveModule('settings')} className="p-5 flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-500/18 text-blue-300 flex items-center justify-center">
                    <Settings size={22} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{t.settings}</h4>
                    <p className="text-xs opacity-60">{isAr ? 'المظهر، اللغة، الأجهزة، الخصوصية' : 'Theme, Language, Devices, Privacy'}</p>
                  </div>
                </GlassCard>

                <GlassCard
                  onClick={async () => {
                    const res = await apiFetch<{ logs: typeof activityLogs }>('/api/activity');
                    setActivityLogs(res.logs || []);
                    setActivityOpen(true);
                  }}
                  className="p-5 flex items-center gap-4"
                >
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/18 text-emerald-300 flex items-center justify-center">
                    <Activity size={22} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{isAr ? 'سجل العمليات' : 'Activity Log'}</h4>
                    <p className="text-xs opacity-60">{isAr ? 'مراجعة جميع العمليات الحديثة' : 'Audit recent account activity'}</p>
                  </div>
                </GlassCard>

                {!pwa.isInstalled && (
                  <GlassCard onClick={() => setInstallModalOpen(true)} className="p-5 flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-[#FF7900]/18 text-[#FF7900] flex items-center justify-center">
                      <Download size={22} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm">{isAr ? 'تثبيت التطبيق الذكي' : 'Smart PWA Install'}</h4>
                      <p className="text-xs opacity-60">Android · iPhone · iPad · Desktop</p>
                    </div>
                  </GlassCard>
                )}
              </div>

              <div className="space-y-3">
                <h4 className="text-sm font-bold opacity-75">{isAr ? 'جميع الأقسام' : 'All Modules'}</h4>
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3">
                  {CORE_SECTIONS.map((s) => (
                    <GlassCard
                      key={s.id}
                      onClick={() => setActiveModule(s.id)}
                      className="p-3.5 flex items-center gap-2.5"
                    >
                      <DynamicIcon name={s.icon} size={18} color={s.color} />
                      <span className="text-xs font-semibold truncate">{isAr ? s.ar : s.en}</span>
                    </GlassCard>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar: الرئيسية | المستندات | إضافة | التقارير | المزيد */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 h-16 bg-[#0d0d0f]/90 backdrop-blur-2xl border-t border-white/10 grid grid-cols-5 items-center px-1">
        <button
          onClick={() => setActiveModule('dashboard')}
          className={`flex flex-col items-center justify-center gap-1 min-h-[44px] cursor-pointer ${
            activeModule === 'dashboard' ? 'text-[#FF7900]' : 'text-white/60'
          }`}
        >
          <Home size={20} />
          <span className="text-[10px] font-semibold">{t.home}</span>
        </button>
        <button
          onClick={() => setActiveModule('documents')}
          className={`flex flex-col items-center justify-center gap-1 min-h-[44px] cursor-pointer ${
            activeModule === 'documents' ? 'text-[#FF7900]' : 'text-white/60'
          }`}
        >
          <FolderOpen size={20} />
          <span className="text-[10px] font-semibold">{t.documents}</span>
        </button>
        <div className="flex items-center justify-center">
          <button
            onClick={() => setQuickAddOpen(true)}
            aria-label={t.add}
            className="w-12 h-12 -mt-5 rounded-full bg-[#FF7900] text-white shadow-lg shadow-[#FF7900]/40 flex items-center justify-center border-2 border-[#080808] active:scale-95 transition cursor-pointer"
          >
            <Plus size={22} />
          </button>
        </div>
        <button
          onClick={() => setActiveModule('reports')}
          className={`flex flex-col items-center justify-center gap-1 min-h-[44px] cursor-pointer ${
            activeModule === 'reports' ? 'text-[#FF7900]' : 'text-white/60'
          }`}
        >
          <PieChart size={20} />
          <span className="text-[10px] font-semibold">{t.reports}</span>
        </button>
        <button
          onClick={() => setActiveModule('tools')}
          className={`flex flex-col items-center justify-center gap-1 min-h-[44px] cursor-pointer ${
            activeModule === 'tools' || activeModule === 'settings' ? 'text-[#FF7900]' : 'text-white/60'
          }`}
        >
          <LayoutGrid size={20} />
          <span className="text-[10px] font-semibold">{t.more}</span>
        </button>
      </nav>

      {/* Offline Indicator */}
      {!isOnline && (
        <div className="fixed bottom-20 lg:bottom-4 left-4 z-50 rounded-xl bg-amber-500 text-black px-3.5 py-2 text-xs font-bold shadow-xl flex items-center gap-2">
          <WifiOff size={15} />
          <span>{t.offlineBanner}</span>
        </div>
      )}

      {/* Quick Add Launcher Modal */}
      <GlassModal open={quickAddOpen} onClose={() => setQuickAddOpen(false)} title={t.quickAdd}>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[
            { id: 'documents' as ModuleId, ar: 'رفع مستند / مجلد', en: 'Document / Folder', icon: 'FolderPlus', color: '#38BDF8' },
            { id: 'expenses' as ModuleId, ar: 'مصروف / دخل', en: 'Expense / Income', icon: 'BarChart3', color: '#FF7900' },
            { id: 'purchases' as ModuleId, ar: 'عملية شراء', en: 'Purchase', icon: 'ShoppingCart', color: '#A3E635' },
            { id: 'calendar' as ModuleId, ar: 'موعد جديد', en: 'Appointment', icon: 'CalendarDays', color: '#EF4444' },
            { id: 'subscriptions' as ModuleId, ar: 'اشتراك جديد', en: 'Subscription', icon: 'Layers', color: '#F59E0B' },
            { id: 'tasks' as ModuleId, ar: 'مهمة / هدف', en: 'Task / Goal', icon: 'CheckSquare', color: '#FBBF24' },
            { id: 'widget_builder' as ModuleId, ar: 'أداة مخصصة', en: 'Custom Widget', icon: 'Sparkles', color: '#A855F7' },
          ].map((q) => (
            <button
              key={q.id}
              onClick={() => {
                setQuickAddOpen(false);
                if (q.id === 'widget_builder') setEditingWidget(null);
                setActiveModule(q.id);
              }}
              className="rounded-2xl bg-white/[0.05] hover:bg-white/10 border border-white/10 p-4 flex flex-col items-center gap-2 cursor-pointer transition"
            >
              <DynamicIcon name={q.icon} size={22} color={q.color} />
              <span className="text-xs font-semibold text-center">{isAr ? q.ar : q.en}</span>
            </button>
          ))}
        </div>
      </GlassModal>

      {/* Notifications Modal */}
      <GlassModal open={notifOpen} onClose={() => setNotifOpen(false)} title={isAr ? 'الإشعارات والتنبيهات' : 'Notifications'}>
        {notifications.length === 0 ? (
          <p className="text-sm opacity-65 text-center py-6">{isAr ? 'لا توجد إشعارات جديدة.' : 'No notifications.'}</p>
        ) : (
          <div className="space-y-2.5">
            {notifications.map((n) => (
              <div
                key={n.id}
                onClick={() => {
                  setNotifOpen(false);
                  if (n.link_module) setActiveModule(n.link_module as ModuleId);
                }}
                className="rounded-2xl bg-white/[0.04] border border-white/10 p-3.5 cursor-pointer hover:border-[#FF7900]/40"
              >
                <div className="flex items-center justify-between gap-2">
                  <h5 className="text-sm font-bold">{n.title}</h5>
                  <Check size={14} className="text-emerald-400" />
                </div>
                <p className="text-xs opacity-70 mt-1">{n.body}</p>
              </div>
            ))}
          </div>
        )}
      </GlassModal>

      {/* Activity Log Modal */}
      <GlassModal open={activityOpen} onClose={() => setActivityOpen(false)} title={isAr ? 'سجل العمليات' : 'Activity Log'}>
        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
          {activityLogs.map((l) => (
            <div key={l.id} className="rounded-xl bg-white/[0.04] border border-white/8 p-3 text-xs flex justify-between gap-3">
              <div>
                <p className="font-bold">{l.action}</p>
                <p className="opacity-60">{l.module} {l.details ? `· ${l.details}` : ''}</p>
              </div>
              <span className="font-mono-num opacity-55 shrink-0">{l.created_at.slice(0, 16).replace('T', ' ')}</span>
            </div>
          ))}
        </div>
      </GlassModal>

      {/* Smart PWA Install Modal */}
      <PWAInstallModal
        open={installModalOpen}
        onClose={() => setInstallModalOpen(false)}
        lang={lang}
        pwa={pwa}
      />
    </div>
  );
}
