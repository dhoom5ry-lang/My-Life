import { icons } from 'lucide-react';

export interface IconCategory {
  id: string;
  ar: string;
  en: string;
  keywords: string[];
}

export interface IconCatalogEntry {
  name: string;
  category: string;
  arLabel: string;
  keywords: string;
}

export const ICON_CATEGORIES: IconCategory[] = [
  { id: 'personal', ar: 'الحياة الشخصية', en: 'Personal Life', keywords: ['user', 'person', 'heart', 'smile', 'life', 'id', 'badge', 'crown', 'star', 'award', 'fingerprint', 'eye', 'hand', 'glasses'] },
  { id: 'home', ar: 'المنزل', en: 'Home', keywords: ['home', 'house', 'bed', 'sofa', 'lamp', 'door', 'key', 'bath', 'armchair', 'tv', 'fan', 'airvent', 'heater', 'blinds', 'building'] },
  { id: 'family', ar: 'العائلة', en: 'Family', keywords: ['users', 'baby', 'heart', 'handshake', 'gift', 'party', 'cake', 'smile', 'person', 'home'] },
  { id: 'finance', ar: 'المال والبنوك', en: 'Finance & Banking', keywords: ['wallet', 'bank', 'credit', 'coin', 'dollar', 'euro', 'pound', 'yen', 'landmark', 'piggy', 'receipt', 'vault', 'percent', 'currency', 'badge', 'circle-dollar'] },
  { id: 'shopping', ar: 'المشتريات', en: 'Shopping', keywords: ['shopping', 'cart', 'bag', 'tag', 'tags', 'barcode', 'qr', 'package', 'box', 'gift', 'ticket', 'store', 'scan'] },
  { id: 'business', ar: 'التجارة والأعمال', en: 'Business', keywords: ['briefcase', 'building', 'chart', 'trending', 'presentation', 'factory', 'scale', 'gavel', 'stamp', 'handshake', 'megaphone', 'newspaper', 'kanban'] },
  { id: 'travel', ar: 'السفر', en: 'Travel', keywords: ['plane', 'map', 'compass', 'globe', 'luggage', 'baggage', 'train', 'ship', 'anchor', 'tent', 'mountain', 'palmtree', 'passport', 'route', 'navigation'] },
  { id: 'cars', ar: 'السيارات', en: 'Automotive', keywords: ['car', 'truck', 'bus', 'bike', 'fuel', 'gauge', 'key', 'parking', 'traffic', 'wheel', 'wrench', 'milestone', 'tractor', 'ambulance'] },
  { id: 'health', ar: 'الصحة', en: 'Health', keywords: ['heart', 'pulse', 'activity', 'pill', 'syringe', 'stethoscope', 'thermometer', 'hospital', 'bandage', 'dna', 'brain', 'bone', 'apple', 'cross'] },
  { id: 'sports', ar: 'الرياضة', en: 'Sports', keywords: ['dumbbell', 'trophy', 'medal', 'flame', 'bike', 'footprints', 'timer', 'stopwatch', 'target', 'swords', 'flag', 'volleyball', 'waves'] },
  { id: 'education', ar: 'التعليم', en: 'Education', keywords: ['graduation', 'school', 'backpack', 'pencil', 'pen', 'ruler', 'compass', 'microscope', 'atom', 'flask', 'calculator', 'globe', 'presentation'] },
  { id: 'books', ar: 'الكتب', en: 'Books', keywords: ['book', 'bookmark', 'library', 'notebook', 'file-text', 'scroll', 'newspaper', 'feather', 'highlighter', 'quote'] },
  { id: 'tech', ar: 'التقنية', en: 'Technology', keywords: ['cpu', 'laptop', 'smartphone', 'tablet', 'monitor', 'server', 'harddrive', 'wifi', 'bluetooth', 'usb', 'battery', 'router', 'printer', 'keyboard', 'mouse', 'chip'] },
  { id: 'coding', ar: 'البرمجة', en: 'Programming', keywords: ['code', 'terminal', 'git', 'branch', 'bug', 'braces', 'brackets', 'database', 'webhook', 'regex', 'variable', 'binary', 'bot', 'blocks'] },
  { id: 'maintenance', ar: 'الصيانة', en: 'Maintenance', keywords: ['wrench', 'hammer', 'screwdriver', 'drill', 'paint', 'brush', 'axe', 'anvil', 'cog', 'settings', 'sliders', 'nut', 'bolt', 'plug'] },
  { id: 'food', ar: 'الطعام', en: 'Food', keywords: ['apple', 'banana', 'beef', 'cake', 'candy', 'carrot', 'cheese', 'cherry', 'cookie', 'croissant', 'egg', 'fish', 'grape', 'milk', 'pizza', 'salad', 'sandwich', 'soup', 'wheat'] },
  { id: 'restaurants', ar: 'المطاعم', en: 'Restaurants', keywords: ['utensils', 'coffee', 'cup', 'wine', 'beer', 'martini', 'chef', 'soup', 'flame', 'store', 'receipt', 'bell'] },
  { id: 'entertainment', ar: 'الترفيه', en: 'Entertainment', keywords: ['sparkles', 'party', 'ticket', 'tv', 'radio', 'drama', 'dice', 'puzzle', 'wand', 'ferris', 'tent', 'star'] },
  { id: 'gaming', ar: 'الألعاب', en: 'Gaming', keywords: ['gamepad', 'joystick', 'dice', 'trophy', 'swords', 'shield', 'crown', 'ghost', 'skull', 'rocket', 'puzzle', 'crosshair'] },
  { id: 'music', ar: 'الموسيقى', en: 'Music', keywords: ['music', 'headphones', 'mic', 'speaker', 'volume', 'disc', 'drum', 'guitar', 'piano', 'radio', 'audio', 'play', 'pause'] },
  { id: 'movies', ar: 'الأفلام', en: 'Movies', keywords: ['film', 'clapperboard', 'video', 'camera', 'projector', 'tv', 'popcorn', 'play', 'rewind', 'fast-forward', 'aperture', 'image'] },
  { id: 'nature', ar: 'الطبيعة', en: 'Nature', keywords: ['leaf', 'tree', 'flower', 'sprout', 'clover', 'mountain', 'waves', 'feather', 'bird', 'bug', 'cat', 'dog', 'fish', 'paw'] },
  { id: 'weather', ar: 'الطقس', en: 'Weather', keywords: ['sun', 'moon', 'cloud', 'rain', 'snow', 'wind', 'umbrella', 'zap', 'tornado', 'rainbow', 'sunrise', 'sunset', 'thermometer', 'droplet'] },
  { id: 'security', ar: 'الأمان', en: 'Security', keywords: ['lock', 'unlock', 'shield', 'key', 'fingerprint', 'scan', 'eye', 'alert', 'siren', 'cctv', 'vault', 'file-lock'] },
  { id: 'productivity', ar: 'الإنتاجية', en: 'Productivity', keywords: ['zap', 'rocket', 'layers', 'layout', 'grid', 'columns', 'kanban', 'workflow', 'sparkles', 'pin', 'filter', 'search', 'sliders'] },
  { id: 'goals', ar: 'الأهداف', en: 'Goals', keywords: ['target', 'flag', 'trophy', 'award', 'medal', 'crown', 'compass', 'mountain', 'trending-up', 'milestone', 'star', 'flame'] },
  { id: 'tasks', ar: 'المهام', en: 'Tasks', keywords: ['check', 'square', 'list', 'clipboard', 'todo', 'circle-check', 'repeat', 'pin', 'bell', 'tag', 'bookmark'] },
  { id: 'time', ar: 'الوقت والتقويم', en: 'Time & Calendar', keywords: ['calendar', 'clock', 'alarm', 'timer', 'hourglass', 'watch', 'history', 'sunrise', 'sunset'] },
  { id: 'files', ar: 'الملفات', en: 'Files', keywords: ['file', 'folder', 'archive', 'paperclip', 'upload', 'download', 'share', 'copy', 'scissors', 'trash', 'save', 'printer', 'inbox'] },
  { id: 'comms', ar: 'الاتصالات', en: 'Communications', keywords: ['phone', 'mail', 'message', 'send', 'at-sign', 'contact', 'voicemail', 'rss', 'share', 'bell', 'megaphone', 'globe', 'link'] },
];

const AR_KEYWORD_GLOSSARY: Record<string, string> = {
  user: 'مستخدم حساب شخص',
  home: 'منزل بيت سكن',
  folder: 'مجلد ملف مستند',
  file: 'ملف مستند وثيقة',
  calendar: 'تقويم موعد تاريخ',
  clock: 'ساعة وقت تذكير',
  wallet: 'محفظة مال ميزانية',
  credit: 'بطاقة دفع بنك',
  shopping: 'تسوق مشتريات سلة',
  cart: 'عربة تسوق',
  car: 'سيارة مركبة نقل',
  plane: 'طائرة سفر رحلة',
  heart: 'صحة قلب عناية مفضلة',
  shield: 'أمان حماية ضمان',
  lock: 'قفل كلمة مرور خصوصية',
  key: 'مفتاح دخول أمان',
  wrench: 'صيانة إصلاح أداة',
  star: 'نجمة مفضلة تميز',
  bell: 'إشعار تنبيه جرس',
  mail: 'بريد رسالة إلكتروني',
  phone: 'هاتف اتصال رقم',
  camera: 'كاميرا صورة تصوير',
  video: 'فيديو فيلم عرض',
  music: 'موسيقى صوت نغمة',
  book: 'كتاب قراءة تعليم',
  code: 'برمجة كود تقنية',
  sun: 'شمس طقس نهار',
  cloud: 'سحابة تخزين طقس',
  gift: 'هدية مكافأة',
  target: 'هدف إنجاز تركيز',
  check: 'مهمة منجز صح',
  chart: 'تقرير إحصائيات رسم بياني',
  building: 'عقار مبنى شركة',
  utensils: 'مطعم طعام أكل',
  coffee: 'قهوة مقهى مشروب',
  gamepad: 'ألعاب ترفيه',
  users: 'عائلة مجموعة فريق',
};

function buildArabicHints(pascalName: string): string {
  const lower = pascalName.toLowerCase();
  const hints: string[] = [];
  for (const [k, ar] of Object.entries(AR_KEYWORD_GLOSSARY)) {
    if (lower.includes(k)) hints.push(ar);
  }
  return hints.join(' ');
}

function buildCatalog(): IconCatalogEntry[] {
  const allIconNames = Object.keys(icons);
  const used = new Set<string>();
  const catalog: IconCatalogEntry[] = [];

  // First pass: assign best matching category for icons matching category keywords
  for (const cat of ICON_CATEGORIES) {
    let count = 0;
    for (const name of allIconNames) {
      if (used.has(name)) continue;
      const lower = name.toLowerCase();
      if (cat.keywords.some((kw) => lower.includes(kw.replace(/-/g, '')))) {
        used.add(name);
        catalog.push({
          name,
          category: cat.id,
          arLabel: `${cat.ar} · ${name}`,
          keywords: `${name} ${cat.ar} ${cat.en} ${buildArabicHints(name)}`.toLowerCase(),
        });
        count++;
        if (count >= 24) break;
      }
    }
  }

  // Second pass: ensure we have 600+ real icons distributed across categories
  let catIdx = 0;
  for (const name of allIconNames) {
    if (catalog.length >= 640) break;
    if (used.has(name)) continue;
    const cat = ICON_CATEGORIES[catIdx % ICON_CATEGORIES.length];
    catIdx++;
    used.add(name);
    catalog.push({
      name,
      category: cat.id,
      arLabel: `${cat.ar} · ${name}`,
      keywords: `${name} ${cat.ar} ${cat.en} ${buildArabicHints(name)}`.toLowerCase(),
    });
  }

  return catalog;
}

export const ICON_LIBRARY: IconCatalogEntry[] = buildCatalog();
