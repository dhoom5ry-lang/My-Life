import React from 'react';
import { X } from 'lucide-react';
import type { CardStyle } from '../types';

export const GlassCard: React.FC<{
  children: React.ReactNode;
  className?: string;
  cardStyle?: CardStyle;
  onClick?: () => void;
}> = ({ children, className = '', cardStyle = 'glass', onClick }) => {
  const base = cardStyle === 'classic' ? 'classic-panel' : 'glass-panel';
  return (
    <div
      onClick={onClick}
      className={`${base} rounded-3xl transition-all duration-200 ${onClick ? 'cursor-pointer hover:border-[#FF7900]/40' : ''} ${className}`}
    >
      {children}
    </div>
  );
};

export const GlassModal: React.FC<{
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  maxWidth?: string;
}> = ({ open, onClose, title, children, maxWidth = 'max-w-lg' }) => {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-md p-0 sm:p-4">
      <div
        className={`glass-panel glass-highlight w-full ${maxWidth} rounded-t-3xl sm:rounded-3xl max-h-[90vh] flex flex-col overflow-hidden`}
      >
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
          <h3 className="text-base sm:text-lg font-semibold truncate">{title}</h3>
          <button
            onClick={onClose}
            aria-label="Close modal"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>
        <div className="p-6 overflow-y-auto space-y-4">{children}</div>
      </div>
    </div>
  );
};

export const PrimaryButton: React.FC<
  React.ButtonHTMLAttributes<HTMLButtonElement> & { accentColor?: string }
> = ({ children, className = '', accentColor, style, ...rest }) => (
  <button
    {...rest}
    style={{ backgroundColor: accentColor || '#FF7900', ...style }}
    className={`min-h-[44px] px-5 py-2.5 rounded-xl text-white font-semibold text-sm inline-flex items-center justify-center gap-2 shadow-lg shadow-[#FF7900]/20 hover:brightness-110 active:scale-[0.98] transition whitespace-nowrap shrink-0 cursor-pointer disabled:opacity-50 ${className}`}
  >
    {children}
  </button>
);

export const InputField: React.FC<
  React.InputHTMLAttributes<HTMLInputElement> & { label?: string }
> = ({ label, className = '', ...rest }) => (
  <label className="block space-y-1.5">
    {label && <span className="block text-xs font-medium opacity-75">{label}</span>}
    <input
      {...rest}
      className={`w-full min-h-[44px] rounded-xl bg-white/[0.05] dark:bg-white/[0.05] border border-white/12 px-3.5 py-2 text-sm focus:outline-none focus:border-[#FF7900] transition ${className}`}
    />
  </label>
);

export const SelectField: React.FC<
  React.SelectHTMLAttributes<HTMLSelectElement> & { label?: string }
> = ({ label, className = '', children, ...rest }) => (
  <label className="block space-y-1.5">
    {label && <span className="block text-xs font-medium opacity-75">{label}</span>}
    <select
      {...rest}
      className={`w-full min-h-[44px] rounded-xl bg-[#18181b] text-white border border-white/12 px-3.5 py-2 text-sm focus:outline-none focus:border-[#FF7900] transition ${className}`}
    >
      {children}
    </select>
  </label>
);
