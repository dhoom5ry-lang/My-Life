import React, { useEffect, useRef, useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Download,
  FileText,
  Printer,
  Search,
  Share2,
  X,
  ZoomIn,
  ZoomOut,
  Check,
} from 'lucide-react';
import * as XLSX from 'xlsx';
import * as pdfjsLib from 'pdfjs-dist';
import pdfjsWorkerUrl from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import type { DocumentItem, Language } from '../types';
import { apiFetch } from '../lib/api';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorkerUrl;

interface DocumentViewerModalProps {
  doc: DocumentItem | null;
  onClose: () => void;
  lang: Language;
}

export const DocumentViewerModal: React.FC<DocumentViewerModalProps> = ({ doc, onClose, lang }) => {
  const isAr = lang === 'ar';
  const [zoom, setZoom] = useState(1.1);
  const [pageNum, setPageNum] = useState(1);
  const [numPages, setNumPages] = useState(1);
  const [pdfSearch, setPdfSearch] = useState('');
  const [pdfMatchPages, setPdfMatchPages] = useState<number[]>([]);
  const [textContent, setTextContent] = useState('');
  const [sheets, setSheets] = useState<{ name: string; rows: string[][] }[]>([]);
  const [activeSheet, setActiveSheet] = useState(0);
  const [shareCopied, setShareCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pdfDocRef = useRef<pdfjsLib.PDFDocumentProxy | null>(null);

  const ext = (doc?.ext || '').toLowerCase();
  const rawUrl = doc ? `/api/documents/${doc.id}/raw` : '';

  useEffect(() => {
    if (!doc) return;
    setZoom(1.1);
    setPageNum(1);
    setNumPages(1);
    setPdfSearch('');
    setPdfMatchPages([]);
    setTextContent('');
    setSheets([]);
    setActiveSheet(0);
    setErrorMsg('');

    let cancelled = false;

    const loadDoc = async () => {
      setLoading(true);
      try {
        if (ext === 'pdf') {
          const res = await fetch(rawUrl, { credentials: 'include' });
          const buf = await res.arrayBuffer();
          const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
          if (cancelled) return;
          pdfDocRef.current = pdf;
          setNumPages(pdf.numPages);
        } else if (['xlsx', 'csv'].includes(ext)) {
          const res = await fetch(rawUrl, { credentials: 'include' });
          const buf = await res.arrayBuffer();
          const wb = XLSX.read(buf, { type: 'array' });
          if (cancelled) return;
          const parsed = wb.SheetNames.map((name) => {
            const ws = wb.Sheets[name];
            const rows = XLSX.utils.sheet_to_json<string[]>(ws, { header: 1 }) as string[][];
            return { name, rows: rows.slice(0, 200) };
          });
          setSheets(parsed);
        } else if (['txt', 'json'].includes(ext)) {
          const res = await fetch(rawUrl, { credentials: 'include' });
          const txt = await res.text();
          if (!cancelled) setTextContent(txt);
        }
      } catch (err) {
        if (!cancelled) setErrorMsg((err as Error).message || 'Unable to preview document');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    if (['pdf', 'xlsx', 'csv', 'txt', 'json'].includes(ext)) {
      loadDoc();
    }

    return () => {
      cancelled = true;
    };
  }, [doc, ext, rawUrl]);

  useEffect(() => {
    if (ext !== 'pdf' || !pdfDocRef.current || !canvasRef.current) return;
    let cancelled = false;

    const renderPage = async () => {
      const page = await pdfDocRef.current!.getPage(pageNum);
      if (cancelled) return;
      const viewport = page.getViewport({ scale: zoom });
      const canvas = canvasRef.current!;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      canvas.height = viewport.height;
      canvas.width = viewport.width;
      await page.render({ canvasContext: ctx, viewport, canvas }).promise;
    };

    renderPage();
    return () => {
      cancelled = true;
    };
  }, [ext, pageNum, zoom, numPages]);

  if (!doc) return null;

  const handleSearchPdf = async () => {
    if (!pdfDocRef.current || !pdfSearch.trim()) {
      setPdfMatchPages([]);
      return;
    }
    const q = pdfSearch.trim().toLowerCase();
    const matches: number[] = [];
    for (let i = 1; i <= pdfDocRef.current.numPages; i++) {
      const page = await pdfDocRef.current.getPage(i);
      const tc = await page.getTextContent();
      const str = tc.items.map((it) => ('str' in it ? it.str : '')).join(' ').toLowerCase();
      if (str.includes(q)) matches.push(i);
    }
    setPdfMatchPages(matches);
    if (matches.length > 0) setPageNum(matches[0]);
  };

  const handleShare = async () => {
    try {
      const data = await apiFetch<{ shareToken: string }>(`/api/documents/${doc.id}/share`, { method: 'POST' });
      const shareUrl = `${window.location.origin}/api/shared/${data.shareToken}`;
      await navigator.clipboard.writeText(shareUrl);
      setShareCopied(true);
      setTimeout(() => setShareCopied(false), 2500);
    } catch {
      // ignore
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black/85 backdrop-blur-xl text-white">
      {/* Viewer Top Bar */}
      <div className="no-print flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3.5 border-b border-white/10 bg-[#111113]/90">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-[#FF7900]/15 border border-[#FF7900]/30 flex items-center justify-center text-[#FF7900] shrink-0">
            <FileText size={19} />
          </div>
          <div className="min-w-0">
            <h3 className="text-sm sm:text-base font-bold truncate">{doc.name}</h3>
            <p className="text-xs text-white/55 font-mono-num">
              .{ext.toUpperCase()} · {Math.max(1, Math.round(doc.size_bytes / 1024))} KB · {doc.updated_at.slice(0, 10)}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {ext === 'pdf' && (
            <>
              <div className="flex items-center gap-1 bg-white/8 rounded-xl px-2 py-1 border border-white/10">
                <input
                  value={pdfSearch}
                  onChange={(e) => setPdfSearch(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleSearchPdf()}
                  placeholder={isAr ? 'بحث داخل PDF...' : 'Search PDF...'}
                  className="bg-transparent text-xs w-28 sm:w-36 focus:outline-none px-1"
                />
                <button onClick={handleSearchPdf} className="p-1.5 hover:text-[#FF7900] cursor-pointer" title="Search">
                  <Search size={14} />
                </button>
                {pdfMatchPages.length > 0 && (
                  <span className="text-[11px] text-[#FF7900] font-mono-num px-1">
                    {pdfMatchPages.length}
                  </span>
                )}
              </div>

              <div className="flex items-center gap-1 bg-white/8 rounded-xl px-1.5 py-1 border border-white/10">
                <button
                  onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.15).toFixed(2)))}
                  className="p-1.5 hover:text-[#FF7900] cursor-pointer"
                  title="Zoom out"
                >
                  <ZoomOut size={15} />
                </button>
                <span className="text-xs font-mono-num px-1.5">{Math.round(zoom * 100)}%</span>
                <button
                  onClick={() => setZoom((z) => Math.min(2.5, +(z + 0.15).toFixed(2)))}
                  className="p-1.5 hover:text-[#FF7900] cursor-pointer"
                  title="Zoom in"
                >
                  <ZoomIn size={15} />
                </button>
              </div>

              <div className="flex items-center gap-1 bg-white/8 rounded-xl px-1.5 py-1 border border-white/10">
                <button
                  onClick={() => setPageNum((p) => Math.max(1, p - 1))}
                  disabled={pageNum <= 1}
                  className="p-1.5 disabled:opacity-35 hover:text-[#FF7900] cursor-pointer"
                >
                  <ChevronRight size={15} />
                </button>
                <span className="text-xs font-mono-num px-1.5">
                  {pageNum} / {numPages}
                </span>
                <button
                  onClick={() => setPageNum((p) => Math.min(numPages, p + 1))}
                  disabled={pageNum >= numPages}
                  className="p-1.5 disabled:opacity-35 hover:text-[#FF7900] cursor-pointer"
                >
                  <ChevronLeft size={15} />
                </button>
              </div>
            </>
          )}

          <a
            href={`${rawUrl}?download=1`}
            download={doc.original_name}
            className="min-h-[38px] px-3 rounded-xl bg-white/8 hover:bg-white/15 border border-white/10 text-xs font-medium inline-flex items-center gap-1.5 transition"
          >
            <Download size={14} />
            <span className="hidden sm:inline">{isAr ? 'تنزيل' : 'Download'}</span>
          </a>

          <button
            onClick={handleShare}
            className="min-h-[38px] px-3 rounded-xl bg-white/8 hover:bg-white/15 border border-white/10 text-xs font-medium inline-flex items-center gap-1.5 transition cursor-pointer"
          >
            {shareCopied ? <Check size={14} className="text-emerald-400" /> : <Share2 size={14} />}
            <span className="hidden sm:inline">
              {shareCopied ? (isAr ? 'تم النسخ' : 'Copied') : isAr ? 'مشاركة' : 'Share'}
            </span>
          </button>

          <button
            onClick={handlePrint}
            className="min-h-[38px] px-3 rounded-xl bg-white/8 hover:bg-white/15 border border-white/10 text-xs font-medium inline-flex items-center gap-1.5 transition cursor-pointer"
          >
            <Printer size={14} />
            <span className="hidden sm:inline">{isAr ? 'طباعة' : 'Print'}</span>
          </button>

          <button
            onClick={onClose}
            className="min-h-[38px] min-w-[38px] rounded-xl bg-white/10 hover:bg-red-500/20 hover:text-red-300 flex items-center justify-center transition cursor-pointer"
          >
            <X size={18} />
          </button>
        </div>
      </div>

      {/* Viewer Viewport */}
      <div className="flex-1 overflow-auto p-4 sm:p-8 flex items-start justify-center">
        {loading ? (
          <div className="self-center text-sm text-white/70">{isAr ? 'جارٍ تحميل المستند...' : 'Loading document...'}</div>
        ) : errorMsg ? (
          <div className="self-center glass-panel rounded-2xl p-6 max-w-md text-center space-y-3">
            <p className="text-sm text-red-300">{errorMsg}</p>
            <a
              href={`${rawUrl}?download=1`}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#FF7900] text-white text-xs font-semibold"
            >
              <Download size={14} />
              <span>{isAr ? 'تنزيل الملف مباشرة' : 'Download File'}</span>
            </a>
          </div>
        ) : ext === 'pdf' ? (
          <div className="rounded-2xl overflow-hidden shadow-2xl border border-white/10 bg-white">
            <canvas ref={canvasRef} />
          </div>
        ) : ['jpg', 'jpeg', 'png', 'webp'].includes(ext) ? (
          <div className="self-center flex flex-col items-center gap-4">
            <div className="flex items-center gap-2 bg-white/10 rounded-xl px-3 py-1.5">
              <button onClick={() => setZoom((z) => Math.max(0.4, z - 0.2))} className="p-1 cursor-pointer">
                <ZoomOut size={16} />
              </button>
              <span className="text-xs font-mono-num">{Math.round(zoom * 100)}%</span>
              <button onClick={() => setZoom((z) => Math.min(3, z + 0.2))} className="p-1 cursor-pointer">
                <ZoomIn size={16} />
              </button>
            </div>
            <img
              src={rawUrl}
              alt={doc.name}
              style={{ transform: `scale(${zoom})`, transformOrigin: 'center center' }}
              className="max-h-[75vh] max-w-full rounded-2xl shadow-2xl transition-transform"
            />
          </div>
        ) : ext === 'mp4' ? (
          <video src={rawUrl} controls className="self-center max-h-[80vh] max-w-4xl w-full rounded-2xl shadow-2xl bg-black" />
        ) : ['xlsx', 'csv'].includes(ext) && sheets.length > 0 ? (
          <div className="w-full max-w-5xl glass-panel rounded-2xl p-4 space-y-4">
            <div className="flex items-center gap-2 overflow-x-auto pb-1">
              {sheets.map((s, idx) => (
                <button
                  key={s.name}
                  onClick={() => setActiveSheet(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap cursor-pointer ${
                    activeSheet === idx ? 'bg-[#FF7900] text-white' : 'bg-white/8 text-white/70'
                  }`}
                >
                  {s.name}
                </button>
              ))}
            </div>
            <div className="overflow-auto max-h-[68vh]">
              <table className="w-full text-xs border-collapse">
                <tbody>
                  {sheets[activeSheet]?.rows.map((row, rIdx) => (
                    <tr key={rIdx} className={rIdx === 0 ? 'bg-white/10 font-bold' : 'border-t border-white/8 hover:bg-white/5'}>
                      {row.map((cell, cIdx) => (
                        <td key={cIdx} className="px-3 py-2 whitespace-nowrap">
                          {String(cell ?? '')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : ['txt', 'json'].includes(ext) ? (
          <pre className="w-full max-w-4xl glass-panel rounded-2xl p-6 text-sm leading-relaxed whitespace-pre-wrap font-sans">
            {textContent || doc.text_preview}
          </pre>
        ) : (
          <div className="self-center glass-panel rounded-3xl p-8 max-w-md text-center space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-[#FF7900]/15 border border-[#FF7900]/30 mx-auto flex items-center justify-center text-[#FF7900] font-mono font-bold text-lg">
              .{ext.toUpperCase()}
            </div>
            <h4 className="text-lg font-bold">{doc.original_name}</h4>
            <p className="text-xs text-white/65">
              {isAr
                ? 'ملف محفوظ وآمن داخل نظام MY LIFE. يمكنك تنزيله أو مشاركته مباشرة.'
                : 'File stored securely in MY LIFE. Download or share directly.'}
            </p>
            <a
              href={`${rawUrl}?download=1`}
              download={doc.original_name}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#FF7900] text-white text-sm font-semibold"
            >
              <Download size={16} />
              <span>{isAr ? 'تنزيل الملف' : 'Download File'}</span>
            </a>
          </div>
        )}
      </div>
    </div>
  );
};
