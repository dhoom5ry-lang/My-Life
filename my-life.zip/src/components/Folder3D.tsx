import React, { useRef, useState } from 'react';
import { MoreVertical, Star, Eye } from 'lucide-react';
import type { DocumentItem, FolderItem, Language } from '../types';
import { DynamicIcon } from './DynamicIcon';

interface Folder3DProps {
  folder: FolderItem;
  lang: Language;
  onOpenFolder: (folder: FolderItem) => void;
  onOpenDocument: (doc: DocumentItem) => void;
  onCustomize: (folder: FolderItem) => void;
  onToggleFavorite: (folder: FolderItem) => void;
}

function hexToRgba(hex: string, alpha: number): string {
  const clean = hex.replace('#', '');
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean.padEnd(6, '0').slice(0, 6);
  const r = parseInt(full.slice(0, 2), 16) || 255;
  const g = parseInt(full.slice(2, 4), 16) || 121;
  const b = parseInt(full.slice(4, 6), 16) || 0;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

export const Folder3D: React.FC<Folder3DProps> = ({
  folder,
  lang,
  onOpenFolder,
  onOpenDocument,
  onCustomize,
  onToggleFavorite,
}) => {
  const [hovered, setHovered] = useState(false);
  const longPressTimer = useRef<number | null>(null);
  const isAr = lang === 'ar';
  const alpha = Math.max(0.2, Math.min(1, (folder.opacity ?? 84) / 100));
  const isGlass = folder.style !== 'classic';

  const previewDocs = folder.preview_docs || [];
  const sheets = previewDocs.length > 0 ? previewDocs.slice(0, 3) : [];

  const handleTouchStart = () => {
    longPressTimer.current = window.setTimeout(() => {
      setHovered((prev) => !prev);
    }, 360);
  };

  const handleTouchEnd = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const isLightColor = folder.color_hex.toLowerCase() === '#ffffff' || folder.color_hex.toLowerCase() === '#facc15';

  return (
    <div
      className="group relative flex flex-col items-center select-none pt-10 pb-2"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Interactive 3D Folder Stage */}
      <div
        onClick={() => onOpenFolder(folder)}
        className="relative w-full max-w-[196px] h-[146px] cursor-pointer"
        style={{ perspective: '900px' }}
      >
        {/* Top Action Controls (Favorite / Preview on mobile / Customize) */}
        <div
          className="absolute -top-8 right-1 left-1 z-30 flex items-center justify-between opacity-90 sm:opacity-0 sm:group-hover:opacity-100 transition-opacity duration-200"
          onClick={(e) => e.stopPropagation()}
        >
          <button
            type="button"
            onClick={() => onToggleFavorite(folder)}
            title={isAr ? 'تفضيل' : 'Favorite'}
            className="w-8 h-8 rounded-full bg-black/55 backdrop-blur-md border border-white/15 flex items-center justify-center text-white/75 hover:text-amber-400 transition cursor-pointer"
          >
            <Star size={14} fill={folder.is_favorite ? '#FACC15' : 'none'} className={folder.is_favorite ? 'text-amber-400' : ''} />
          </button>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setHovered((v) => !v)}
              title={isAr ? 'معاينة الأوراق' : 'Preview Papers'}
              className="sm:hidden w-8 h-8 rounded-full bg-black/55 backdrop-blur-md border border-white/15 flex items-center justify-center text-white/75 hover:text-[#FF7900] transition cursor-pointer"
            >
              <Eye size={14} />
            </button>
            <button
              type="button"
              onClick={() => onCustomize(folder)}
              title={isAr ? 'تخصيص المجلد' : 'Customize Folder'}
              className="w-8 h-8 rounded-full bg-black/55 backdrop-blur-md border border-white/15 flex items-center justify-center text-white/75 hover:text-white transition cursor-pointer"
            >
              <MoreVertical size={14} />
            </button>
          </div>
        </div>

        {/* 1. Rear Folder Tab + Back Plate */}
        <div
          className="absolute inset-x-0 top-3 bottom-0 rounded-2xl transition-all duration-300"
          style={{
            background: isGlass
              ? `linear-gradient(160deg, ${hexToRgba(folder.color_hex, alpha * 0.65)}, ${hexToRgba(folder.color_hex, alpha * 0.35)})`
              : hexToRgba(folder.color_hex, 0.85),
            backdropFilter: isGlass ? 'blur(16px)' : undefined,
            border: `1px solid ${hexToRgba(folder.color_hex, 0.45)}`,
            boxShadow: hovered
              ? `0 22px 42px -12px ${hexToRgba(folder.color_hex, 0.48)}`
              : '0 14px 26px -14px rgba(0,0,0,0.65)',
          }}
        >
          {/* Folder Top Tab */}
          <div
            className="absolute -top-3.5 right-3 w-20 h-5 rounded-t-xl border-t border-x"
            style={{
              background: hexToRgba(folder.color_hex, isGlass ? alpha * 0.72 : 0.92),
              borderColor: hexToRgba(folder.color_hex, 0.45),
            }}
          />
        </div>

        {/* 2. Emerging Real Paper Sheets Inside Folder */}
        <div className="absolute inset-x-3 top-4 bottom-3 z-10 pointer-events-none">
          {sheets.length === 0 ? (
            <>
              <div
                className="absolute inset-x-2 top-2 bottom-2 rounded-xl bg-white/85 border border-black/10 shadow-md transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]"
                style={{
                  transform: hovered ? 'translateY(-22px) rotate(-3deg)' : 'translateY(0px) rotate(0deg)',
                }}
              >
                <div className="p-2.5 space-y-1.5 opacity-45">
                  <div className="h-1.5 w-3/4 rounded bg-slate-400" />
                  <div className="h-1.5 w-1/2 rounded bg-slate-300" />
                </div>
              </div>
              <div
                className="absolute inset-x-1 top-3 bottom-1 rounded-xl bg-white/95 border border-black/10 shadow-md transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]"
                style={{
                  transform: hovered ? 'translateY(-30px) rotate(2deg)' : 'translateY(2px) rotate(0deg)',
                }}
              >
                <div className="p-3 text-[10px] font-medium text-slate-500 text-center mt-2">
                  {isAr ? 'مجلد جاهز لملفاتك' : 'Ready for documents'}
                </div>
              </div>
            </>
          ) : (
            sheets.map((doc, idx) => {
              const total = sheets.length;
              const spreadOffset = idx - (total - 1) / 2;
              const restY = idx * 3;
              const hoverY = -30 - (total - 1 - idx) * 14;
              const hoverRotate = spreadOffset * 5.5;
              const hoverX = spreadOffset * 10;
              const isImage = ['jpg', 'jpeg', 'png', 'webp'].includes(doc.ext.toLowerCase());

              return (
                <div
                  key={doc.id}
                  onClick={(e) => {
                    if (hovered) {
                      e.stopPropagation();
                      onOpenDocument(doc);
                    }
                  }}
                  className="pointer-events-auto absolute inset-x-1 top-1 bottom-2 rounded-xl bg-[#fafafa] text-slate-900 border border-black/10 shadow-lg overflow-hidden transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]"
                  style={{
                    zIndex: 10 + idx,
                    transform: hovered
                      ? `translate(${hoverX}px, ${hoverY}px) rotate(${hoverRotate}deg) scale(1.02)`
                      : `translate(0px, ${restY}px) rotate(${spreadOffset * 1.5}deg) scale(${0.96 + idx * 0.015})`,
                  }}
                >
                  <div className="h-full p-2.5 flex flex-col justify-between bg-gradient-to-b from-white to-slate-100">
                    <div className="flex items-center justify-between gap-1 border-b border-slate-200 pb-1">
                      <span className="text-[10px] font-bold truncate max-w-[115px] text-slate-800">{doc.name}</span>
                      <span className="text-[9px] font-mono font-semibold uppercase text-[#FF7900]">
                        {doc.ext}
                      </span>
                    </div>
                    {isImage ? (
                      <div className="my-1 flex-1 rounded-md overflow-hidden bg-slate-200">
                        <img
                          src={`/api/documents/${doc.id}/raw`}
                          alt={doc.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    ) : (
                      <p className="text-[8.5px] leading-relaxed text-slate-600 line-clamp-3 mt-1 font-medium">
                        {doc.text_preview || `${doc.original_name} · ${Math.max(1, Math.round(doc.size_bytes / 1024))} KB`}
                      </p>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* 3. Front 3D Translucent Glass Pocket */}
        <div
          className="absolute inset-x-0 bottom-0 h-[100px] z-20 rounded-2xl p-3.5 flex flex-col justify-between transition-transform duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]"
          style={{
            transformOrigin: 'bottom center',
            transform: hovered ? 'rotateX(-18deg) translateY(4px)' : 'rotateX(0deg) translateY(0px)',
            background: isGlass
              ? `linear-gradient(145deg, ${hexToRgba(folder.color_hex, alpha * 0.78)} 0%, ${hexToRgba(folder.color_hex, alpha * 0.46)} 60%, rgba(18,18,20,${alpha * 0.85}) 100%)`
              : hexToRgba(folder.color_hex, 0.95),
            backdropFilter: isGlass ? 'blur(18px) saturate(150%)' : undefined,
            border: '1px solid rgba(255,255,255,0.28)',
            boxShadow:
              'inset 0 1.5px 0 0 rgba(255,255,255,0.38), inset 0 -10px 20px rgba(0,0,0,0.18), 0 10px 24px -8px rgba(0,0,0,0.55)',
          }}
        >
          {/* Soft Glass Specular Reflection */}
          {isGlass && (
            <div className="pointer-events-none absolute inset-x-2 top-1 h-6 rounded-t-xl bg-gradient-to-b from-white/25 to-transparent" />
          )}

          <div className="relative flex items-center justify-between">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center border border-white/20 shadow-inner"
              style={{ backgroundColor: isLightColor ? 'rgba(0,0,0,0.12)' : 'rgba(255,255,255,0.14)' }}
            >
              <DynamicIcon
                name={folder.icon_name || 'Folder'}
                size={19}
                color={isLightColor ? '#111111' : '#FFFFFF'}
              />
            </div>
            <span
              className={`text-[11px] font-mono-num font-semibold ${
                isLightColor ? 'text-slate-900/80' : 'text-white/85'
              }`}
            >
              {folder.file_count} {isAr ? 'ملف' : 'files'}
            </span>
          </div>

          <div className="relative flex items-end justify-between gap-2">
            <h4
              className={`text-sm font-bold truncate ${
                isLightColor ? 'text-slate-950' : 'text-white drop-shadow-sm'
              }`}
            >
              {folder.name}
            </h4>
          </div>
        </div>
      </div>

      {/* File count caption below folder */}
      <div className="mt-2.5 text-center">
        <p className="text-xs opacity-60 font-mono-num">
          {folder.file_count} {isAr ? 'ملف محفوظ' : 'documents'}
        </p>
      </div>
    </div>
  );
};
