import React, { useEffect, useMemo, useState } from 'react';
import { Search, Star, Clock, Check } from 'lucide-react';
import { ICON_CATEGORIES, ICON_LIBRARY } from '../data/iconLibrary';
import { DynamicIcon } from './DynamicIcon';
import { GlassCard, GlassModal, PrimaryButton } from './GlassUI';
import { apiFetch } from '../lib/api';
import type { IconShape, Language } from '../types';

interface IconLibraryViewProps {
  lang: Language;
  selectionMode?: boolean;
  initialIcon?: string;
  initialColor?: string;
  initialShape?: IconShape;
  onSelect?: (result: { icon: string; color: string; size: number; shape: IconShape }) => void;
}

const PRESET_COLORS = ['#FF7900', '#3B82F6', '#8B5CF6', '#10B981', '#F59E0B', '#EC4899', '#EF4444', '#FFFFFF', '#94A3B8'];

export const IconLibraryView: React.FC<IconLibraryViewProps> = ({
  lang,
  selectionMode = false,
  initialIcon = 'Sparkles',
  initialColor = '#FF7900',
  initialShape = 'squircle',
  onSelect,
}) => {
  const isAr = lang === 'ar';
  const [query, setQuery] = useState('');
  const [activeCat, setActiveCat] = useState<string>('all');
  const [selectedIcon, setSelectedIcon] = useState(initialIcon);
  const [color, setColor] = useState(initialColor);
  const [size, setSize] = useState(26);
  const [shape, setShape] = useState<IconShape>(initialShape);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [recent, setRecent] = useState<string[]>([]);
  const [savedNotice, setSavedNotice] = useState(false);

  useEffect(() => {
    apiFetch<{ favorites: string[]; recent: string[] }>('/api/icons/prefs')
      .then((res) => {
        setFavorites(res.favorites || []);
        setRecent(res.recent || []);
      })
      .catch(() => {});
  }, []);

  const persistPrefs = async (nextFav: string[], nextRecent: string[]) => {
    try {
      await apiFetch('/api/icons/prefs', {
        method: 'PUT',
        body: JSON.stringify({ favorites: nextFav, recent: nextRecent }),
      });
    } catch {
      // ignore
    }
  };

  const toggleFavorite = (iconName: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const next = favorites.includes(iconName) ? favorites.filter((f) => f !== iconName) : [iconName, ...favorites];
    setFavorites(next);
    persistPrefs(next, recent);
  };

  const handlePickIcon = (iconName: string) => {
    setSelectedIcon(iconName);
    const nextRecent = [iconName, ...recent.filter((r) => r !== iconName)].slice(0, 24);
    setRecent(nextRecent);
    persistPrefs(favorites, nextRecent);
  };

  const filteredIcons = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = ICON_LIBRARY;
    if (activeCat === 'favorites') {
      list = list.filter((i) => favorites.includes(i.name));
    } else if (activeCat === 'recent') {
      list = recent
        .map((r) => ICON_LIBRARY.find((i) => i.name === r))
        .filter((v): v is NonNullable<typeof v> => Boolean(v));
    } else if (activeCat !== 'all') {
      list = list.filter((i) => i.category === activeCat);
    }
    if (q) {
      list = list.filter((i) => i.keywords.includes(q) || i.name.toLowerCase().includes(q));
    }
    return list;
  }, [query, activeCat, favorites, recent]);

  const shapeRadius =
    shape === 'circle'
      ? 'rounded-full'
      : shape === 'squircle'
      ? 'rounded-2xl'
      : shape === 'rounded'
      ? 'rounded-xl'
      : 'rounded-none';

  const handleSave = () => {
    if (onSelect) {
      onSelect({ icon: selectedIcon, color, size, shape });
    } else {
      setSavedNotice(true);
      setTimeout(() => setSavedNotice(false), 2000);
    }
  };

  return (
    <div className="space-y-5">
      {/* Live Preview & Customizer Bar */}
      <GlassCard className="p-4 sm:p-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div
              className={`w-16 h-16 ${shapeRadius} flex items-center justify-center border border-white/15 bg-white/[0.06] shrink-0 shadow-lg`}
            >
              <DynamicIcon name={selectedIcon} size={size} color={color} />
            </div>
            <div>
              <p className="text-xs opacity-60">{isAr ? 'المعاينة المباشرة للأيقونة' : 'Live Icon Preview'}</p>
              <h4 className="text-base font-bold font-mono">{selectedIcon}</h4>
              <p className="text-xs text-[#FF7900] mt-0.5 font-mono-num">
                {ICON_LIBRARY.length}+ {isAr ? 'أيقونة متجهة حقيقية · 30 تصنيفًا' : 'Vector Icons · 30 Categories'}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5">
              {PRESET_COLORS.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setColor(c)}
                  className={`w-6 h-6 rounded-full border cursor-pointer transition ${
                    color.toLowerCase() === c.toLowerCase() ? 'ring-2 ring-white scale-110' : 'border-white/25'
                  }`}
                  style={{ backgroundColor: c }}
                />
              ))}
              <input
                type="color"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                className="w-7 h-7 rounded-lg bg-transparent cursor-pointer"
                title={isAr ? 'عجلة الألوان' : 'Color Wheel'}
              />
              <input
                type="text"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                className="w-20 min-h-[34px] rounded-lg bg-white/8 border border-white/12 px-2 text-xs font-mono"
              />
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs opacity-70">{isAr ? 'الحجم' : 'Size'}</span>
              <input
                type="range"
                min={16}
                max={42}
                value={size}
                onChange={(e) => setSize(Number(e.target.value))}
                className="w-24 accent-[#FF7900]"
              />
            </div>

            <div className="flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10">
              {(['squircle', 'circle', 'rounded', 'sharp'] as IconShape[]).map((sh) => (
                <button
                  key={sh}
                  type="button"
                  onClick={() => setShape(sh)}
                  className={`px-2.5 py-1 rounded-lg text-xs cursor-pointer transition ${
                    shape === sh ? 'bg-[#FF7900] text-white' : 'text-white/65 hover:text-white'
                  }`}
                >
                  {sh}
                </button>
              ))}
            </div>

            <PrimaryButton onClick={handleSave}>
              {savedNotice ? <Check size={16} /> : null}
              <span>
                {selectionMode
                  ? isAr
                    ? 'اعتماد الأيقونة'
                    : 'Use Icon'
                  : savedNotice
                  ? isAr
                    ? 'تم الحفظ'
                    : 'Saved'
                  : isAr
                  ? 'حفظ الاختيار'
                  : 'Save Selection'}
              </span>
            </PrimaryButton>
          </div>
        </div>
      </GlassCard>

      {/* Search & Category Tabs */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute top-3.5 right-3.5 opacity-50" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={isAr ? 'ابحث باسم الأيقونة أو الكلمة المرتبطة (مثال: مال، سفر، home, wallet)...' : 'Search icon name or keyword...'}
            className="w-full min-h-[44px] rounded-xl bg-white/[0.06] border border-white/12 pr-10 pl-4 text-sm focus:outline-none focus:border-[#FF7900]"
          />
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveCat('favorites')}
            className={`min-h-[44px] px-3.5 rounded-xl border text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer ${
              activeCat === 'favorites' ? 'bg-[#FF7900] border-[#FF7900] text-white' : 'bg-white/5 border-white/10'
            }`}
          >
            <Star size={14} />
            <span>{isAr ? `المفضلة (${favorites.length})` : `Favorites (${favorites.length})`}</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveCat('recent')}
            className={`min-h-[44px] px-3.5 rounded-xl border text-xs font-medium inline-flex items-center gap-1.5 cursor-pointer ${
              activeCat === 'recent' ? 'bg-[#FF7900] border-[#FF7900] text-white' : 'bg-white/5 border-white/10'
            }`}
          >
            <Clock size={14} />
            <span>{isAr ? 'المستخدمة مؤخرًا' : 'Recent'}</span>
          </button>
        </div>
      </div>

      {/* 30 Categories Scroller */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        <button
          type="button"
          onClick={() => setActiveCat('all')}
          className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition ${
            activeCat === 'all' ? 'bg-[#FF7900] text-white' : 'bg-white/6 hover:bg-white/12 text-white/75'
          }`}
        >
          {isAr ? `الكل (${ICON_LIBRARY.length})` : `All (${ICON_LIBRARY.length})`}
        </button>
        {ICON_CATEGORIES.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => setActiveCat(c.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 cursor-pointer transition ${
              activeCat === c.id ? 'bg-[#FF7900] text-white' : 'bg-white/6 hover:bg-white/12 text-white/75'
            }`}
          >
            {isAr ? c.ar : c.en}
          </button>
        ))}
      </div>

      {/* Icons Grid */}
      <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 lg:grid-cols-10 gap-2.5 max-h-[460px] overflow-y-auto p-1">
        {filteredIcons.map((entry) => {
          const isSelected = selectedIcon === entry.name;
          const isFav = favorites.includes(entry.name);
          return (
            <div
              key={entry.name}
              onClick={() => handlePickIcon(entry.name)}
              className={`group relative rounded-2xl p-3 flex flex-col items-center justify-center gap-1.5 border transition cursor-pointer ${
                isSelected
                  ? 'bg-[#FF7900]/18 border-[#FF7900] shadow-lg shadow-[#FF7900]/15'
                  : 'bg-white/[0.04] border-white/8 hover:bg-white/[0.08] hover:border-white/20'
              }`}
              title={entry.arLabel}
            >
              <button
                type="button"
                onClick={(e) => toggleFavorite(entry.name, e)}
                className="absolute top-1.5 left-1.5 opacity-0 group-hover:opacity-100 transition"
              >
                <Star size={11} fill={isFav ? '#FACC15' : 'none'} className={isFav ? 'text-amber-400' : 'text-white/50'} />
              </button>
              <div className={`${shapeRadius} p-1.5`}>
                <DynamicIcon name={entry.name} size={22} color={isSelected ? color : '#E5E7EB'} />
              </div>
              <span className="text-[10px] opacity-65 truncate w-full text-center font-mono">{entry.name}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const IconPickerModal: React.FC<{
  open: boolean;
  onClose: () => void;
  lang: Language;
  initialIcon?: string;
  initialColor?: string;
  onSelect: (result: { icon: string; color: string; size: number; shape: IconShape }) => void;
}> = ({ open, onClose, lang, initialIcon, initialColor, onSelect }) => (
  <GlassModal
    open={open}
    onClose={onClose}
    title={lang === 'ar' ? 'مكتبة الأيقونات (500+ أيقونة)' : 'Icon Library (500+ Icons)'}
    maxWidth="max-w-4xl"
  >
    <IconLibraryView
      lang={lang}
      selectionMode
      initialIcon={initialIcon}
      initialColor={initialColor}
      onSelect={(res) => {
        onSelect(res);
        onClose();
      }}
    />
  </GlassModal>
);
