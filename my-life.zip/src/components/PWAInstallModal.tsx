import React, { useState } from 'react';
import { CheckCircle2, Download, PlusSquare, Share, Smartphone, X, AlertTriangle } from 'lucide-react';
import type { Language } from '../types';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallModalProps {
  open: boolean;
  onClose: () => void;
  lang: Language;
  pwa: ReturnType<typeof usePWAInstall>;
}

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({ open, onClose, lang, pwa }) => {
  const [showGuide, setShowGuide] = useState(false);
  const [verifyMsg, setVerifyMsg] = useState('');

  if (!open) return null;

  const isAr = lang === 'ar';

  const handleInstallClick = async () => {
    if (pwa.isInstallable) {
      const outcome = await pwa.install();
      if (outcome === 'accepted') {
        setVerifyMsg(isAr ? 'تم تثبيت MY LIFE بنجاح!' : 'MY LIFE installed successfully!');
      }
      return;
    }
    setShowGuide(true);
  };

  const handleVerify = () => {
    const ok = pwa.recheckInstalled();
    setVerifyMsg(
      ok
        ? isAr
          ? 'تم التحقق: التطبيق يعمل الآن بوضع Standalone المثبت!'
          : 'Verified: MY LIFE is running in installed standalone mode!'
        : isAr
          ? 'افتح التطبيق من أيقونة الشاشة الرئيسية بعد إتمام الخطوات لإكمال التحقق.'
          : 'Launch MY LIFE from your Home Screen icon after completing the steps to verify.'
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/65 backdrop-blur-md p-4">
      <div className="glass-panel glass-highlight w-full max-w-md rounded-3xl p-6 text-white animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <img
              src="/icon-192.png"
              alt="MY LIFE"
              className="w-14 h-14 rounded-2xl border border-[#FF7900]/40 shadow-lg shadow-[#FF7900]/20 shrink-0"
            />
            <div>
              <h3 className="text-lg font-bold tracking-tight">
                {pwa.isIOS ? 'Add MY LIFE to Home Screen' : 'Install MY LIFE'}
              </h3>
              <p className="text-xs text-white/65 mt-0.5">
                {isAr
                  ? 'احصل على تجربة تطبيق أصلي سريع على جهازك مع دعم العمل دون اتصال.'
                  : 'Get a native-feel experience on your device with offline support.'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Close"
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-white/60 hover:text-white hover:bg-white/10 transition"
          >
            <X size={18} />
          </button>
        </div>

        {pwa.justInstalled || pwa.isInstalled ? (
          <div className="mt-5 rounded-2xl bg-emerald-500/15 border border-emerald-500/30 p-4 flex items-center gap-3">
            <CheckCircle2 className="text-emerald-400 shrink-0" size={22} />
            <p className="text-sm text-emerald-100">
              {isAr ? 'تم تثبيت تطبيق MY LIFE بنجاح وهو جاهز على شاشتك الرئيسية.' : 'MY LIFE is installed and ready on your Home Screen.'}
            </p>
          </div>
        ) : (
          <>
            {pwa.isIOS && !pwa.isSafariOnIOS && (
              <div className="mt-4 rounded-2xl bg-amber-500/15 border border-amber-500/30 p-3.5 flex items-start gap-2.5 text-xs text-amber-100">
                <AlertTriangle size={16} className="text-amber-400 shrink-0 mt-0.5" />
                <span>
                  {isAr
                    ? 'على أجهزة iPhone وiPad، يجب فتح الرابط في متصفح Safari لتفعيل خيار الإضافة للشاشة الرئيسية.'
                    : 'On iPhone and iPad, please open this site in Safari to enable Add to Home Screen.'}
                </span>
              </div>
            )}

            {(showGuide || pwa.isIOS) && (
              <div className="mt-4 space-y-2.5 rounded-2xl bg-white/[0.04] border border-white/10 p-4 text-xs text-white/85">
                {pwa.isIOS ? (
                  <>
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-[#FF7900]/20 text-[#FF7900] flex items-center justify-center font-bold shrink-0">1</span>
                      <span className="flex items-center gap-1.5">
                        {isAr ? 'افتح الصفحة في Safari واضغط زر المشاركة' : 'Open in Safari and tap the Share button'}
                        <Share size={14} className="text-[#FF7900]" />
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-[#FF7900]/20 text-[#FF7900] flex items-center justify-center font-bold shrink-0">2</span>
                      <span className="flex items-center gap-1.5">
                        {isAr ? 'مرّر واختر "إضافة إلى الشاشة الرئيسية"' : 'Scroll and tap "Add to Home Screen"'}
                        <PlusSquare size={14} className="text-[#FF7900]" />
                      </span>
                    </div>
                    <div className="flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-full bg-[#FF7900]/20 text-[#FF7900] flex items-center justify-center font-bold shrink-0">3</span>
                      <span>{isAr ? 'اضغط "إضافة" في الزاوية العلوية لتأكيد التثبيت.' : 'Tap "Add" in the top corner to confirm.'}</span>
                    </div>
                  </>
                ) : (
                  <div className="flex items-start gap-2.5">
                    <Smartphone size={18} className="text-[#FF7900] shrink-0 mt-0.5" />
                    <p>
                      {isAr
                        ? 'افتح قائمة المتصفح (⋮) واختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية" لإضافة أيقونة MY LIFE.'
                        : 'Open your browser menu and choose "Install app" or "Add to Home screen" to install MY LIFE.'}
                    </p>
                  </div>
                )}
              </div>
            )}

            {verifyMsg && (
              <p className="mt-3 text-xs text-white/80 bg-white/5 border border-white/10 rounded-xl px-3 py-2">
                {verifyMsg}
              </p>
            )}

            <div className="mt-5 flex items-center gap-2.5">
              {!pwa.isIOS ? (
                <button
                  onClick={handleInstallClick}
                  className="flex-1 min-h-[44px] rounded-xl bg-[#FF7900] hover:bg-[#FF8F29] text-white font-semibold text-sm flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  <Download size={17} />
                  <span>{isAr ? 'تثبيت التطبيق' : 'Install App'}</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={() => setShowGuide(true)}
                    className="flex-1 min-h-[44px] rounded-xl bg-[#FF7900] hover:bg-[#FF8F29] text-white font-semibold text-sm flex items-center justify-center gap-2 transition cursor-pointer"
                  >
                    <PlusSquare size={17} />
                    <span>{isAr ? 'طريقة التثبيت' : 'How to Install'}</span>
                  </button>
                  <button
                    onClick={handleVerify}
                    className="min-h-[44px] px-4 rounded-xl bg-white/10 hover:bg-white/15 text-white text-xs font-medium transition cursor-pointer"
                  >
                    {isAr ? 'تحقق من التثبيت' : 'Verify'}
                  </button>
                </>
              )}
              <button
                onClick={onClose}
                className="min-h-[44px] px-4 rounded-xl bg-white/8 hover:bg-white/12 text-white/75 text-sm font-medium transition cursor-pointer"
              >
                {isAr ? 'لاحقًا' : 'Later'}
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
