import React from 'react';
import { icons } from 'lucide-react';

interface DynamicIconProps {
  name: string;
  size?: number;
  color?: string;
  className?: string;
  strokeWidth?: number;
}

export const DynamicIcon: React.FC<DynamicIconProps> = ({
  name,
  size = 22,
  color,
  className = '',
  strokeWidth = 1.9,
}) => {
  const iconMap = icons as Record<string, React.ComponentType<{ size?: number; color?: string; className?: string; strokeWidth?: number }>>;
  const IconComp = iconMap[name] || iconMap['Sparkles'] || iconMap['Folder'];
  if (!IconComp) return null;
  return <IconComp size={size} color={color} className={className} strokeWidth={strokeWidth} />;
};
