import React, { useState } from 'react';
import { CalendarDays, FolderOpen, BarChart3, ArrowLeft, ArrowRight, Globe } from 'lucide-react';
import { apiFetch, setAuthToken } from '../lib/api';
import type { Language, User } from '../types';
import { InputField, PrimaryButton } from './GlassUI';

interface AuthOnboardingProps {
  lang: Language;
  onChangeLang: (l: Language) => void;
  onAuthenticated: (user: User) => void;
}

export const AuthOnboarding: React.FC<AuthOnboardingProps> = ({ lang, onChangeLang, onAuthenticated }) => {
  const isAr = lang === 'ar';
  const [step, setStep] = useState<'onboarding' | 'auth'>('auth');
  const [slide, setSlide] = useState(0);
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const slides = [
    {
      icon: FolderOpen,
      color: '#8B5CF6',
      arTitle: 'نظّم مستنداتك',
      enTitle: 'Organize Your Documents',
      arDesc: 'احفظ ملفاتك ومستنداتك داخل مجلدات زجاجية ثلاثية الأبعاد مع معاينة فورية للأوراق.',
      enDesc: 'Store files inside interactive 3D glass folders with live paper hover previews.',
    },
    {
      icon: CalendarDays,
      color: '#EC4899',
      arTitle: 'إدارة مواعيدك',
      enTitle: 'Manage Your Schedule',
      arDesc: 'تابع مواعيدك ومهامك وتذكيراتك اليومية والعائلية بسهولة في مكان واحد.',
      enDesc: 'Track appointments, tasks, and shared family schedules effortlessly.',
    },
    {
      icon: BarChart3,
      color: '#FF7900',
      arTitle: 'تحكّم في مصروفاتك',
      enTitle: 'Control Your Finances',
      arDesc: 'تابع مصروفاتك وميزانيتك واشتراكاتك وتقاريرك الذكية لحظة بلحظة.',
      enDesc: 'Monitor expenses, budgets, subscriptions, and smart financial reports.',
    },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const endpoint = mode === 'login' ? '/api/auth/login' : '/api/auth/register';
      const res = await apiFetch<{ user: User; token: string }>(endpoint, {
        method: 'POST',
        body: JSON.stringify(
          mode === 'login'
            ? { email, password, remember }
            : { email, password, name, language: lang }
        ),
      });
      setAuthToken(res.token);
      onAuthenticated(res.user);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#080808] text-white flex flex-col items-center justify-center p-4 sm:p-8 relative overflow-hidden">
      {/* Subtle Orange Ambient Glow */}
      <div
        className="pointer-events-none absolute -top-40 left-1/2 -translate-x-1/2 w-[560px] h-[360px] rounded-full opacity-25 blur-[130px]"
        style={{ background: 'radial-gradient(circle, #FF7900 0%, transparent 70%)' }}
      />

      <div className="relative z-10 w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Brand & Onboarding Showcase */}
        <div className="lg:col-span-6 space-y-6 text-center lg:text-start">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3.5">
              <img
                src="/icon-192.png"
                alt="MY LIFE"
                className="w-14 h-14 rounded-2xl border border-[#FF7900]/40 shadow-xl shadow-[#FF7900]/20"
              />
              <div>
                <h1 className="text-2xl font-bold tracking-tight">MY LIFE</h1>
                <p className="text-xs text-[#FF7900] font-semibold tracking-wider">YOUR LIFE, ORGANIZED.</p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => onChangeLang(lang === 'ar' ? 'en' : 'ar')}
              className="px-3 py-2 rounded-xl bg-white/6 hover:bg-white/12 border border-white/10 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Globe size={14} className="text-[#FF7900]" />
              <span>{lang === 'ar' ? 'English' : 'العربية'}</span>
            </button>
          </div>

          <div className="space-y-2">
            <h2 className="text-3xl sm:text-4xl font-bold leading-tight text-balance">
              {isAr ? 'منظم حياتك الرقمية المتكامل' : 'Your Entire Digital Life. One Place.'}
            </h2>
            <p className="text-sm text-white/65 max-w-lg mx-auto lg:mx-0">
              {isAr
                ? 'نظام متكامل لإدارة المستندات والمصروفات والمشتريات والاشتراكات والمواعيد والعائلة والضمانات في مساحة واحدة فاخرة وآمنة.'
                : 'A unified ecosystem for documents, expenses, purchases, subscriptions, calendar, family, warranties, and smart assistance.'}
            </p>
          </div>

          {/* Interactive Onboarding Preview Card */}
          <div className="glass-panel glass-highlight rounded-3xl p-6 space-y-4 text-start">
            {(() => {
              const s = slides[slide];
              const Icon = s.icon;
              return (
                <>
                  <div className="flex items-center justify-between">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center border border-white/15"
                      style={{ backgroundColor: `${s.color}22` }}
                    >
                      <Icon size={24} color={s.color} />
                    </div>
                    <div className="flex items-center gap-1.5">
                      {slides.map((_, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setSlide(idx)}
                          className={`h-2 rounded-full transition-all cursor-pointer ${
                            slide === idx ? 'w-6 bg-[#FF7900]' : 'w-2 bg-white/25'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <div>
                    <h3 className="text-lg font-bold">{isAr ? s.arTitle : s.enTitle}</h3>
                    <p className="text-xs text-white/70 mt-1 leading-relaxed">{isAr ? s.arDesc : s.enDesc}</p>
                  </div>
                  <div className="flex items-center justify-between pt-1">
                    <button
                      type="button"
                      onClick={() => setStep('auth')}
                      className="text-xs text-white/55 hover:text-white cursor-pointer"
                    >
                      {isAr ? 'تخطي' : 'Skip'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setSlide((prev) => (prev + 1) % slides.length)}
                      className="px-3.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <span>{isAr ? 'التالي' : 'Next'}</span>
                      {isAr ? <ArrowLeft size={13} /> : <ArrowRight size={13} />}
                    </button>
                  </div>
                </>
              );
            })()}
          </div>
        </div>

        {/* Auth Glass Panel */}
        <div className={`lg:col-span-6 ${step === 'onboarding' ? 'hidden lg:block' : 'block'}`}>
          <div className="glass-panel glass-highlight rounded-3xl p-6 sm:p-8 space-y-6 max-w-md mx-auto">
            <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-white/[0.04] border border-white/10">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setError('');
                }}
                className={`min-h-[42px] rounded-xl text-xs font-bold cursor-pointer transition ${
                  mode === 'login' ? 'bg-[#FF7900] text-white' : 'text-white/65 hover:text-white'
                }`}
              >
                {isAr ? 'تسجيل الدخول' : 'Sign In'}
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('register');
                  setError('');
                }}
                className={`min-h-[42px] rounded-xl text-xs font-bold cursor-pointer transition ${
                  mode === 'register' ? 'bg-[#FF7900] text-white' : 'text-white/65 hover:text-white'
                }`}
              >
                {isAr ? 'إنشاء حساب' : 'Create Account'}
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {mode === 'register' && (
                <InputField
                  label={isAr ? 'الاسم الكامل' : 'Full Name'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={isAr ? 'الاسم' : 'Your name'}
                  required
                />
              )}
              <InputField
                label={isAr ? 'البريد الإلكتروني' : 'Email Address'}
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                required
              />
              <InputField
                label={isAr ? 'كلمة المرور' : 'Password'}
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
              />

              {mode === 'login' && (
                <label className="flex items-center justify-between text-xs cursor-pointer">
                  <span className="opacity-75">{isAr ? 'تذكرني على هذا الجهاز' : 'Remember me'}</span>
                  <input
                    type="checkbox"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                    className="w-4 h-4 accent-[#FF7900]"
                  />
                </label>
              )}

              {error && (
                <div className="rounded-xl bg-red-500/15 border border-red-500/35 px-3.5 py-2.5 text-xs text-red-200">
                  {error}
                </div>
              )}

              <PrimaryButton type="submit" disabled={loading} className="w-full">
                {loading
                  ? isAr
                    ? 'جارٍ المعالجة...'
                    : 'Please wait...'
                  : mode === 'login'
                  ? isAr
                    ? 'دخول'
                    : 'Sign In'
                  : isAr
                  ? 'إنشاء حساب MY LIFE'
                  : 'Create MY LIFE Account'}
              </PrimaryButton>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
