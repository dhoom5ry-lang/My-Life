import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const UPLOADS_DIR = path.resolve(process.cwd(), 'storage', 'uploads');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

export const DB_PATH = path.join(DATA_DIR, 'mylife.db');
export const UPLOAD_ROOT = UPLOADS_DIR;

export const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name TEXT NOT NULL,
    avatar_url TEXT DEFAULT '',
    language TEXT DEFAULT 'ar',
    theme TEXT DEFAULT 'dark',
    accent_color TEXT DEFAULT '#FF7900',
    icon_shape TEXT DEFAULT 'squircle',
    card_style TEXT DEFAULT 'glass',
    plan TEXT DEFAULT 'FREE',
    assistant_consent TEXT DEFAULT '{"documents":true,"expenses":true,"subscriptions":true,"calendar":true,"tasks":true,"warranties":true}',
    notifications_enabled INTEGER DEFAULT 1,
    privacy_mode INTEGER DEFAULT 0,
    created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,
    token_hash TEXT UNIQUE NOT NULL,
    user_id TEXT NOT NULL,
    device_name TEXT NOT NULL,
    user_agent TEXT DEFAULT '',
    ip_address TEXT DEFAULT '',
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL,
    last_active_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS dashboard_configs (
    user_id TEXT PRIMARY KEY,
    tiles_order TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS folders (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    color_hex TEXT DEFAULT '#FF7900',
    opacity INTEGER DEFAULT 82,
    icon_name TEXT DEFAULT 'Folder',
    style TEXT DEFAULT 'glass',
    is_favorite INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    folder_id TEXT,
    name TEXT NOT NULL,
    original_name TEXT NOT NULL,
    mime_type TEXT NOT NULL,
    ext TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    storage_path TEXT NOT NULL,
    text_preview TEXT DEFAULT '',
    is_favorite INTEGER DEFAULT 0,
    is_deleted INTEGER DEFAULT 0,
    deleted_at TEXT,
    share_token TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (folder_id) REFERENCES folders(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS purchases (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    product_name TEXT NOT NULL,
    image_url TEXT DEFAULT '',
    price REAL NOT NULL,
    currency TEXT DEFAULT 'SAR',
    store TEXT DEFAULT '',
    purchase_date TEXT NOT NULL,
    order_number TEXT DEFAULT '',
    status TEXT DEFAULT 'delivered',
    payment_method TEXT DEFAULT 'card',
    category TEXT DEFAULT 'electronics',
    warranty_months INTEGER DEFAULT 0,
    invoice_doc_id TEXT,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    amount REAL NOT NULL,
    currency TEXT DEFAULT 'SAR',
    category TEXT NOT NULL,
    date TEXT NOT NULL,
    payment_method TEXT DEFAULT 'card',
    invoice_doc_id TEXT,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS subscriptions (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    service_name TEXT NOT NULL,
    logo_icon TEXT DEFAULT 'Repeat',
    color TEXT DEFAULT '#FF7900',
    price REAL NOT NULL,
    currency TEXT DEFAULT 'SAR',
    start_date TEXT NOT NULL,
    renewal_date TEXT NOT NULL,
    billing_cycle TEXT DEFAULT 'monthly',
    status TEXT DEFAULT 'active',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS events (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    date TEXT NOT NULL,
    start_time TEXT DEFAULT '09:00',
    end_time TEXT DEFAULT '10:00',
    location TEXT DEFAULT '',
    priority TEXT DEFAULT 'medium',
    recurrence TEXT DEFAULT 'none',
    description TEXT DEFAULT '',
    shared_with_family INTEGER DEFAULT 0,
    reminder_minutes INTEGER DEFAULT 30,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS families (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    owner_id TEXT NOT NULL,
    invite_code TEXT UNIQUE NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS family_members (
    id TEXT PRIMARY KEY,
    family_id TEXT NOT NULL,
    user_id TEXT,
    display_name TEXT NOT NULL,
    relation TEXT DEFAULT 'member',
    role TEXT DEFAULT 'member',
    avatar_color TEXT DEFAULT '#FF7900',
    permissions TEXT DEFAULT '{"view_budget":true,"add_expenses":true,"view_calendar":true,"manage_tasks":true}',
    created_at TEXT NOT NULL,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS family_items (
    id TEXT PRIMARY KEY,
    family_id TEXT NOT NULL,
    author_user_id TEXT NOT NULL,
    item_type TEXT NOT NULL,
    title TEXT NOT NULL,
    amount REAL DEFAULT 0,
    target_amount REAL DEFAULT 0,
    due_date TEXT DEFAULT '',
    assigned_to TEXT DEFAULT '',
    status TEXT DEFAULT 'pending',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (family_id) REFERENCES families(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS budgets (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    category TEXT NOT NULL,
    period TEXT DEFAULT 'monthly',
    limit_amount REAL NOT NULL,
    currency TEXT DEFAULT 'SAR',
    alert_threshold INTEGER DEFAULT 80,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS savings_goals (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    target_amount REAL NOT NULL,
    current_amount REAL DEFAULT 0,
    currency TEXT DEFAULT 'SAR',
    deadline TEXT DEFAULT '',
    icon_name TEXT DEFAULT 'PiggyBank',
    color TEXT DEFAULT '#22C55E',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS warranties (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    product_name TEXT NOT NULL,
    manufacturer TEXT DEFAULT '',
    purchase_date TEXT NOT NULL,
    expiry_date TEXT NOT NULL,
    serial_number TEXT DEFAULT '',
    service_center TEXT DEFAULT '',
    invoice_doc_id TEXT,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS maintenance_logs (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    category TEXT NOT NULL,
    title TEXT NOT NULL,
    service_center TEXT DEFAULT '',
    scheduled_date TEXT NOT NULL,
    cost REAL DEFAULT 0,
    status TEXT DEFAULT 'scheduled',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS properties (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    image_url TEXT DEFAULT '',
    value REAL DEFAULT 0,
    lease_start TEXT DEFAULT '',
    lease_end TEXT DEFAULT '',
    monthly_rent REAL DEFAULT 0,
    expenses_total REAL DEFAULT 0,
    revenue_total REAL DEFAULT 0,
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS trips (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    destination TEXT NOT NULL,
    departure_date TEXT NOT NULL,
    return_date TEXT NOT NULL,
    flight_info TEXT DEFAULT '',
    hotel_info TEXT DEFAULT '',
    budget REAL DEFAULT 0,
    spent REAL DEFAULT 0,
    checklist_json TEXT DEFAULT '[]',
    notes TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    category TEXT DEFAULT 'daily',
    priority TEXT DEFAULT 'medium',
    due_date TEXT DEFAULT '',
    due_time TEXT DEFAULT '',
    recurrence TEXT DEFAULT 'none',
    completed INTEGER DEFAULT 0,
    is_goal INTEGER DEFAULT 0,
    progress INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS contacts (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    phone TEXT DEFAULT '',
    email TEXT DEFAULT '',
    relationship TEXT DEFAULT '',
    company TEXT DEFAULT '',
    notes TEXT DEFAULT '',
    is_favorite INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS vault_items (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    content TEXT DEFAULT '',
    url TEXT DEFAULT '',
    doc_id TEXT,
    is_favorite INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS custom_widgets (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    name TEXT NOT NULL,
    icon_name TEXT DEFAULT 'Sparkles',
    icon_color TEXT DEFAULT '#FF7900',
    bg_color TEXT DEFAULT '#151515',
    style TEXT DEFAULT 'glass',
    opacity INTEGER DEFAULT 82,
    widget_type TEXT DEFAULT 'tracker',
    config_json TEXT DEFAULT '{}',
    data_json TEXT DEFAULT '{}',
    is_favorite INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS icon_prefs (
    user_id TEXT PRIMARY KEY,
    favorites_json TEXT DEFAULT '[]',
    recent_json TEXT DEFAULT '[]',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS backups (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    label TEXT NOT NULL,
    encrypted INTEGER DEFAULT 1,
    size_bytes INTEGER NOT NULL,
    payload TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    type TEXT DEFAULT 'info',
    is_read INTEGER DEFAULT 0,
    link_module TEXT DEFAULT 'dashboard',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS activity_logs (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    action TEXT NOT NULL,
    module TEXT NOT NULL,
    details TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS billing_history (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    plan TEXT NOT NULL,
    amount REAL NOT NULL,
    currency TEXT DEFAULT 'SAR',
    status TEXT DEFAULT 'active',
    invoice_number TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

export const DEFAULT_TILE_ORDER = [
  'documents',
  'calendar',
  'subscriptions',
  'purchases',
  'expenses',
  'family',
  'budget',
  'warranties',
  'maintenance',
  'properties',
  'travel',
  'goals',
  'tasks',
  'mylife',
  'assistant',
  'reports',
  'contacts',
  'backup',
  'vault',
  'favorites',
  'tools',
];

export const DEFAULT_STARTER_FOLDERS = [
  { name: 'الهوية', color_hex: '#7C3AED', icon_name: 'IdCard' },
  { name: 'العمل', color_hex: '#3B82F6', icon_name: 'Briefcase' },
  { name: 'شخصي', color_hex: '#1F2937', icon_name: 'User' },
  { name: 'التدريب', color_hex: '#EC4899', icon_name: 'GraduationCap' },
  { name: 'طبية', color_hex: '#FFFFFF', icon_name: 'HeartPulse' },
  { name: 'البنك', color_hex: '#F59E0B', icon_name: 'Landmark' },
  { name: 'السكن', color_hex: '#10B981', icon_name: 'Home' },
  { name: 'المشاريع', color_hex: '#FF7900', icon_name: 'FolderKanban' },
];
