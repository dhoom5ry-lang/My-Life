import React, { useEffect, useState } from 'react';
import {
  Archive,
  Contact,
  DatabaseBackup,
  Download,
  Lock,
  Plus,
  RotateCcw,
  Star,
  Trash2,
  Upload,
} from 'lucide-react';
import { apiFetch } from '../lib/api';
import { CORE_SECTIONS } from '../lib/i18n';
import type { ContactItem, CustomWidget, DocumentItem, FolderItem, Language, ModuleId, VaultItem } from '../types';
import { DynamicIcon } from '../components/DynamicIcon';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

export const ContactsModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [contacts, setContacts] = useState<ContactItem[]>([]);
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: '', phone: '', email: '', relationship: '', company: '', notes: '' });

  const load = async () => {
    const res = await apiFetch<{ contacts: ContactItem[] }>('/api/contacts');
    setContacts(res.contacts || []);
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = contacts.filter(
    (c) =>
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.phone.includes(search) ||
      c.email.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isAr ? 'ابحث في جهات الاتصال...' : 'Search contacts...'}
          className="flex-1 min-w-[220px] min-h-[44px] rounded-xl bg-white/[0.06] border border-white/12 px-4 text-sm focus:outline-none focus:border-[#FF7900]"
        />
        <PrimaryButton onClick={() => setOpen(true)}>
          <Plus size={16} />
          <span>{isAr ? 'إضافة جهة اتصال' : 'Add Contact'}</span>
        </PrimaryButton>
      </div>

      {filtered.length === 0 ? (
        <GlassCard className="p-10 text-center text-sm opacity-65">{isAr ? 'لا توجد جهات اتصال.' : 'No contacts yet.'}</GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((c) => (
            <GlassCard key={c.id} className="p-4 flex items-start justify-between gap-3">
              <div className="flex items-start gap-3">
                <div className="w-11 h-11 rounded-full bg-blue-500/20 text-blue-300 flex items-center justify-center font-bold">
                  <Contact size={18} />
                </div>
                <div>
                  <h4 className="font-bold text-sm">{c.name}</h4>
                  <p className="text-xs opacity-65">{c.relationship || c.company || '—'}</p>
                  {c.phone && <p className="text-xs font-mono-num text-[#FF7900] mt-1">{c.phone}</p>}
                  {c.email && <p className="text-xs opacity-65">{c.email}</p>}
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={async () => {
                    await apiFetch(`/api/contacts/${c.id}`, {
                      method: 'PATCH',
                      body: JSON.stringify({ is_favorite: c.is_favorite ? 0 : 1 }),
                    });
                    load();
                  }}
                  className="p-1.5 rounded-lg hover:bg-white/10 cursor-pointer"
                >
                  <Star size={15} fill={c.is_favorite ? '#FACC15' : 'none'} className={c.is_favorite ? 'text-amber-400' : 'opacity-60'} />
                </button>
                <button
                  onClick={async () => {
                    await apiFetch(`/api/contacts/${c.id}`, { method: 'DELETE' });
                    load();
                  }}
                  className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      <GlassModal open={open} onClose={() => setOpen(false)} title={isAr ? 'جهة اتصال جديدة' : 'New Contact'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/contacts', { method: 'POST', body: JSON.stringify(form) });
            setOpen(false);
            setForm({ name: '', phone: '', email: '', relationship: '', company: '', notes: '' });
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'الاسم' : 'Name'} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <InputField label={isAr ? 'رقم الجوال' : 'Phone'} value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
          <InputField label={isAr ? 'البريد الإلكتروني' : 'Email'} value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'الصلة' : 'Relationship'} value={form.relationship} onChange={(e) => setForm({ ...form, relationship: e.target.value })} />
            <InputField label={isAr ? 'الجهة / الشركة' : 'Company'} value={form.company} onChange={(e) => setForm({ ...form, company: e.target.value })} />
          </div>
          <PrimaryButton type="submit" className="w-full">{isAr ? 'حفظ' : 'Save'}</PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};

export const VaultModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [items, setItems] = useState<VaultItem[]>([]);
  const [typeFilter, setTypeFilter] = useState<'all' | VaultItem['type']>('all');
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ type: 'note' as VaultItem['type'], title: '', content: '', url: '' });

  const load = async () => {
    const res = await apiFetch<{ items: VaultItem[] }>('/api/vault');
    setItems(res.items || []);
  };

  useEffect(() => {
    load();
  }, []);

  const types: { id: VaultItem['type']; ar: string; en: string }[] = [
    { id: 'photo', ar: 'الصور', en: 'Photos' },
    { id: 'video', ar: 'الفيديوهات', en: 'Videos' },
    { id: 'document', ar: 'المستندات', en: 'Documents' },
    { id: 'link', ar: 'الروابط', en: 'Links' },
    { id: 'note', ar: 'الملاحظات', en: 'Notes' },
  ];

  const filtered = typeFilter === 'all' ? items : items.filter((i) => i.type === typeFilter);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setTypeFilter('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer ${
              typeFilter === 'all' ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/75'
            }`}
          >
            {isAr ? 'الكل' : 'All'}
          </button>
          {types.map((t) => (
            <button
              key={t.id}
              onClick={() => setTypeFilter(t.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer ${
                typeFilter === t.id ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/75'
              }`}
            >
              {isAr ? t.ar : t.en}
            </button>
          ))}
        </div>
        <PrimaryButton onClick={() => setOpen(true)}>
          <Plus size={16} />
          <span>{isAr ? 'إضافة للمحفوظات' : 'Save to Vault'}</span>
        </PrimaryButton>
      </div>

      {filtered.length === 0 ? (
        <GlassCard className="p-10 text-center space-y-2">
          <Archive size={34} className="mx-auto opacity-35" />
          <p className="text-sm opacity-65">{isAr ? 'لا توجد محفوظات في هذا القسم.' : 'No saved items yet.'}</p>
        </GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((item) => (
            <GlassCard key={item.id} className="p-4 space-y-2.5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h4 className="font-bold text-sm">{item.title}</h4>
                  <span className="text-[11px] text-[#FF7900]">{item.type}</span>
                </div>
                <button
                  onClick={async () => {
                    await apiFetch(`/api/vault/${item.id}`, { method: 'DELETE' });
                    load();
                  }}
                  className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                >
                  <Trash2 size={14} />
                </button>
              </div>
              {item.content && <p className="text-xs opacity-75 whitespace-pre-wrap">{item.content}</p>}
              {item.url && /^https?:\/\//i.test(item.url) && (
                <a href={item.url} target="_blank" rel="noreferrer" className="text-xs text-blue-400 hover:underline block truncate">
                  {item.url}
                </a>
              )}
            </GlassCard>
          ))}
        </div>
      )}

      <GlassModal open={open} onClose={() => setOpen(false)} title={isAr ? 'حفظ في المحفوظات' : 'Add to Vault'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/vault', { method: 'POST', body: JSON.stringify(form) });
            setOpen(false);
            setForm({ type: 'note', title: '', content: '', url: '' });
            load();
          }}
          className="space-y-3.5"
        >
          <SelectField label={isAr ? 'النوع' : 'Type'} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as VaultItem['type'] })}>
            {types.map((t) => (
              <option key={t.id} value={t.id}>{isAr ? t.ar : t.en}</option>
            ))}
          </SelectField>
          <InputField label={isAr ? 'العنوان' : 'Title'} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <InputField label={isAr ? 'الرابط (اختياري)' : 'URL (optional)'} value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} />
          <label className="block space-y-1.5">
            <span className="block text-xs font-medium opacity-75">{isAr ? 'المحتوى / الملاحظة' : 'Content / Note'}</span>
            <textarea
              rows={4}
              value={form.content}
              onChange={(e) => setForm({ ...form, content: e.target.value })}
              className="w-full rounded-xl bg-white/[0.05] border border-white/12 p-3 text-sm focus:outline-none focus:border-[#FF7900]"
            />
          </label>
          <PrimaryButton type="submit" className="w-full">{isAr ? 'حفظ' : 'Save'}</PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};

export const FavoritesModule: React.FC<{
  lang: Language;
  onNavigate: (mod: ModuleId) => void;
}> = ({ lang, onNavigate }) => {
  const isAr = lang === 'ar';
  const [folders, setFolders] = useState<FolderItem[]>([]);
  const [docs, setDocs] = useState<DocumentItem[]>([]);
  const [widgets, setWidgets] = useState<CustomWidget[]>([]);

  useEffect(() => {
    Promise.all([
      apiFetch<{ folders: FolderItem[] }>('/api/folders'),
      apiFetch<{ documents: DocumentItem[] }>('/api/documents'),
      apiFetch<{ widgets: CustomWidget[] }>('/api/widgets'),
    ]).then(([f, d, w]) => {
      setFolders((f.folders || []).filter((x) => x.is_favorite === 1));
      setDocs((d.documents || []).filter((x) => x.is_favorite === 1));
      setWidgets((w.widgets || []).filter((x) => x.is_favorite === 1));
    });
  }, []);

  return (
    <div className="space-y-6">
      <GlassCard className="p-5 space-y-3">
        <h4 className="text-sm font-bold">{isAr ? 'المجلدات المفضلة' : 'Favorite Folders'} ({folders.length})</h4>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {folders.map((f) => (
            <button
              key={f.id}
              onClick={() => onNavigate('documents')}
              className="rounded-2xl bg-white/[0.05] border border-white/10 p-3.5 flex items-center gap-3 hover:border-[#FF7900] cursor-pointer text-start"
            >
              <DynamicIcon name={f.icon_name} color={f.color_hex} size={20} />
              <div className="min-w-0">
                <p className="text-sm font-bold truncate">{f.name}</p>
                <p className="text-xs opacity-60">{f.file_count} {isAr ? 'ملف' : 'files'}</p>
              </div>
            </button>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="p-5 space-y-3">
        <h4 className="text-sm font-bold">{isAr ? 'الملفات المفضلة' : 'Favorite Documents'} ({docs.length})</h4>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {docs.map((d) => (
            <button
              key={d.id}
              onClick={() => onNavigate('documents')}
              className="rounded-2xl bg-white/[0.05] border border-white/10 p-3.5 text-start hover:border-[#FF7900] cursor-pointer"
            >
              <p className="text-sm font-bold truncate">{d.name}</p>
              <p className="text-xs opacity-60 font-mono">.{d.ext.toUpperCase()}</p>
            </button>
          ))}
        </div>
      </GlassCard>

      <GlassCard className="p-5 space-y-3">
        <h4 className="text-sm font-bold">{isAr ? 'الأقسام والأدوات السريعة' : 'Pinned Sections & Custom Tools'}</h4>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {widgets.map((w) => (
            <button
              key={w.id}
              onClick={() => onNavigate('tools')}
              className="rounded-2xl bg-white/[0.05] border border-white/10 p-3.5 flex items-center gap-3 cursor-pointer"
            >
              <DynamicIcon name={w.icon_name} color={w.icon_color} size={20} />
              <span className="text-sm font-semibold truncate">{w.name}</span>
            </button>
          ))}
          {CORE_SECTIONS.slice(0, 4).map((s) => (
            <button
              key={s.id}
              onClick={() => onNavigate(s.id)}
              className="rounded-2xl bg-white/[0.05] border border-white/10 p-3.5 flex items-center gap-3 hover:border-[#FF7900] cursor-pointer"
            >
              <DynamicIcon name={s.icon} color={s.color} size={20} />
              <span className="text-sm font-semibold truncate">{isAr ? s.ar : s.en}</span>
            </button>
          ))}
        </div>
      </GlassCard>
    </div>
  );
};

export const BackupModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [backups, setBackups] = useState<{ id: string; label: string; encrypted: number; size_bytes: number; created_at: string }[]>([]);
  const [label, setLabel] = useState('');
  const [passphrase, setPassphrase] = useState('');
  const [restorePass, setRestorePass] = useState('');
  const [msg, setMsg] = useState('');

  const load = async () => {
    const res = await apiFetch<{ backups: typeof backups }>('/api/backups');
    setBackups(res.backups || []);
  };

  useEffect(() => {
    load();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg('');
    await apiFetch('/api/backups/create', {
      method: 'POST',
      body: JSON.stringify({
        label: label || `MY LIFE Backup ${new Date().toISOString().slice(0, 10)}`,
        passphrase,
        encrypted: true,
      }),
    });
    setLabel('');
    setMsg(isAr ? 'تم إنشاء نسخة احتياطية مشفرة بنجاح (AES-256-GCM).' : 'Encrypted AES-256-GCM backup created.');
    load();
  };

  const handleUploadRestore = async (file: File | null) => {
    if (!file) return;
    setMsg('');
    try {
      const payload = await file.text();
      await apiFetch('/api/backups/restore', {
        method: 'POST',
        body: JSON.stringify({ payload, passphrase: restorePass }),
      });
      setMsg(isAr ? 'تمت استعادة البيانات من الملف بنجاح!' : 'Backup restored successfully!');
    } catch (err) {
      setMsg((err as Error).message);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <GlassCard className="p-6 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center">
              <DatabaseBackup size={22} />
            </div>
            <div>
              <h3 className="font-bold text-base">{isAr ? 'إنشاء نسخة احتياطية مشفرة' : 'Create Encrypted Backup'}</h3>
              <p className="text-xs opacity-60">{isAr ? 'تشفير AES-256-GCM لجميع بياناتك' : 'AES-256-GCM encrypted snapshot'}</p>
            </div>
          </div>
          <form onSubmit={handleCreate} className="space-y-3">
            <InputField label={isAr ? 'اسم النسخة' : 'Backup Label'} value={label} onChange={(e) => setLabel(e.target.value)} placeholder={isAr ? 'نسخة شهر نوفمبر' : 'November Snapshot'} />
            <InputField
              label={isAr ? 'كلمة مرور التشفير (اختياري لكن موصى به)' : 'Encryption Passphrase (Recommended)'}
              type="password"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
            />
            <PrimaryButton type="submit" className="w-full">
              <Lock size={16} />
              <span>{isAr ? 'إنشاء وحفظ النسخة' : 'Create Encrypted Backup'}</span>
            </PrimaryButton>
          </form>
        </GlassCard>

        <GlassCard className="p-6 space-y-4">
          <h3 className="font-bold text-base">{isAr ? 'استعادة من ملف نسخة احتياطية' : 'Restore from Backup File'}</h3>
          <InputField
            label={isAr ? 'كلمة مرور فك التشفير (إن وجدت)' : 'Decryption Passphrase'}
            type="password"
            value={restorePass}
            onChange={(e) => setRestorePass(e.target.value)}
          />
          <label className="min-h-[52px] rounded-2xl border border-dashed border-white/25 hover:border-[#FF7900] flex items-center justify-center gap-2 text-sm cursor-pointer transition">
            <Upload size={17} className="text-[#FF7900]" />
            <span>{isAr ? 'اختر ملف .mylife.json للاستعادة' : 'Choose .mylife.json file to restore'}</span>
            <input type="file" accept=".json" className="hidden" onChange={(e) => handleUploadRestore(e.target.files?.[0] || null)} />
          </label>
          {msg && <p className="text-xs text-[#FF7900] bg-[#FF7900]/10 border border-[#FF7900]/30 rounded-xl p-3">{msg}</p>}
        </GlassCard>
      </div>

      <GlassCard className="p-5 space-y-3">
        <h4 className="text-sm font-bold">{isAr ? 'تاريخ النسخ الاحتياطية' : 'Backup History'}</h4>
        {backups.length === 0 ? (
          <p className="text-sm opacity-60 py-6 text-center">{isAr ? 'لا توجد نسخ احتياطية محفوظة بعد.' : 'No backups created yet.'}</p>
        ) : (
          <div className="divide-y divide-white/8">
            {backups.map((b) => (
              <div key={b.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-sm font-bold flex items-center gap-2">
                    <Lock size={13} className="text-emerald-400" />
                    <span>{b.label}</span>
                  </p>
                  <p className="text-xs opacity-60 font-mono-num">
                    {b.created_at.slice(0, 19).replace('T', ' ')} · {(b.size_bytes / 1024).toFixed(1)} KB
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <a
                    href={`/api/backups/${b.id}/download`}
                    className="px-3 py-1.5 rounded-xl bg-white/8 hover:bg-white/14 text-xs inline-flex items-center gap-1.5"
                  >
                    <Download size={13} />
                    <span>{isAr ? 'تنزيل' : 'Download'}</span>
                  </a>
                  <button
                    onClick={async () => {
                      setMsg('');
                      try {
                        await apiFetch('/api/backups/restore', {
                          method: 'POST',
                          body: JSON.stringify({ backupId: b.id, passphrase: restorePass }),
                        });
                        setMsg(isAr ? 'تمت الاستعادة بنجاح!' : 'Restored successfully!');
                      } catch (err) {
                        setMsg((err as Error).message);
                      }
                    }}
                    className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 text-xs inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <RotateCcw size={13} />
                    <span>{isAr ? 'استعادة' : 'Restore'}</span>
                  </button>
                  <button
                    onClick={async () => {
                      await apiFetch(`/api/backups/${b.id}`, { method: 'DELETE' });
                      load();
                    }}
                    className="p-2 rounded-xl hover:bg-red-500/20 text-red-400 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </GlassCard>
    </div>
  );
};
