import React, { useState } from 'react';
import { Lock, Send, ShieldCheck, Sparkles } from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { AssistantConsent, Language, User } from '../types';
import { GlassCard, PrimaryButton } from '../components/GlassUI';

interface ChatMessage {
  role: 'user' | 'assistant';
  text: string;
}

export const AssistantModule: React.FC<{
  user: User;
  lang: Language;
  onUserUpdate: (u: User) => void;
}> = ({ user, lang, onUserUpdate }) => {
  const isAr = lang === 'ar';
  const consent: AssistantConsent = JSON.parse(
    user.assistant_consent || '{"documents":true,"expenses":true,"subscriptions":true,"calendar":true,"tasks":true,"warranties":true}'
  );

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: 'assistant',
      text: isAr
        ? `مرحبًا ${user.name}! كيف أساعدك اليوم؟ أستطيع تحليل مصروفاتك، تلخيص مستنداتك، تنبيهك بالاشتراكات القريبة، ومراجعة مهامك ومواعيدك وفق الصلاحيات التي تفعّلها لي.`
        : `Hello ${user.name}! How can I help today? I can analyze your expenses, summarize documents, check expiring subscriptions, and organize tasks within the permissions you grant.`,
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const toggleConsent = async (key: keyof AssistantConsent) => {
    const next = { ...consent, [key]: !consent[key] };
    const res = await apiFetch<{ user: User }>('/api/auth/profile', {
      method: 'PATCH',
      body: JSON.stringify({ assistant_consent: next }),
    });
    onUserUpdate(res.user);
  };

  const sendMessage = async (textOverride?: string) => {
    const msg = (textOverride ?? input).trim();
    if (!msg || loading) return;
    setInput('');
    setMessages((prev) => [...prev, { role: 'user', text: msg }]);
    setLoading(true);
    try {
      const res = await apiFetch<{ reply: string }>('/api/assistant/chat', {
        method: 'POST',
        body: JSON.stringify({ message: msg }),
      });
      setMessages((prev) => [...prev, { role: 'assistant', text: res.reply }]);
    } catch (err) {
      setMessages((prev) => [...prev, { role: 'assistant', text: (err as Error).message }]);
    } finally {
      setLoading(false);
    }
  };

  const suggestions = isAr
    ? [
        'لخّص مصروفاتي هذا الشهر وقارنها بالدخل',
        'ما هي الاشتراكات القريبة من التجديد؟',
        'لخّص مستنداتي الأخيرة',
        'رتّب مهامي ومواعيدي القادمة',
      ]
    : [
        'Summarize my expenses this month vs income',
        'Which subscriptions are renewing soon?',
        'Summarize my recent documents',
        'Organize my upcoming tasks & appointments',
      ];

  const permissionLabels: { key: keyof AssistantConsent; ar: string; en: string }[] = [
    { key: 'documents', ar: 'المستندات', en: 'Documents' },
    { key: 'expenses', ar: 'المصروفات والفواتير', en: 'Expenses & Invoices' },
    { key: 'subscriptions', ar: 'الاشتراكات', en: 'Subscriptions' },
    { key: 'calendar', ar: 'المواعيد', en: 'Calendar' },
    { key: 'tasks', ar: 'المهام', en: 'Tasks' },
    { key: 'warranties', ar: 'الضمانات', en: 'Warranties' },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* Privacy & Data Consent Panel */}
      <GlassCard className="p-5 lg:col-span-4 space-y-4 h-fit">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-[#FF7900]/15 text-[#FF7900] flex items-center justify-center">
            <ShieldCheck size={20} />
          </div>
          <div>
            <h4 className="font-bold text-sm">{isAr ? 'صلاحيات الوصول للبيانات' : 'Assistant Data Permissions'}</h4>
            <p className="text-[11px] opacity-60">{isAr ? 'تحكم بما يمكن للمساعد قراءته' : 'Control what the assistant may access'}</p>
          </div>
        </div>

        <div className="space-y-2">
          {permissionLabels.map((p) => (
            <label
              key={p.key}
              className="flex items-center justify-between rounded-2xl bg-white/[0.04] border border-white/10 px-3.5 py-2.5 cursor-pointer"
            >
              <span className="text-xs font-medium">{isAr ? p.ar : p.en}</span>
              <input
                type="checkbox"
                checked={Boolean(consent[p.key])}
                onChange={() => toggleConsent(p.key)}
                className="w-4 h-4 accent-[#FF7900]"
              />
            </label>
          ))}
        </div>

        <p className="text-[11px] opacity-60 flex items-start gap-1.5">
          <Lock size={13} className="shrink-0 mt-0.5 text-emerald-400" />
          <span>
            {isAr
              ? 'يتم تطبيق الصلاحيات على الخادم قبل أي استعلام ولا تُكشف أي بيانات معطلة.'
              : 'Permissions are enforced server-side; disabled sections are never shared with AI.'}
          </span>
        </p>
      </GlassCard>

      {/* Chat Surface */}
      <GlassCard className="p-5 lg:col-span-8 flex flex-col min-h-[540px] max-h-[72vh]">
        <div className="flex items-center gap-3 pb-4 border-b border-white/10">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#FF7900] to-purple-600 flex items-center justify-center text-white shadow-lg shadow-[#FF7900]/25">
            <Sparkles size={20} />
          </div>
          <div>
            <h3 className="font-bold text-base">{isAr ? 'المساعد الذكي — MY LIFE' : 'MY LIFE Smart Assistant'}</h3>
            <p className="text-xs opacity-60">{isAr ? 'تحليل مستندات، فواتير، مصروفات، وتقارير ذكية' : 'Document, invoice, expense & schedule intelligence'}</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto py-4 space-y-3">
          {messages.map((m, idx) => (
            <div key={idx} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                  m.role === 'user'
                    ? 'bg-[#FF7900] text-white'
                    : 'bg-white/[0.06] border border-white/10'
                }`}
              >
                {m.text}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="rounded-2xl px-4 py-3 text-xs bg-white/[0.06] border border-white/10 opacity-75">
                {isAr ? 'جارٍ التحليل وإعداد الرد...' : 'Analyzing permitted data...'}
              </div>
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-1.5 pb-3">
          {suggestions.map((s) => (
            <button
              key={s}
              onClick={() => sendMessage(s)}
              className="px-3 py-1.5 rounded-xl bg-white/6 hover:bg-white/12 border border-white/10 text-xs transition cursor-pointer"
            >
              {s}
            </button>
          ))}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage();
          }}
          className="flex items-center gap-2 pt-2 border-t border-white/10"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isAr ? 'اكتب طلبك هنا...' : 'Ask about your data...'}
            className="flex-1 min-h-[44px] rounded-xl bg-white/[0.05] border border-white/12 px-4 text-sm focus:outline-none focus:border-[#FF7900]"
          />
          <PrimaryButton type="submit" disabled={loading}>
            <Send size={16} />
            <span>{isAr ? 'إرسال' : 'Send'}</span>
          </PrimaryButton>
        </form>
      </GlassCard>
    </div>
  );
};
