import React, { useEffect, useMemo, useState } from 'react';
import { Download, FileSpreadsheet } from 'lucide-react';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import { apiFetch } from '../lib/api';
import { formatCurrency } from '../lib/i18n';
import type {
  BudgetItem,
  Language,
  MaintenanceItem,
  PropertyItem,
  PurchaseItem,
  SavingsGoal,
  SubscriptionItem,
  TaskItem,
  TransactionItem,
  WarrantyItem,
} from '../types';
import { GlassCard, PrimaryButton } from '../components/GlassUI';

type ReportTab =
  | 'expenses'
  | 'income'
  | 'purchases'
  | 'subscriptions'
  | 'budget'
  | 'savings'
  | 'family'
  | 'tasks'
  | 'warranties'
  | 'properties';

export const ReportsModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [tab, setTab] = useState<ReportTab>('expenses');
  const [period, setPeriod] = useState<'monthly' | 'quarterly' | 'yearly'>('monthly');

  const [txs, setTxs] = useState<TransactionItem[]>([]);
  const [purchases, setPurchases] = useState<PurchaseItem[]>([]);
  const [subs, setSubs] = useState<SubscriptionItem[]>([]);
  const [budgets, setBudgets] = useState<BudgetItem[]>([]);
  const [savings, setSavings] = useState<SavingsGoal[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [warranties, setWarranties] = useState<WarrantyItem[]>([]);
  const [properties, setProperties] = useState<PropertyItem[]>([]);
  const [maintenance, setMaintenance] = useState<MaintenanceItem[]>([]);
  const [familyItems, setFamilyItems] = useState<{ title: string; amount: number; item_type: string; status: string }[]>([]);

  useEffect(() => {
    Promise.all([
      apiFetch<{ transactions: TransactionItem[] }>('/api/transactions'),
      apiFetch<{ purchases: PurchaseItem[] }>('/api/purchases'),
      apiFetch<{ subscriptions: SubscriptionItem[] }>('/api/subscriptions'),
      apiFetch<{ budgets: BudgetItem[]; savings: SavingsGoal[] }>('/api/budgets'),
      apiFetch<{ tasks: TaskItem[] }>('/api/tasks'),
      apiFetch<{ warranties: WarrantyItem[] }>('/api/warranties'),
      apiFetch<{ properties: PropertyItem[] }>('/api/properties'),
      apiFetch<{ logs: MaintenanceItem[] }>('/api/maintenance'),
      apiFetch<{ items: { title: string; amount: number; item_type: string; status: string }[] }>('/api/family'),
    ]).then(([t, p, s, b, tk, w, pr, m, fam]) => {
      setTxs(t.transactions || []);
      setPurchases(p.purchases || []);
      setSubs(s.subscriptions || []);
      setBudgets(b.budgets || []);
      setSavings(b.savings || []);
      setTasks(tk.tasks || []);
      setWarranties(w.warranties || []);
      setProperties(pr.properties || []);
      setMaintenance(m.logs || []);
      setFamilyItems(fam.items || []);
    });
  }, []);

  const reportTabs: { id: ReportTab; ar: string; en: string }[] = [
    { id: 'expenses', ar: 'المصروفات', en: 'Expenses' },
    { id: 'income', ar: 'الدخل', en: 'Income' },
    { id: 'purchases', ar: 'المشتريات', en: 'Purchases' },
    { id: 'subscriptions', ar: 'الاشتراكات', en: 'Subscriptions' },
    { id: 'budget', ar: 'الميزانية', en: 'Budget' },
    { id: 'savings', ar: 'الادخار', en: 'Savings' },
    { id: 'family', ar: 'العائلة', en: 'Family' },
    { id: 'tasks', ar: 'المهام', en: 'Tasks' },
    { id: 'warranties', ar: 'الضمانات', en: 'Warranties' },
    { id: 'properties', ar: 'الممتلكات', en: 'Properties' },
  ];

  const rowsForExport = useMemo(() => {
    switch (tab) {
      case 'expenses':
        return txs.filter((t) => t.type === 'expense').map((t) => ({ Title: t.title, Category: t.category, Amount: t.amount, Date: t.date }));
      case 'income':
        return txs.filter((t) => t.type === 'income').map((t) => ({ Title: t.title, Amount: t.amount, Date: t.date }));
      case 'purchases':
        return purchases.map((p) => ({ Product: p.product_name, Store: p.store, Price: p.price, Date: p.purchase_date, Status: p.status }));
      case 'subscriptions':
        return subs.map((s) => ({ Service: s.service_name, Price: s.price, Cycle: s.billing_cycle, Renewal: s.renewal_date, Status: s.status }));
      case 'budget':
        return budgets.map((b) => ({ Category: b.category, Period: b.period, Limit: b.limit_amount }));
      case 'savings':
        return savings.map((g) => ({ Goal: g.title, Saved: g.current_amount, Target: g.target_amount, Deadline: g.deadline }));
      case 'family':
        return familyItems.map((f) => ({ Title: f.title, Type: f.item_type, Amount: f.amount, Status: f.status }));
      case 'tasks':
        return tasks.map((t) => ({ Title: t.title, Category: t.category, Priority: t.priority, Completed: t.completed ? 'Yes' : 'No' }));
      case 'warranties':
        return warranties.map((w) => ({ Product: w.product_name, Manufacturer: w.manufacturer, Expiry: w.expiry_date }));
      case 'properties':
        return properties.map((p) => ({ Property: p.name, Address: p.address, Value: p.value, Rent: p.monthly_rent }));
    }
  }, [tab, txs, purchases, subs, budgets, savings, familyItems, tasks, warranties, properties]);

  // Monthly Bar Chart data across last 6 months
  const monthlyBars = useMemo(() => {
    const map: Record<string, number> = {};
    for (const t of txs) {
      if (t.type === 'expense') {
        const m = t.date.slice(0, 7);
        map[m] = (map[m] || 0) + t.amount;
      }
    }
    const entries = Object.entries(map).sort((a, b) => a[0].localeCompare(b[0])).slice(-6);
    const maxVal = Math.max(1, ...entries.map((e) => e[1]));
    return entries.map(([label, value]) => ({ label, value, pct: Math.round((value / maxVal) * 100) }));
  }, [txs]);

  const handleExportExcel = () => {
    const ws = XLSX.utils.json_to_sheet(rowsForExport.length ? rowsForExport : [{ Info: 'No rows' }]);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, tab.toUpperCase());
    XLSX.writeFile(wb, `MY-LIFE-${tab}-report.xlsx`);
  };

  const handleExportPdf = () => {
    const canvas = document.createElement('canvas');
    canvas.width = 1120;
    canvas.height = 1400;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#0B0B0D';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#FF7900';
    ctx.font = 'bold 36px sans-serif';
    ctx.fillText(`MY LIFE — ${tab.toUpperCase()} REPORT`, 56, 76);

    ctx.fillStyle = '#AAAAAA';
    ctx.font = '20px sans-serif';
    ctx.fillText(`Generated: ${new Date().toISOString().slice(0, 10)} · Period: ${period}`, 56, 114);

    let y = 176;
    const slice = rowsForExport.slice(0, 26);
    ctx.font = '18px sans-serif';
    for (const row of slice) {
      ctx.fillStyle = 'rgba(255,255,255,0.06)';
      ctx.fillRect(56, y - 24, 1008, 36);
      ctx.fillStyle = '#FFFFFF';
      const line = Object.values(row).join('   |   ');
      ctx.fillText(line.slice(0, 95), 72, y);
      y += 44;
    }

    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF({ orientation: 'portrait', unit: 'px', format: [canvas.width, canvas.height] });
    pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
    pdf.save(`MY-LIFE-${tab}-report.pdf`);
  };

  const totalExpenses = txs.filter((t) => t.type === 'expense').reduce((a, b) => a + b.amount, 0);
  const totalIncome = txs.filter((t) => t.type === 'income').reduce((a, b) => a + b.amount, 0);
  const totalPurchases = purchases.reduce((a, b) => a + b.price, 0);
  const totalMaint = maintenance.reduce((a, b) => a + b.cost, 0);

  return (
    <div className="space-y-6">
      {/* Top Export & Period Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-white/6 p-1 rounded-xl border border-white/10">
          {(['monthly', 'quarterly', 'yearly'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold cursor-pointer ${
                period === p ? 'bg-[#FF7900] text-white' : 'text-white/70'
              }`}
            >
              {p === 'monthly' ? (isAr ? 'شهري' : 'Monthly') : p === 'quarterly' ? (isAr ? 'ربع سنوي' : 'Quarterly') : isAr ? 'سنوي' : 'Yearly'}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={handleExportExcel}
            className="min-h-[44px] px-4 rounded-xl bg-emerald-500/20 border border-emerald-500/35 text-emerald-300 text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
          >
            <FileSpreadsheet size={16} />
            <span>{isAr ? 'تصدير Excel' : 'Export Excel'}</span>
          </button>
          <PrimaryButton onClick={handleExportPdf}>
            <Download size={16} />
            <span>{isAr ? 'تصدير PDF' : 'Export PDF'}</span>
          </PrimaryButton>
        </div>
      </div>

      {/* 10 Report Type Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {reportTabs.map((r) => (
          <button
            key={r.id}
            onClick={() => setTab(r.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer ${
              tab === r.id ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/75 hover:bg-white/10'
            }`}
          >
            {isAr ? r.ar : r.en}
          </button>
        ))}
      </div>

      {/* KPI Row + Monthly Comparison Bar Chart */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'إجمالي المصروفات' : 'Total Expenses'}</p>
          <p className="text-xl font-bold font-mono-num text-[#FF7900] mt-1">{formatCurrency(totalExpenses, lang)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'إجمالي الدخل' : 'Total Income'}</p>
          <p className="text-xl font-bold font-mono-num text-emerald-400 mt-1">{formatCurrency(totalIncome, lang)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'إجمالي المشتريات' : 'Total Purchases'}</p>
          <p className="text-xl font-bold font-mono-num mt-1">{formatCurrency(totalPurchases, lang)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'تكاليف الصيانة' : 'Maintenance'}</p>
          <p className="text-xl font-bold font-mono-num mt-1">{formatCurrency(totalMaint, lang)}</p>
        </GlassCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <GlassCard className="p-5 lg:col-span-5 space-y-4">
          <h4 className="text-sm font-bold">{isAr ? 'المقارنة الشهرية للمصروفات' : 'Monthly Expense Comparison'}</h4>
          {monthlyBars.length === 0 ? (
            <p className="text-xs opacity-60 py-10 text-center">{isAr ? 'أضف مصروفات لعرض الرسم البياني.' : 'Add expenses to visualize trends.'}</p>
          ) : (
            <div className="flex items-end gap-3 h-48 pt-4">
              {monthlyBars.map((b) => (
                <div key={b.label} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                  <span className="text-[10px] font-mono-num opacity-75">{Math.round(b.value)}</span>
                  <div
                    className="w-full max-w-[36px] rounded-t-xl bg-gradient-to-t from-[#FF7900] to-amber-400 transition-all duration-300"
                    style={{ height: `${Math.max(10, b.pct)}%` }}
                  />
                  <span className="text-[10px] font-mono-num opacity-60">{b.label.slice(2)}</span>
                </div>
              ))}
            </div>
          )}
        </GlassCard>

        <GlassCard className="p-5 lg:col-span-7 space-y-3">
          <h4 className="text-sm font-bold">
            {isAr ? 'جدول التقرير التفصيلي' : 'Detailed Report Table'} ({rowsForExport.length})
          </h4>
          {rowsForExport.length === 0 ? (
            <div className="py-12 text-center text-sm opacity-60">{isAr ? 'لا توجد سجلات في هذا التقرير بعد.' : 'No rows in this report yet.'}</div>
          ) : (
            <div className="overflow-x-auto max-h-[340px]">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-white/10 text-white/65">
                    {Object.keys(rowsForExport[0]).map((col) => (
                      <th key={col} className="py-2 px-3 text-start font-semibold">
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/8">
                  {rowsForExport.map((r, i) => (
                    <tr key={i} className="hover:bg-white/[0.04]">
                      {Object.values(r).map((val, j) => (
                        <td key={j} className="py-2.5 px-3 font-mono-num whitespace-nowrap">
                          {String(val)}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </GlassCard>
      </div>
    </div>
  );
};
