import React, { useEffect, useMemo, useState } from 'react';
import { BellRing, Plus, Repeat, Trash2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatCurrency } from '../lib/i18n';
import type { Language, SubscriptionItem } from '../types';
import { DynamicIcon } from '../components/DynamicIcon';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

export const SubscriptionsModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [subs, setSubs] = useState<SubscriptionItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'active' | 'expiring' | 'expired' | 'cancelled'>('all');
  const [modalOpen, setModalOpen] = useState(false);

  const [form, setForm] = useState({
    service_name: '',
    logo_icon: 'Repeat',
    color: '#FF7900',
    price: '',
    currency: 'SAR',
    start_date: new Date().toISOString().slice(0, 10),
    renewal_date: new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10),
    billing_cycle: 'monthly' as 'monthly' | 'yearly' | 'weekly',
    status: 'active' as 'active' | 'expiring' | 'expired' | 'cancelled',
    notes: '',
  });

  const load = async () => {
    const res = await apiFetch<{ subscriptions: SubscriptionItem[] }>('/api/subscriptions');
    setSubs(res.subscriptions || []);
  };

  useEffect(() => {
    load();
  }, []);

  const totals = useMemo(() => {
    let monthly = 0;
    for (const s of subs) {
      if (s.status === 'cancelled' || s.status === 'expired') continue;
      if (s.billing_cycle === 'monthly') monthly += s.price;
      else if (s.billing_cycle === 'yearly') monthly += s.price / 12;
      else monthly += s.price * 4.33;
    }
    return { monthly, yearly: monthly * 12 };
  }, [subs]);

  const expiringAlerts = useMemo(() => {
    const now = Date.now();
    return subs.filter((s) => {
      if (s.status === 'cancelled' || s.status === 'expired') return false;
      const diffDays = Math.ceil((new Date(s.renewal_date).getTime() - now) / 86400000);
      return diffDays >= 0 && diffDays <= 7;
    });
  }, [subs]);

  const filtered = useMemo(
    () => (filter === 'all' ? subs : subs.filter((s) => s.status === filter)),
    [subs, filter]
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/subscriptions', {
      method: 'POST',
      body: JSON.stringify({ ...form, price: Number(form.price || 0) }),
    });
    setModalOpen(false);
    setForm({ ...form, service_name: '', price: '', notes: '' });
    load();
  };

  const statusText = (st: string) => {
    if (st === 'active') return isAr ? 'نشط' : 'Active';
    if (st === 'expiring') return isAr ? 'قريب التجديد' : 'Renewing Soon';
    if (st === 'expired') return isAr ? 'منتهٍ' : 'Expired';
    return isAr ? 'ملغي' : 'Cancelled';
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {(['all', 'active', 'expiring', 'expired', 'cancelled'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setFilter(st)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer whitespace-nowrap ${
                filter === st ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/75'
              }`}
            >
              {st === 'all' ? (isAr ? 'الكل' : 'All') : statusText(st)}
            </button>
          ))}
        </div>

        <PrimaryButton onClick={() => setModalOpen(true)}>
          <Plus size={16} />
          <span>{isAr ? 'إضافة اشتراك' : 'Add Subscription'}</span>
        </PrimaryButton>
      </div>

      {/* Summary & Renewal Alerts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <GlassCard className="p-5">
          <p className="text-xs opacity-60">{isAr ? 'التكلفة الشهرية' : 'Monthly Cost'}</p>
          <p className="text-2xl font-bold font-mono-num text-[#FF7900] mt-1">{formatCurrency(totals.monthly, lang)}</p>
        </GlassCard>
        <GlassCard className="p-5">
          <p className="text-xs opacity-60">{isAr ? 'التكلفة السنوية' : 'Annual Cost'}</p>
          <p className="text-2xl font-bold font-mono-num mt-1">{formatCurrency(totals.yearly, lang)}</p>
        </GlassCard>
        <GlassCard className="p-5 flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
            <BellRing size={20} />
          </div>
          <div>
            <p className="text-xs opacity-65">{isAr ? 'تنبيهات التجديد (7 أيام)' : 'Upcoming Renewals (7d)'}</p>
            <p className="text-lg font-bold font-mono-num">{expiringAlerts.length}</p>
          </div>
        </GlassCard>
      </div>

      {/* Subscriptions Grid */}
      {filtered.length === 0 ? (
        <GlassCard className="p-10 text-center space-y-3">
          <Repeat size={36} className="mx-auto opacity-35" />
          <p className="text-sm opacity-70">{isAr ? 'لا توجد اشتراكات مطابقة.' : 'No subscriptions found.'}</p>
        </GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((s) => {
            const daysLeft = Math.ceil((new Date(s.renewal_date).getTime() - Date.now()) / 86400000);
            return (
              <GlassCard key={s.id} className="p-4 space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className="w-12 h-12 rounded-2xl flex items-center justify-center border border-white/15 shrink-0"
                      style={{ backgroundColor: `${s.color}25` }}
                    >
                      <DynamicIcon name={s.logo_icon || 'Repeat'} size={22} color={s.color || '#FF7900'} />
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-bold text-sm truncate">{s.service_name}</h4>
                      <p className="text-xs opacity-60 font-mono-num">
                        {formatCurrency(s.price, lang)} / {s.billing_cycle}
                      </p>
                    </div>
                  </div>
                  <span
                    className={`text-xs font-semibold ${
                      s.status === 'active'
                        ? 'text-emerald-400'
                        : s.status === 'expiring'
                        ? 'text-amber-400'
                        : 'text-red-400'
                    }`}
                  >
                    {statusText(s.status)}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs pt-2 border-t border-white/8">
                  <span className="opacity-70 font-mono-num">
                    {isAr ? 'التجديد:' : 'Renews:'} {s.renewal_date} ({daysLeft >= 0 ? `${daysLeft}d` : isAr ? 'منتهٍ' : 'past'})
                  </span>
                  <div className="flex items-center gap-1.5">
                    <select
                      value={s.status}
                      onChange={async (e) => {
                        await apiFetch(`/api/subscriptions/${s.id}`, {
                          method: 'PATCH',
                          body: JSON.stringify({ status: e.target.value }),
                        });
                        load();
                      }}
                      className="rounded-lg bg-[#18181b] border border-white/10 px-2 py-1 text-[11px]"
                    >
                      <option value="active">{isAr ? 'نشط' : 'Active'}</option>
                      <option value="expiring">{isAr ? 'قريب التجديد' : 'Expiring'}</option>
                      <option value="expired">{isAr ? 'منتهٍ' : 'Expired'}</option>
                      <option value="cancelled">{isAr ? 'ملغي' : 'Cancelled'}</option>
                    </select>
                    <button
                      onClick={async () => {
                        await apiFetch(`/api/subscriptions/${s.id}`, { method: 'DELETE' });
                        load();
                      }}
                      className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </GlassCard>
            );
          })}
        </div>
      )}

      <GlassModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={isAr ? 'إضافة اشتراك جديد' : 'Add Subscription'}
      >
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <InputField
            label={isAr ? 'اسم الخدمة' : 'Service Name'}
            value={form.service_name}
            onChange={(e) => setForm({ ...form, service_name: e.target.value })}
            required
          />
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label={isAr ? 'السعر' : 'Price'}
              type="number"
              step="0.01"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              required
            />
            <SelectField
              label={isAr ? 'دورة الفوترة' : 'Billing Cycle'}
              value={form.billing_cycle}
              onChange={(e) => setForm({ ...form, billing_cycle: e.target.value as 'monthly' | 'yearly' | 'weekly' })}
            >
              <option value="monthly">{isAr ? 'شهري' : 'Monthly'}</option>
              <option value="yearly">{isAr ? 'سنوي' : 'Yearly'}</option>
              <option value="weekly">{isAr ? 'أسبوعي' : 'Weekly'}</option>
            </SelectField>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label={isAr ? 'تاريخ البداية' : 'Start Date'}
              type="date"
              value={form.start_date}
              onChange={(e) => setForm({ ...form, start_date: e.target.value })}
            />
            <InputField
              label={isAr ? 'تاريخ التجديد' : 'Renewal Date'}
              type="date"
              value={form.renewal_date}
              onChange={(e) => setForm({ ...form, renewal_date: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <SelectField
              label={isAr ? 'الحالة' : 'Status'}
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value as typeof form.status })}
            >
              <option value="active">{isAr ? 'نشط' : 'Active'}</option>
              <option value="expiring">{isAr ? 'قريب التجديد' : 'Expiring Soon'}</option>
              <option value="expired">{isAr ? 'منتهٍ' : 'Expired'}</option>
              <option value="cancelled">{isAr ? 'ملغي' : 'Cancelled'}</option>
            </SelectField>
            <label className="block space-y-1.5">
              <span className="block text-xs font-medium opacity-75">{isAr ? 'لون الخدمة' : 'Color'}</span>
              <input
                type="color"
                value={form.color}
                onChange={(e) => setForm({ ...form, color: e.target.value })}
                className="w-full h-[44px] rounded-xl bg-white/5 border border-white/12 p-1 cursor-pointer"
              />
            </label>
          </div>
          <InputField
            label={isAr ? 'ملاحظات' : 'Notes'}
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-xl bg-white/8 text-sm cursor-pointer">
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <PrimaryButton type="submit">{isAr ? 'حفظ الاشتراك' : 'Save Subscription'}</PrimaryButton>
          </div>
        </form>
      </GlassModal>
    </div>
  );
};
