import React, { useEffect, useMemo, useState } from 'react';
import { Plus, ShoppingBag, Trash2, Store, Tag } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatCurrency } from '../lib/i18n';
import type { DocumentItem, Language, PurchaseItem } from '../types';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

const PURCHASE_CATEGORIES = [
  { id: 'electronics', ar: 'إلكترونيات', en: 'Electronics' },
  { id: 'clothing', ar: 'ملابس', en: 'Clothing' },
  { id: 'home_appliances', ar: 'أجهزة منزلية', en: 'Home Appliances' },
  { id: 'groceries', ar: 'أغذية', en: 'Groceries' },
  { id: 'furniture', ar: 'أثاث', en: 'Furniture' },
  { id: 'automotive', ar: 'سيارات', en: 'Automotive' },
  { id: 'other', ar: 'أخرى', en: 'Other' },
];

export const PurchasesModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [items, setItems] = useState<PurchaseItem[]>([]);
  const [docs, setDocs] = useState<DocumentItem[]>([]);
  const [catFilter, setCatFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);

  const [form, setForm] = useState({
    product_name: '',
    image_url: '',
    price: '',
    store: '',
    purchase_date: new Date().toISOString().slice(0, 10),
    order_number: '',
    status: 'delivered',
    payment_method: 'card',
    category: 'electronics',
    warranty_months: '12',
    invoice_doc_id: '',
    notes: '',
  });

  const load = async () => {
    const [pRes, dRes] = await Promise.all([
      apiFetch<{ purchases: PurchaseItem[] }>('/api/purchases'),
      apiFetch<{ documents: DocumentItem[] }>('/api/documents'),
    ]);
    setItems(pRes.purchases || []);
    setDocs(dRes.documents || []);
  };

  useEffect(() => {
    load();
  }, []);

  const stats = useMemo(() => {
    const now = new Date();
    const ym = now.toISOString().slice(0, 7);
    const yr = now.toISOString().slice(0, 4);
    let total = 0;
    let monthTotal = 0;
    let yearTotal = 0;
    const storeCounts: Record<string, number> = {};
    const catSpend: Record<string, number> = {};

    for (const p of items) {
      total += p.price;
      if (p.purchase_date.startsWith(ym)) monthTotal += p.price;
      if (p.purchase_date.startsWith(yr)) yearTotal += p.price;
      if (p.store) storeCounts[p.store] = (storeCounts[p.store] || 0) + 1;
      catSpend[p.category] = (catSpend[p.category] || 0) + p.price;
    }

    const topStore = Object.entries(storeCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '—';
    const topCatKey = Object.entries(catSpend).sort((a, b) => b[1] - a[1])[0]?.[0];
    const topCat = PURCHASE_CATEGORIES.find((c) => c.id === topCatKey);

    return {
      total,
      monthTotal,
      yearTotal,
      topStore,
      topCategory: topCat ? (isAr ? topCat.ar : topCat.en) : '—',
    };
  }, [items, isAr]);

  const filtered = useMemo(
    () => (catFilter === 'all' ? items : items.filter((p) => p.category === catFilter)),
    [items, catFilter]
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await apiFetch('/api/purchases', {
      method: 'POST',
      body: JSON.stringify({
        ...form,
        price: Number(form.price || 0),
        warranty_months: Number(form.warranty_months || 0),
        invoice_doc_id: form.invoice_doc_id || null,
      }),
    });
    setModalOpen(false);
    setForm({
      product_name: '',
      image_url: '',
      price: '',
      store: '',
      purchase_date: new Date().toISOString().slice(0, 10),
      order_number: '',
      status: 'delivered',
      payment_method: 'card',
      category: 'electronics',
      warranty_months: '12',
      invoice_doc_id: '',
      notes: '',
    });
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setCatFilter('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer whitespace-nowrap ${
              catFilter === 'all' ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/75'
            }`}
          >
            {isAr ? 'الكل' : 'All'}
          </button>
          {PURCHASE_CATEGORIES.map((c) => (
            <button
              key={c.id}
              onClick={() => setCatFilter(c.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer whitespace-nowrap ${
                catFilter === c.id ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/75'
              }`}
            >
              {isAr ? c.ar : c.en}
            </button>
          ))}
        </div>

        <PrimaryButton onClick={() => setModalOpen(true)}>
          <Plus size={16} />
          <span>{isAr ? 'إضافة عملية شراء' : 'Add Purchase'}</span>
        </PrimaryButton>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3.5">
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'إجمالي المشتريات' : 'Total Purchases'}</p>
          <p className="text-xl font-bold font-mono-num mt-1">{formatCurrency(stats.total, lang)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'مشتريات الشهر' : 'This Month'}</p>
          <p className="text-xl font-bold font-mono-num text-[#FF7900] mt-1">{formatCurrency(stats.monthTotal, lang)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'مشتريات السنة' : 'This Year'}</p>
          <p className="text-xl font-bold font-mono-num mt-1">{formatCurrency(stats.yearTotal, lang)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60 flex items-center gap-1">
            <Store size={12} /> {isAr ? 'أكثر متجر' : 'Top Store'}
          </p>
          <p className="text-lg font-bold truncate mt-1">{stats.topStore}</p>
        </GlassCard>
        <GlassCard className="p-4 col-span-2 lg:col-span-1">
          <p className="text-xs opacity-60 flex items-center gap-1">
            <Tag size={12} /> {isAr ? 'أعلى تصنيف' : 'Top Category'}
          </p>
          <p className="text-lg font-bold truncate mt-1">{stats.topCategory}</p>
        </GlassCard>
      </div>

      {/* Purchases List */}
      {filtered.length === 0 ? (
        <GlassCard className="p-10 text-center space-y-3">
          <ShoppingBag size={36} className="mx-auto opacity-35" />
          <p className="text-sm opacity-70">{isAr ? 'لا توجد مشتريات مسجلة في هذا التصنيف.' : 'No purchases recorded yet.'}</p>
        </GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((p) => {
            const catLabel = PURCHASE_CATEGORIES.find((c) => c.id === p.category);
            return (
              <GlassCard key={p.id} className="p-4 flex flex-col justify-between gap-3">
                <div className="flex items-start gap-3">
                  {p.image_url ? (
                    <img
                      src={p.image_url}
                      alt={p.product_name}
                      referrerPolicy="no-referrer"
                      className="w-14 h-14 rounded-2xl object-cover border border-white/10 shrink-0"
                    />
                  ) : (
                    <div className="w-14 h-14 rounded-2xl bg-[#FF7900]/15 border border-[#FF7900]/30 flex items-center justify-center text-[#FF7900] shrink-0">
                      <ShoppingBag size={22} />
                    </div>
                  )}
                  <div className="min-w-0 flex-1">
                    <h4 className="font-bold text-sm truncate">{p.product_name}</h4>
                    <p className="text-xs opacity-65 mt-0.5">
                      {p.store || '—'} · {catLabel ? (isAr ? catLabel.ar : catLabel.en) : p.category}
                    </p>
                    <p className="text-xs opacity-50 font-mono-num mt-0.5">
                      {p.purchase_date} {p.order_number ? `· #${p.order_number}` : ''}
                    </p>
                  </div>
                  <span className="text-sm font-bold font-mono-num text-[#FF7900] shrink-0">
                    {formatCurrency(p.price, lang)}
                  </span>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-white/8 text-xs">
                  <span className="opacity-70">
                    {p.status} · {p.payment_method}
                    {p.warranty_months > 0 ? ` · ${isAr ? 'ضمان' : 'Warranty'} ${p.warranty_months}m` : ''}
                  </span>
                  <button
                    onClick={async () => {
                      await apiFetch(`/api/purchases/${p.id}`, { method: 'DELETE' });
                      load();
                    }}
                    className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </GlassCard>
            );
          })}
        </div>
      )}

      <GlassModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={isAr ? 'إضافة عملية شراء جديدة' : 'Add New Purchase'}
      >
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <InputField
            label={isAr ? 'اسم المنتج' : 'Product Name'}
            value={form.product_name}
            onChange={(e) => setForm({ ...form, product_name: e.target.value })}
            required
          />
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label={isAr ? 'السعر' : 'Price'}
              type="number"
              step="0.01"
              value={form.price}
              onChange={(e) => setForm({ ...form, price: e.target.value })}
              required
            />
            <InputField
              label={isAr ? 'المتجر' : 'Store'}
              value={form.store}
              onChange={(e) => setForm({ ...form, store: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label={isAr ? 'تاريخ الشراء' : 'Purchase Date'}
              type="date"
              value={form.purchase_date}
              onChange={(e) => setForm({ ...form, purchase_date: e.target.value })}
            />
            <SelectField
              label={isAr ? 'التصنيف' : 'Category'}
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
            >
              {PURCHASE_CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {isAr ? c.ar : c.en}
                </option>
              ))}
            </SelectField>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label={isAr ? 'رقم الطلب' : 'Order Number'}
              value={form.order_number}
              onChange={(e) => setForm({ ...form, order_number: e.target.value })}
            />
            <SelectField
              label={isAr ? 'حالة الطلب' : 'Order Status'}
              value={form.status}
              onChange={(e) => setForm({ ...form, status: e.target.value })}
            >
              <option value="delivered">{isAr ? 'تم التسليم' : 'Delivered'}</option>
              <option value="shipped">{isAr ? 'قيد الشحن' : 'Shipped'}</option>
              <option value="processing">{isAr ? 'قيد التجهيز' : 'Processing'}</option>
              <option value="returned">{isAr ? 'مرتجع' : 'Returned'}</option>
            </SelectField>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <SelectField
              label={isAr ? 'طريقة الدفع' : 'Payment Method'}
              value={form.payment_method}
              onChange={(e) => setForm({ ...form, payment_method: e.target.value })}
            >
              <option value="card">{isAr ? 'بطاقة بنكية' : 'Card'}</option>
              <option value="cash">{isAr ? 'نقدي' : 'Cash'}</option>
              <option value="apple_pay">Apple Pay</option>
              <option value="transfer">{isAr ? 'تحويل بنكي' : 'Bank Transfer'}</option>
            </SelectField>
            <InputField
              label={isAr ? 'مدة الضمان (أشهر)' : 'Warranty (Months)'}
              type="number"
              value={form.warranty_months}
              onChange={(e) => setForm({ ...form, warranty_months: e.target.value })}
            />
          </div>
          <SelectField
            label={isAr ? 'ربط بفاتورة من المستندات' : 'Link Invoice Document'}
            value={form.invoice_doc_id}
            onChange={(e) => setForm({ ...form, invoice_doc_id: e.target.value })}
          >
            <option value="">{isAr ? 'بدون فاتورة' : 'None'}</option>
            {docs.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}.{d.ext}
              </option>
            ))}
          </SelectField>
          <InputField
            label={isAr ? 'ملاحظات' : 'Notes'}
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-xl bg-white/8 text-sm cursor-pointer">
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <PrimaryButton type="submit">{isAr ? 'حفظ الشراء' : 'Save Purchase'}</PrimaryButton>
          </div>
        </form>
      </GlassModal>
    </div>
  );
};
