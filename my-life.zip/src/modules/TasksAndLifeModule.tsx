import React, { useEffect, useMemo, useState } from 'react';
import { Award, CheckCircle2, Circle, Plus, Target, Trash2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { Language, TaskItem } from '../types';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

const TASK_CATS = [
  { id: 'daily', ar: 'يومية', en: 'Daily' },
  { id: 'work', ar: 'العمل', en: 'Work' },
  { id: 'study', ar: 'الدراسة', en: 'Study' },
  { id: 'home', ar: 'المنزل', en: 'Home' },
  { id: 'family', ar: 'العائلة', en: 'Family' },
  { id: 'shopping', ar: 'قائمة المشتريات', en: 'Shopping List' },
  { id: 'responsibility', ar: 'المسؤوليات', en: 'Responsibilities' },
];

export const TasksAndLifeModule: React.FC<{
  lang: Language;
  mode: 'tasks' | 'goals' | 'mylife';
}> = ({ lang, mode }) => {
  const isAr = lang === 'ar';
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [catFilter, setCatFilter] = useState('all');
  const [modalOpen, setModalOpen] = useState(false);

  const [form, setForm] = useState({
    title: '',
    category: 'daily' as TaskItem['category'],
    priority: 'medium' as TaskItem['priority'],
    due_date: new Date().toISOString().slice(0, 10),
    due_time: '09:00',
    recurrence: 'none' as TaskItem['recurrence'],
    is_goal: mode === 'goals',
    progress: '0',
  });

  const load = async () => {
    const res = await apiFetch<{ tasks: TaskItem[] }>('/api/tasks');
    setTasks(res.tasks || []);
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    let list = tasks;
    if (mode === 'goals') list = list.filter((t) => t.is_goal === 1);
    else if (mode === 'tasks') list = list.filter((t) => t.is_goal === 0);
    if (catFilter !== 'all') list = list.filter((t) => t.category === catFilter);
    return list;
  }, [tasks, mode, catFilter]);

  const completedCount = filtered.filter((t) => t.completed === 1).length;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setCatFilter('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer whitespace-nowrap ${
              catFilter === 'all' ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/75'
            }`}
          >
            {isAr ? 'الكل' : 'All'}
          </button>
          {TASK_CATS.map((c) => (
            <button
              key={c.id}
              onClick={() => setCatFilter(c.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer whitespace-nowrap ${
                catFilter === c.id ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/75'
              }`}
            >
              {isAr ? c.ar : c.en}
            </button>
          ))}
        </div>

        <PrimaryButton
          onClick={() => {
            setForm((f) => ({ ...f, is_goal: mode === 'goals' }));
            setModalOpen(true);
          }}
        >
          <Plus size={16} />
          <span>{mode === 'goals' ? (isAr ? 'إضافة هدف' : 'Add Goal') : isAr ? 'إضافة مهمة' : 'Add Task'}</span>
        </PrimaryButton>
      </div>

      {/* Achievements Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <GlassCard className="p-4 flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-[#FF7900]/15 text-[#FF7900] flex items-center justify-center">
            {mode === 'goals' ? <Target size={20} /> : <Award size={20} />}
          </div>
          <div>
            <p className="text-xs opacity-60">{isAr ? 'الإجمالي' : 'Total'}</p>
            <p className="text-xl font-bold font-mono-num">{filtered.length}</p>
          </div>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'الإنجازات المكتملة' : 'Completed'}</p>
          <p className="text-xl font-bold font-mono-num text-emerald-400 mt-1">{completedCount}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'معدل الإنجاز' : 'Completion Rate'}</p>
          <p className="text-xl font-bold font-mono-num mt-1">
            {filtered.length > 0 ? Math.round((completedCount / filtered.length) * 100) : 0}%
          </p>
        </GlassCard>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <GlassCard className="p-10 text-center text-sm opacity-65">
          {isAr ? 'لا توجد مهام أو أهداف مسجلة بعد.' : 'No tasks or goals recorded yet.'}
        </GlassCard>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((t) => {
            const cat = TASK_CATS.find((c) => c.id === t.category);
            return (
              <GlassCard key={t.id} className="p-4 flex items-center justify-between gap-4">
                <button
                  onClick={async () => {
                    await apiFetch(`/api/tasks/${t.id}`, {
                      method: 'PATCH',
                      body: JSON.stringify({ completed: t.completed ? 0 : 1, progress: t.completed ? t.progress : 100 }),
                    });
                    load();
                  }}
                  className="flex items-center gap-3.5 text-start flex-1 min-w-0 cursor-pointer"
                >
                  {t.completed ? (
                    <CheckCircle2 size={22} className="text-emerald-400 shrink-0" />
                  ) : (
                    <Circle size={22} className="text-white/40 hover:text-[#FF7900] shrink-0" />
                  )}
                  <div className="min-w-0 flex-1">
                    <p className={`text-sm font-semibold truncate ${t.completed ? 'line-through opacity-50' : ''}`}>
                      {t.title}
                    </p>
                    <p className="text-xs opacity-55 mt-0.5">
                      {cat ? (isAr ? cat.ar : cat.en) : t.category} · {t.priority}
                      {t.due_date ? ` · ${t.due_date}` : ''}
                      {t.recurrence !== 'none' ? ` · ${t.recurrence}` : ''}
                    </p>
                  </div>
                </button>

                <div className="flex items-center gap-3 shrink-0">
                  {t.is_goal === 1 && (
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min={0}
                        max={100}
                        value={t.progress}
                        onChange={async (e) => {
                          const prog = Number(e.target.value);
                          await apiFetch(`/api/tasks/${t.id}`, {
                            method: 'PATCH',
                            body: JSON.stringify({ progress: prog, completed: prog === 100 ? 1 : 0 }),
                          });
                          load();
                        }}
                        className="w-20 accent-[#FF7900]"
                      />
                      <span className="text-xs font-mono-num w-9">{t.progress}%</span>
                    </div>
                  )}
                  <button
                    onClick={async () => {
                      await apiFetch(`/api/tasks/${t.id}`, { method: 'DELETE' });
                      load();
                    }}
                    className="p-2 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </GlassCard>
            );
          })}
        </div>
      )}

      <GlassModal open={modalOpen} onClose={() => setModalOpen(false)} title={form.is_goal ? (isAr ? 'هدف شخصي جديد' : 'New Goal') : isAr ? 'مهمة جديدة' : 'New Task'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/tasks', {
              method: 'POST',
              body: JSON.stringify({ ...form, progress: Number(form.progress || 0) }),
            });
            setModalOpen(false);
            setForm({ ...form, title: '' });
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'العنوان' : 'Title'} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <div className="grid grid-cols-2 gap-3">
            <SelectField label={isAr ? 'القسم' : 'Category'} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as TaskItem['category'] })}>
              {TASK_CATS.map((c) => (
                <option key={c.id} value={c.id}>
                  {isAr ? c.ar : c.en}
                </option>
              ))}
            </SelectField>
            <SelectField label={isAr ? 'الأولوية' : 'Priority'} value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as TaskItem['priority'] })}>
              <option value="low">{isAr ? 'منخفضة' : 'Low'}</option>
              <option value="medium">{isAr ? 'متوسطة' : 'Medium'}</option>
              <option value="high">{isAr ? 'عالية' : 'High'}</option>
            </SelectField>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'التاريخ' : 'Due Date'} type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
            <SelectField label={isAr ? 'التكرار' : 'Recurrence'} value={form.recurrence} onChange={(e) => setForm({ ...form, recurrence: e.target.value as TaskItem['recurrence'] })}>
              <option value="none">{isAr ? 'مرة واحدة' : 'None'}</option>
              <option value="daily">{isAr ? 'يومي' : 'Daily'}</option>
              <option value="weekly">{isAr ? 'أسبوعي' : 'Weekly'}</option>
              <option value="monthly">{isAr ? 'شهري' : 'Monthly'}</option>
            </SelectField>
          </div>
          <PrimaryButton type="submit" className="w-full">
            {isAr ? 'حفظ' : 'Save'}
          </PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};
