import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Copy,
  Eye,
  File,
  FolderPlus,
  Heart,
  MoveRight,
  RotateCcw,
  Search,
  Share2,
  Trash2,
  UploadCloud,
  Info,
  ArrowUp,
  ArrowDown,
} from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { CardStyle, DocumentItem, FolderItem, Language } from '../types';
import { Folder3D } from '../components/Folder3D';
import { DocumentViewerModal } from '../components/DocumentViewerModal';
import { IconPickerModal } from '../components/IconPickerModal';
import { DynamicIcon } from '../components/DynamicIcon';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

const FOLDER_COLORS = [
  { label: 'أزرق', hex: '#3B82F6' },
  { label: 'بنفسجي', hex: '#8B5CF6' },
  { label: 'أخضر', hex: '#10B981' },
  { label: 'أصفر', hex: '#FACC15' },
  { label: 'وردي', hex: '#EC4899' },
  { label: 'ذهبي', hex: '#F59E0B' },
  { label: 'برتقالي', hex: '#FF7900' },
  { label: 'رمادي', hex: '#64748B' },
  { label: 'أبيض', hex: '#FFFFFF' },
  { label: 'أسود', hex: '#18181B' },
  { label: 'بني', hex: '#92400E' },
];

export const DocumentsModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [folders, setFolders] = useState<FolderItem[]>([]);
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [trashDocs, setTrashDocs] = useState<DocumentItem[]>([]);
  const [tab, setTab] = useState<'folders' | 'recent' | 'favorites' | 'trash'>('folders');
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [extFilter, setExtFilter] = useState('all');
  const [sortBy, setSortBy] = useState<'date' | 'name' | 'size'>('date');
  const [viewerDoc, setViewerDoc] = useState<DocumentItem | null>(null);
  const [infoDoc, setInfoDoc] = useState<DocumentItem | null>(null);
  const [moveDoc, setMoveDoc] = useState<{ doc: DocumentItem; mode: 'move' | 'copy' } | null>(null);
  const [targetFolderId, setTargetFolderId] = useState<string>('');
  const [draggingOver, setDraggingOver] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [statusMsg, setStatusMsg] = useState('');

  // Folder Create / Customize Modal state
  const [folderModalOpen, setFolderModalOpen] = useState(false);
  const [editingFolder, setEditingFolder] = useState<FolderItem | null>(null);
  const [fName, setFName] = useState('');
  const [fColor, setFColor] = useState('#FF7900');
  const [fOpacity, setFOpacity] = useState(84);
  const [fIcon, setFIcon] = useState('Folder');
  const [fStyle, setFStyle] = useState<CardStyle>('glass');
  const [iconPickerOpen, setIconPickerOpen] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const loadAll = useCallback(async () => {
    const [fRes, dRes, tRes] = await Promise.all([
      apiFetch<{ folders: FolderItem[] }>('/api/folders'),
      apiFetch<{ documents: DocumentItem[] }>('/api/documents'),
      apiFetch<{ documents: DocumentItem[] }>('/api/documents?trash=1'),
    ]);
    setFolders(fRes.folders || []);
    setDocuments(dRes.documents || []);
    setTrashDocs(tRes.documents || []);
  }, []);

  useEffect(() => {
    loadAll();
  }, [loadAll]);

  const activeFolder = folders.find((f) => f.id === activeFolderId) || null;

  const openNewFolderModal = () => {
    setEditingFolder(null);
    setFName('');
    setFColor('#FF7900');
    setFOpacity(84);
    setFIcon('Folder');
    setFStyle('glass');
    setFolderModalOpen(true);
  };

  const openCustomizeFolder = (folder: FolderItem) => {
    setEditingFolder(folder);
    setFName(folder.name);
    setFColor(folder.color_hex);
    setFOpacity(folder.opacity ?? 84);
    setFIcon(folder.icon_name || 'Folder');
    setFStyle(folder.style || 'glass');
    setFolderModalOpen(true);
  };

  const handleSaveFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!fName.trim()) return;
    if (editingFolder) {
      await apiFetch(`/api/folders/${editingFolder.id}`, {
        method: 'PATCH',
        body: JSON.stringify({
          name: fName.trim(),
          color_hex: fColor,
          opacity: fOpacity,
          icon_name: fIcon,
          style: fStyle,
        }),
      });
    } else {
      await apiFetch('/api/folders', {
        method: 'POST',
        body: JSON.stringify({
          name: fName.trim(),
          color_hex: fColor,
          opacity: fOpacity,
          icon_name: fIcon,
          style: fStyle,
        }),
      });
    }
    setFolderModalOpen(false);
    loadAll();
  };

  const handleDuplicateFolder = async () => {
    if (!editingFolder) return;
    await apiFetch(`/api/folders/${editingFolder.id}/duplicate`, { method: 'POST' });
    setFolderModalOpen(false);
    loadAll();
  };

  const handleDeleteFolder = async () => {
    if (!editingFolder) return;
    await apiFetch(`/api/folders/${editingFolder.id}`, { method: 'DELETE' });
    if (activeFolderId === editingFolder.id) setActiveFolderId(null);
    setFolderModalOpen(false);
    loadAll();
  };

  const handleReorderFolder = async (folderId: string, dir: -1 | 1) => {
    const idx = folders.findIndex((f) => f.id === folderId);
    const swapIdx = idx + dir;
    if (idx === -1 || swapIdx < 0 || swapIdx >= folders.length) return;
    const next = [...folders];
    const [moved] = next.splice(idx, 1);
    next.splice(swapIdx, 0, moved);
    setFolders(next);
    await apiFetch('/api/folders/reorder', {
      method: 'PATCH',
      body: JSON.stringify({ ids: next.map((f) => f.id) }),
    });
  };

  const handleUploadFiles = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    setUploading(true);
    setStatusMsg('');
    try {
      const fd = new FormData();
      if (activeFolderId) fd.append('folder_id', activeFolderId);
      Array.from(fileList).forEach((file) => fd.append('files', file));
      await apiFetch('/api/documents/upload', { method: 'POST', body: fd });
      setStatusMsg(isAr ? `تم رفع ${fileList.length} ملف بنجاح` : `Uploaded ${fileList.length} file(s)`);
      await loadAll();
    } catch (err) {
      setStatusMsg((err as Error).message);
    } finally {
      setUploading(false);
    }
  };

  const handleMoveOrCopy = async () => {
    if (!moveDoc) return;
    const fid = targetFolderId || null;
    if (moveDoc.mode === 'move') {
      await apiFetch(`/api/documents/${moveDoc.doc.id}`, {
        method: 'PATCH',
        body: JSON.stringify({ folder_id: fid }),
      });
    } else {
      await apiFetch(`/api/documents/${moveDoc.doc.id}/copy`, {
        method: 'POST',
        body: JSON.stringify({ folder_id: fid }),
      });
    }
    setMoveDoc(null);
    loadAll();
  };

  const filteredDocs = useMemo(() => {
    let list = tab === 'trash' ? trashDocs : documents;
    if (activeFolderId && tab === 'folders') {
      list = list.filter((d) => d.folder_id === activeFolderId);
    }
    if (tab === 'favorites') {
      list = list.filter((d) => d.is_favorite === 1);
    }
    if (extFilter !== 'all') {
      list = list.filter((d) => {
        const e = d.ext.toLowerCase();
        if (extFilter === 'images') return ['jpg', 'jpeg', 'png', 'webp'].includes(e);
        if (extFilter === 'office') return ['docx', 'xlsx', 'pptx'].includes(e);
        return e === extFilter;
      });
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((d) => d.name.toLowerCase().includes(q) || d.ext.toLowerCase().includes(q));
    }
    return [...list].sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'size') return b.size_bytes - a.size_bytes;
      return b.updated_at.localeCompare(a.updated_at);
    });
  }, [documents, trashDocs, tab, activeFolderId, extFilter, search, sortBy]);

  const visibleFolders = useMemo(() => {
    let list = folders;
    if (tab === 'favorites') list = list.filter((f) => f.is_favorite === 1);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((f) => f.name.toLowerCase().includes(q));
    }
    return list;
  }, [folders, tab, search]);

  return (
    <div
      className="space-y-6"
      onDragOver={(e) => {
        e.preventDefault();
        setDraggingOver(true);
      }}
      onDragLeave={() => setDraggingOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDraggingOver(false);
        handleUploadFiles(e.dataTransfer.files);
      }}
    >
      {/* Drag & Drop Highlight Overlay */}
      {draggingOver && (
        <div className="fixed inset-0 z-40 bg-black/75 backdrop-blur-md flex items-center justify-center p-6 pointer-events-none">
          <div className="glass-panel border-2 border-dashed border-[#FF7900] rounded-3xl p-12 text-center space-y-3">
            <UploadCloud size={44} className="text-[#FF7900] mx-auto" />
            <p className="text-lg font-bold">{isAr ? 'أفلت الملفات هنا للرفع الفوري' : 'Drop files here to upload'}</p>
            <p className="text-xs opacity-65">PDF, DOCX, XLSX, PPTX, TXT, JPG, PNG, MP4, ZIP</p>
          </div>
        </div>
      )}

      {/* Top Controls Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {[
            { id: 'folders', ar: 'جميع المجلدات', en: 'All Folders' },
            { id: 'recent', ar: 'الملفات الأخيرة', en: 'Recent Files' },
            { id: 'favorites', ar: 'المفضلة', en: 'Favorites' },
            { id: 'trash', ar: `المحذوفات (${trashDocs.length})`, en: `Trash (${trashDocs.length})` },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setTab(item.id as typeof tab);
                if (item.id !== 'folders') setActiveFolderId(null);
              }}
              className={`min-h-[42px] px-4 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 cursor-pointer transition ${
                tab === item.id ? 'bg-[#FF7900] text-white shadow-lg shadow-[#FF7900]/20' : 'bg-white/6 hover:bg-white/12 text-white/75'
              }`}
            >
              {isAr ? item.ar : item.en}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".pdf,.docx,.xlsx,.pptx,.txt,.csv,.json,.jpg,.jpeg,.png,.webp,.mp4,.zip"
            className="hidden"
            onChange={(e) => handleUploadFiles(e.target.files)}
          />
          <button
            onClick={openNewFolderModal}
            className="min-h-[44px] px-4 rounded-xl bg-white/8 hover:bg-white/14 border border-white/12 text-xs font-semibold inline-flex items-center gap-2 cursor-pointer transition"
          >
            <FolderPlus size={16} className="text-[#FF7900]" />
            <span>{isAr ? 'مجلد جديد' : 'New Folder'}</span>
          </button>
          <PrimaryButton onClick={() => fileInputRef.current?.click()} disabled={uploading}>
            <UploadCloud size={16} />
            <span>{uploading ? (isAr ? 'جارٍ الرفع...' : 'Uploading...') : isAr ? 'رفع ملفات' : 'Upload Files'}</span>
          </PrimaryButton>
        </div>
      </div>

      {statusMsg && (
        <div className="rounded-2xl bg-[#FF7900]/15 border border-[#FF7900]/30 px-4 py-2.5 text-xs text-white">
          {statusMsg}
        </div>
      )}

      {/* Search, Filter & Sort Toolbar */}
      <GlassCard className="p-3.5 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute top-3.5 right-3.5 opacity-50" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={isAr ? 'ابحث في المستندات والمجلدات...' : 'Search documents and folders...'}
            className="w-full min-h-[42px] rounded-xl bg-white/[0.04] border border-white/10 pr-10 pl-4 text-sm focus:outline-none focus:border-[#FF7900]"
          />
        </div>
        <div className="flex items-center gap-2 overflow-x-auto">
          {[
            { id: 'all', label: isAr ? 'الكل' : 'All' },
            { id: 'pdf', label: 'PDF' },
            { id: 'office', label: 'Word / Excel' },
            { id: 'images', label: isAr ? 'صور' : 'Images' },
            { id: 'mp4', label: 'MP4' },
            { id: 'zip', label: 'ZIP' },
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setExtFilter(f.id)}
              className={`px-3 py-2 rounded-xl text-xs font-medium whitespace-nowrap cursor-pointer ${
                extFilter === f.id ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/70 hover:text-white'
              }`}
            >
              {f.label}
            </button>
          ))}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'date' | 'name' | 'size')}
            className="min-h-[38px] rounded-xl bg-[#18181b] border border-white/12 px-3 text-xs"
          >
            <option value="date">{isAr ? 'الأحدث' : 'Newest'}</option>
            <option value="name">{isAr ? 'الاسم' : 'Name'}</option>
            <option value="size">{isAr ? 'الحجم' : 'Size'}</option>
          </select>
        </div>
      </GlassCard>

      {/* Active Folder Breadcrumb */}
      {activeFolder && (
        <div className="flex items-center justify-between gap-3">
          <button
            onClick={() => setActiveFolderId(null)}
            className="inline-flex items-center gap-2 text-sm font-semibold text-[#FF7900] hover:underline cursor-pointer"
          >
            {isAr ? <ArrowRight size={16} /> : <ArrowLeft size={16} />}
            <span>{isAr ? 'العودة لجميع المجلدات' : 'Back to all folders'}</span>
          </button>
          <span className="text-sm font-bold">
            {activeFolder.name} · {filteredDocs.length} {isAr ? 'ملف' : 'files'}
          </span>
        </div>
      )}

      {/* 3D Glass Folders Grid */}
      {!activeFolder && (tab === 'folders' || tab === 'favorites') && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold opacity-75">
              {isAr
                ? 'مرّر المؤشر على أي مجلد لإخراج الأوراق ومعاينة المستندات (أو اضغط مطولًا على الجوال)'
                : 'Hover any folder to pull out & preview papers (long-press on mobile)'}
            </h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5 gap-5 pt-2">
            {visibleFolders.map((folder) => (
              <div key={folder.id} className="relative">
                <Folder3D
                  folder={folder}
                  lang={lang}
                  onOpenFolder={(f) => setActiveFolderId(f.id)}
                  onOpenDocument={(d) => setViewerDoc(d)}
                  onCustomize={openCustomizeFolder}
                  onToggleFavorite={async (f) => {
                    await apiFetch(`/api/folders/${f.id}`, {
                      method: 'PATCH',
                      body: JSON.stringify({ is_favorite: f.is_favorite ? 0 : 1 }),
                    });
                    loadAll();
                  }}
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Files List / Split Tablet View */}
      {(activeFolder || tab === 'recent' || tab === 'favorites' || tab === 'trash' || search.trim() !== '') && (
        <div className="space-y-3">
          <h3 className="text-sm font-semibold opacity-75">
            {tab === 'trash'
              ? isAr
                ? 'الملفات المحذوفة'
                : 'Deleted Files'
              : isAr
              ? 'المستندات والملفات'
              : 'Documents & Files'}
          </h3>

          {filteredDocs.length === 0 ? (
            <GlassCard className="p-10 text-center space-y-3">
              <File size={34} className="mx-auto opacity-35" />
              <p className="text-sm opacity-70">
                {isAr
                  ? 'لا توجد ملفات هنا بعد. اسحب الملفات وأفلتها هنا أو اضغط "رفع ملفات".'
                  : 'No files here yet. Drag and drop files or click Upload Files.'}
              </p>
            </GlassCard>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3.5">
              {filteredDocs.map((doc) => (
                <GlassCard key={doc.id} className="p-4 flex flex-col justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div
                      onClick={() => setViewerDoc(doc)}
                      className="w-11 h-11 rounded-xl bg-[#FF7900]/15 border border-[#FF7900]/30 flex items-center justify-center text-[#FF7900] font-mono text-xs font-bold shrink-0 cursor-pointer"
                    >
                      {doc.ext.toUpperCase()}
                    </div>
                    <div className="min-w-0 flex-1">
                      <h4
                        onClick={() => setViewerDoc(doc)}
                        className="text-sm font-bold truncate cursor-pointer hover:text-[#FF7900]"
                      >
                        {doc.name}
                      </h4>
                      <p className="text-xs opacity-60 font-mono-num mt-0.5">
                        {Math.max(1, Math.round(doc.size_bytes / 1024))} KB · {doc.updated_at.slice(0, 10)}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-white/8">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setViewerDoc(doc)}
                        title={isAr ? 'معاينة' : 'Preview'}
                        className="p-2 rounded-lg hover:bg-white/10 text-white/75 hover:text-white cursor-pointer"
                      >
                        <Eye size={15} />
                      </button>
                      {tab !== 'trash' && (
                        <>
                          <button
                            onClick={async () => {
                              await apiFetch(`/api/documents/${doc.id}`, {
                                method: 'PATCH',
                                body: JSON.stringify({ is_favorite: doc.is_favorite ? 0 : 1 }),
                              });
                              loadAll();
                            }}
                            title={isAr ? 'تفضيل' : 'Favorite'}
                            className="p-2 rounded-lg hover:bg-white/10 cursor-pointer"
                          >
                            <Heart
                              size={15}
                              fill={doc.is_favorite ? '#EF4444' : 'none'}
                              className={doc.is_favorite ? 'text-red-400' : 'text-white/70'}
                            />
                          </button>
                          <button
                            onClick={() => {
                              setTargetFolderId(doc.folder_id || '');
                              setMoveDoc({ doc, mode: 'move' });
                            }}
                            title={isAr ? 'نقل' : 'Move'}
                            className="p-2 rounded-lg hover:bg-white/10 text-white/70 cursor-pointer"
                          >
                            <MoveRight size={15} />
                          </button>
                          <button
                            onClick={() => {
                              setTargetFolderId(doc.folder_id || '');
                              setMoveDoc({ doc, mode: 'copy' });
                            }}
                            title={isAr ? 'نسخ' : 'Copy'}
                            className="p-2 rounded-lg hover:bg-white/10 text-white/70 cursor-pointer"
                          >
                            <Copy size={15} />
                          </button>
                          <button
                            onClick={async () => {
                              const r = await apiFetch<{ shareToken: string }>(`/api/documents/${doc.id}/share`, { method: 'POST' });
                              await navigator.clipboard.writeText(`${window.location.origin}/api/shared/${r.shareToken}`);
                              setStatusMsg(isAr ? 'تم نسخ رابط المشاركة الآمن' : 'Secure share link copied');
                            }}
                            title={isAr ? 'مشاركة' : 'Share'}
                            className="p-2 rounded-lg hover:bg-white/10 text-white/70 cursor-pointer"
                          >
                            <Share2 size={15} />
                          </button>
                        </>
                      )}
                      <button
                        onClick={() => setInfoDoc(doc)}
                        title={isAr ? 'معلومات الملف' : 'File Info'}
                        className="p-2 rounded-lg hover:bg-white/10 text-white/70 cursor-pointer"
                      >
                        <Info size={15} />
                      </button>
                    </div>

                    {tab === 'trash' ? (
                      <div className="flex items-center gap-1">
                        <button
                          onClick={async () => {
                            await apiFetch(`/api/documents/${doc.id}/restore`, { method: 'POST' });
                            loadAll();
                          }}
                          className="px-2.5 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 text-xs inline-flex items-center gap-1 cursor-pointer"
                        >
                          <RotateCcw size={13} />
                          <span>{isAr ? 'استعادة' : 'Restore'}</span>
                        </button>
                        <button
                          onClick={async () => {
                            await apiFetch(`/api/documents/${doc.id}?permanent=1`, { method: 'DELETE' });
                            loadAll();
                          }}
                          className="p-2 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={async () => {
                          await apiFetch(`/api/documents/${doc.id}`, { method: 'DELETE' });
                          loadAll();
                        }}
                        className="p-2 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                        title={isAr ? 'حذف' : 'Delete'}
                      >
                        <Trash2 size={15} />
                      </button>
                    )}
                  </div>
                </GlassCard>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Folder Create / Customize Modal */}
      <GlassModal
        open={folderModalOpen}
        onClose={() => setFolderModalOpen(false)}
        title={editingFolder ? (isAr ? 'تخصيص المجلد الزجاجي' : 'Customize 3D Folder') : isAr ? 'إنشاء مجلد جديد' : 'Create New Folder'}
      >
        <form onSubmit={handleSaveFolder} className="space-y-4">
          <InputField
            label={isAr ? 'اسم المجلد' : 'Folder Name'}
            value={fName}
            onChange={(e) => setFName(e.target.value)}
            required
          />

          <div className="space-y-2">
            <span className="block text-xs font-medium opacity-75">{isAr ? 'الألوان القياسية + عجلة الألوان + HEX' : 'Colors + Wheel + HEX'}</span>
            <div className="flex flex-wrap items-center gap-2">
              {FOLDER_COLORS.map((c) => (
                <button
                  key={c.hex}
                  type="button"
                  onClick={() => setFColor(c.hex)}
                  title={c.label}
                  className={`w-7 h-7 rounded-full border cursor-pointer transition ${
                    fColor.toLowerCase() === c.hex.toLowerCase() ? 'ring-2 ring-[#FF7900] scale-110' : 'border-white/25'
                  }`}
                  style={{ backgroundColor: c.hex }}
                />
              ))}
              <input
                type="color"
                value={fColor}
                onChange={(e) => setFColor(e.target.value)}
                className="w-8 h-8 rounded-lg bg-transparent cursor-pointer"
              />
              <input
                type="text"
                value={fColor}
                onChange={(e) => setFColor(e.target.value)}
                className="w-24 min-h-[36px] rounded-xl bg-white/8 border border-white/12 px-2.5 text-xs font-mono"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="opacity-75">{isAr ? 'شفافية الزجاج' : 'Glass Opacity'}</span>
              <span className="font-mono-num">{fOpacity}%</span>
            </div>
            <input
              type="range"
              min={25}
              max={100}
              value={fOpacity}
              onChange={(e) => setFOpacity(Number(e.target.value))}
              className="w-full accent-[#FF7900]"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setFStyle('glass')}
              className={`min-h-[44px] rounded-xl border text-xs font-semibold cursor-pointer ${
                fStyle === 'glass' ? 'bg-[#FF7900]/20 border-[#FF7900] text-white' : 'bg-white/5 border-white/10 text-white/70'
              }`}
            >
              {isAr ? 'النمط الزجاجي' : 'Glass Style'}
            </button>
            <button
              type="button"
              onClick={() => setFStyle('classic')}
              className={`min-h-[44px] rounded-xl border text-xs font-semibold cursor-pointer ${
                fStyle === 'classic' ? 'bg-[#FF7900]/20 border-[#FF7900] text-white' : 'bg-white/5 border-white/10 text-white/70'
              }`}
            >
              {isAr ? 'النمط الكلاسيكي' : 'Classic Style'}
            </button>
          </div>

          <div className="flex items-center justify-between rounded-2xl bg-white/5 border border-white/10 p-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                <DynamicIcon name={fIcon} size={20} color={fColor} />
              </div>
              <span className="text-xs font-mono">{fIcon}</span>
            </div>
            <button
              type="button"
              onClick={() => setIconPickerOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold cursor-pointer"
            >
              {isAr ? 'اختيار من 500+ أيقونة' : 'Pick from 500+ Icons'}
            </button>
          </div>

          {editingFolder && (
            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-white/10">
              <button
                type="button"
                onClick={() => handleReorderFolder(editingFolder.id, -1)}
                className="px-3 py-2 rounded-xl bg-white/8 text-xs inline-flex items-center gap-1 cursor-pointer"
              >
                <ArrowUp size={13} />
                <span>{isAr ? 'تقديم' : 'Move Up'}</span>
              </button>
              <button
                type="button"
                onClick={() => handleReorderFolder(editingFolder.id, 1)}
                className="px-3 py-2 rounded-xl bg-white/8 text-xs inline-flex items-center gap-1 cursor-pointer"
              >
                <ArrowDown size={13} />
                <span>{isAr ? 'تأخير' : 'Move Down'}</span>
              </button>
              <button
                type="button"
                onClick={handleDuplicateFolder}
                className="px-3 py-2 rounded-xl bg-white/8 text-xs inline-flex items-center gap-1 cursor-pointer"
              >
                <Copy size={13} />
                <span>{isAr ? 'تكرار' : 'Duplicate'}</span>
              </button>
              <button
                type="button"
                onClick={handleDeleteFolder}
                className="px-3 py-2 rounded-xl bg-red-500/20 text-red-300 text-xs inline-flex items-center gap-1 cursor-pointer"
              >
                <Trash2 size={13} />
                <span>{isAr ? 'حذف المجلد' : 'Delete'}</span>
              </button>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={() => setFolderModalOpen(false)}
              className="min-h-[44px] px-4 rounded-xl bg-white/8 text-sm cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <PrimaryButton type="submit">{isAr ? 'حفظ التغييرات' : 'Save Folder'}</PrimaryButton>
          </div>
        </form>
      </GlassModal>

      {/* Move / Copy Document Modal */}
      <GlassModal
        open={Boolean(moveDoc)}
        onClose={() => setMoveDoc(null)}
        title={moveDoc?.mode === 'move' ? (isAr ? 'نقل الملف إلى مجلد' : 'Move File') : isAr ? 'نسخ الملف إلى مجلد' : 'Copy File'}
      >
        <div className="space-y-4">
          <SelectField
            label={isAr ? 'اختر المجلد الوجهة' : 'Destination Folder'}
            value={targetFolderId}
            onChange={(e) => setTargetFolderId(e.target.value)}
          >
            <option value="">{isAr ? 'بدون مجلد (جذر المستندات)' : 'No Folder (Root)'}</option>
            {folders.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name}
              </option>
            ))}
          </SelectField>
          <div className="flex justify-end gap-2">
            <button onClick={() => setMoveDoc(null)} className="px-4 py-2 rounded-xl bg-white/8 text-sm cursor-pointer">
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <PrimaryButton onClick={handleMoveOrCopy}>
              {moveDoc?.mode === 'move' ? (isAr ? 'نقل الآن' : 'Move') : isAr ? 'نسخ الآن' : 'Copy'}
            </PrimaryButton>
          </div>
        </div>
      </GlassModal>

      {/* File Info Modal */}
      <GlassModal
        open={Boolean(infoDoc)}
        onClose={() => setInfoDoc(null)}
        title={isAr ? 'معلومات المستند' : 'Document Metadata'}
      >
        {infoDoc && (
          <div className="space-y-3 text-sm">
            <div className="flex justify-between py-2 border-b border-white/10">
              <span className="opacity-65">{isAr ? 'الاسم الأصلي' : 'Original Name'}</span>
              <span className="font-semibold">{infoDoc.original_name}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-white/10">
              <span className="opacity-65">{isAr ? 'النوع' : 'Type'}</span>
              <span className="font-mono">{infoDoc.ext.toUpperCase()} ({infoDoc.mime_type})</span>
            </div>
            <div className="flex justify-between py-2 border-b border-white/10">
              <span className="opacity-65">{isAr ? 'الحجم' : 'Size'}</span>
              <span className="font-mono-num">{(infoDoc.size_bytes / 1024).toFixed(2)} KB</span>
            </div>
            <div className="flex justify-between py-2 border-b border-white/10">
              <span className="opacity-65">{isAr ? 'تاريخ الإنشاء' : 'Created'}</span>
              <span className="font-mono-num">{infoDoc.created_at.slice(0, 19).replace('T', ' ')}</span>
            </div>
            <div className="flex justify-between py-2">
              <span className="opacity-65">{isAr ? 'آخر تعديل' : 'Last Modified'}</span>
              <span className="font-mono-num">{infoDoc.updated_at.slice(0, 19).replace('T', ' ')}</span>
            </div>
          </div>
        )}
      </GlassModal>

      <IconPickerModal
        open={iconPickerOpen}
        onClose={() => setIconPickerOpen(false)}
        lang={lang}
        initialIcon={fIcon}
        initialColor={fColor}
        onSelect={(res) => {
          setFIcon(res.icon);
          setFColor(res.color);
        }}
      />

      <DocumentViewerModal doc={viewerDoc} onClose={() => setViewerDoc(null)} lang={lang} />
    </div>
  );
};
