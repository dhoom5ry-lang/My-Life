import React, { useState } from 'react';
import { CheckCircle2, Circle, Minus, Plus, Trash2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { CardStyle, CustomWidget, Language } from '../types';
import { DynamicIcon } from '../components/DynamicIcon';
import { IconPickerModal } from '../components/IconPickerModal';
import { GlassCard, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

export const WidgetBuilderModule: React.FC<{
  lang: Language;
  editingWidget?: CustomWidget | null;
  onSaved: () => void;
}> = ({ lang, editingWidget, onSaved }) => {
  const isAr = lang === 'ar';
  const [name, setName] = useState(editingWidget?.name || '');
  const [iconName, setIconName] = useState(editingWidget?.icon_name || 'Sparkles');
  const [iconColor, setIconColor] = useState(editingWidget?.icon_color || '#FF7900');
  const [bgColor, setBgColor] = useState(editingWidget?.bg_color || '#151515');
  const [style, setStyle] = useState<CardStyle>(editingWidget?.style || 'glass');
  const [opacity, setOpacity] = useState(editingWidget?.opacity ?? 82);
  const [widgetType, setWidgetType] = useState<CustomWidget['widget_type']>(editingWidget?.widget_type || 'checklist');
  const [pickerOpen, setPickerOpen] = useState(false);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const payload = {
      name: name.trim(),
      icon_name: iconName,
      icon_color: iconColor,
      bg_color: bgColor,
      style,
      opacity,
      widget_type: widgetType,
    };
    if (editingWidget) {
      await apiFetch(`/api/widgets/${editingWidget.id}`, {
        method: 'PATCH',
        body: JSON.stringify(payload),
      });
    } else {
      await apiFetch('/api/widgets', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    }
    onSaved();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      <GlassCard className="p-6 lg:col-span-7 space-y-4">
        <h3 className="text-lg font-bold">{editingWidget ? (isAr ? 'تعديل الأداة المخصصة' : 'Edit Custom Widget') : isAr ? 'إضافة أداة مخصصة' : 'Create Custom Widget'}</h3>
        <form onSubmit={handleSave} className="space-y-4">
          <InputField
            label={isAr ? 'اسم الأداة' : 'Widget Name'}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder={isAr ? 'مثال: فواتيري، عداد القراءة، قائمة سريعة...' : 'e.g. Reading Counter, Quick Bills...'}
            required
          />

          <SelectField
            label={isAr ? 'وظيفة الأداة الفعلية' : 'Functional Widget Type'}
            value={widgetType}
            onChange={(e) => setWidgetType(e.target.value as CustomWidget['widget_type'])}
          >
            <option value="checklist">{isAr ? 'قائمة تحقق تفاعلية (Checklist)' : 'Interactive Checklist'}</option>
            <option value="counter">{isAr ? 'عداد تتبع رقمي (Counter / Habit)' : 'Numeric Counter / Habit Tracker'}</option>
            <option value="notes">{isAr ? 'مفكرة سريعة (Quick Notes)' : 'Quick Notes Pad'}</option>
            <option value="quick_expense">{isAr ? 'مسجّل مصروف سريع' : 'Quick Expense Logger'}</option>
            <option value="tracker">{isAr ? 'متتبع هدف (%)' : 'Goal Progress Tracker'}</option>
          </SelectField>

          <div className="flex items-center justify-between rounded-2xl bg-white/[0.04] border border-white/10 p-3.5">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-white/10 flex items-center justify-center">
                <DynamicIcon name={iconName} size={22} color={iconColor} />
              </div>
              <div>
                <p className="text-xs opacity-60">{isAr ? 'الأيقونة المختارة' : 'Selected Icon'}</p>
                <p className="text-sm font-mono font-bold">{iconName}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setPickerOpen(true)}
              className="px-4 py-2 rounded-xl bg-[#FF7900]/20 border border-[#FF7900]/40 text-[#FF7900] text-xs font-semibold cursor-pointer"
            >
              {isAr ? 'مكتبة 500+ أيقونة' : 'Open 500+ Icon Library'}
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <span className="block text-xs font-medium opacity-75">{isAr ? 'لون الأيقونة (عجلة + HEX)' : 'Icon Color'}</span>
              <div className="flex items-center gap-2">
                <input type="color" value={iconColor} onChange={(e) => setIconColor(e.target.value)} className="w-10 h-10 rounded-xl bg-transparent cursor-pointer" />
                <input type="text" value={iconColor} onChange={(e) => setIconColor(e.target.value)} className="flex-1 min-h-[40px] rounded-xl bg-white/6 border border-white/12 px-3 text-xs font-mono" />
              </div>
            </div>
            <div className="space-y-1.5">
              <span className="block text-xs font-medium opacity-75">{isAr ? 'لون خلفية الأداة' : 'Widget Background'}</span>
              <div className="flex items-center gap-2">
                <input type="color" value={bgColor} onChange={(e) => setBgColor(e.target.value)} className="w-10 h-10 rounded-xl bg-transparent cursor-pointer" />
                <input type="text" value={bgColor} onChange={(e) => setBgColor(e.target.value)} className="flex-1 min-h-[40px] rounded-xl bg-white/6 border border-white/12 px-3 text-xs font-mono" />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setStyle('glass')}
              className={`min-h-[44px] rounded-xl border text-xs font-semibold cursor-pointer ${
                style === 'glass' ? 'bg-[#FF7900]/20 border-[#FF7900] text-white' : 'bg-white/5 border-white/10 text-white/70'
              }`}
            >
              {isAr ? 'زجاجي (Glass)' : 'Glass Style'}
            </button>
            <button
              type="button"
              onClick={() => setStyle('classic')}
              className={`min-h-[44px] rounded-xl border text-xs font-semibold cursor-pointer ${
                style === 'classic' ? 'bg-[#FF7900]/20 border-[#FF7900] text-white' : 'bg-white/5 border-white/10 text-white/70'
              }`}
            >
              {isAr ? 'كلاسيكي (Classic)' : 'Classic Style'}
            </button>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-xs">
              <span className="opacity-75">{isAr ? 'الشفافية' : 'Opacity'}</span>
              <span className="font-mono-num">{opacity}%</span>
            </div>
            <input type="range" min={25} max={100} value={opacity} onChange={(e) => setOpacity(Number(e.target.value))} className="w-full accent-[#FF7900]" />
          </div>

          <PrimaryButton type="submit" className="w-full">
            {editingWidget ? (isAr ? 'حفظ تعديلات الأداة' : 'Update Widget') : isAr ? 'إضافة الأداة' : 'Add Widget'}
          </PrimaryButton>
        </form>
      </GlassCard>

      {/* Live Preview */}
      <GlassCard className="p-6 lg:col-span-5 flex flex-col items-center justify-center gap-5">
        <p className="text-xs opacity-60">{isAr ? 'معاينة مباشرة للأداة على الشاشة الرئيسية' : 'Live Dashboard Tile Preview'}</p>
        <div
          className="w-40 h-40 rounded-3xl p-4 flex flex-col items-center justify-center gap-3 border border-white/15 shadow-2xl transition-all"
          style={{
            backgroundColor: bgColor,
            opacity: opacity / 100,
            backdropFilter: style === 'glass' ? 'blur(20px)' : undefined,
          }}
        >
          <div className="w-14 h-14 rounded-2xl bg-white/10 flex items-center justify-center">
            <DynamicIcon name={iconName} size={28} color={iconColor} />
          </div>
          <span className="text-sm font-bold text-center truncate w-full">{name || (isAr ? 'اسم الأداة' : 'Widget Name')}</span>
        </div>
      </GlassCard>

      <IconPickerModal
        open={pickerOpen}
        onClose={() => setPickerOpen(false)}
        lang={lang}
        initialIcon={iconName}
        initialColor={iconColor}
        onSelect={(res) => {
          setIconName(res.icon);
          setIconColor(res.color);
        }}
      />
    </div>
  );
};

export const CustomWidgetRunner: React.FC<{
  widget: CustomWidget;
  lang: Language;
  onUpdate: () => void;
  onEdit: () => void;
  onDelete: () => void;
}> = ({ widget, lang, onUpdate, onEdit, onDelete }) => {
  const isAr = lang === 'ar';
  const parsed = JSON.parse(widget.data_json || '{}');
  const [count, setCount] = useState<number>(parsed.count ?? 0);
  const [note, setNote] = useState<string>(parsed.note ?? '');
  const [items, setItems] = useState<{ id: string; text: string; done: boolean }[]>(parsed.items || []);
  const [newItem, setNewItem] = useState('');
  const [expTitle, setExpTitle] = useState('');
  const [expAmount, setExpAmount] = useState('');

  const persist = async (nextData: Record<string, unknown>) => {
    await apiFetch(`/api/widgets/${widget.id}`, {
      method: 'PATCH',
      body: JSON.stringify({ data: nextData }),
    });
    onUpdate();
  };

  return (
    <div className="space-y-5">
      <GlassCard className="p-5 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center">
            <DynamicIcon name={widget.icon_name} size={24} color={widget.icon_color} />
          </div>
          <div>
            <h3 className="text-lg font-bold">{widget.name}</h3>
            <p className="text-xs opacity-60">{widget.widget_type}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onEdit} className="px-3.5 py-2 rounded-xl bg-white/8 text-xs font-semibold cursor-pointer">
            {isAr ? 'تخصيص' : 'Customize'}
          </button>
          <button onClick={onDelete} className="p-2 rounded-xl bg-red-500/20 text-red-300 cursor-pointer">
            <Trash2 size={16} />
          </button>
        </div>
      </GlassCard>

      {widget.widget_type === 'counter' || widget.widget_type === 'tracker' ? (
        <GlassCard className="p-8 text-center space-y-5">
          <p className="text-5xl font-bold font-mono-num text-[#FF7900]">{count}</p>
          <div className="flex items-center justify-center gap-4">
            <button
              onClick={() => {
                const n = Math.max(0, count - 1);
                setCount(n);
                persist({ ...parsed, count: n });
              }}
              className="w-14 h-14 rounded-2xl bg-white/10 hover:bg-white/15 flex items-center justify-center cursor-pointer"
            >
              <Minus size={22} />
            </button>
            <button
              onClick={() => {
                const n = count + 1;
                setCount(n);
                persist({ ...parsed, count: n });
              }}
              className="w-14 h-14 rounded-2xl bg-[#FF7900] text-white flex items-center justify-center cursor-pointer"
            >
              <Plus size={22} />
            </button>
          </div>
        </GlassCard>
      ) : widget.widget_type === 'notes' ? (
        <GlassCard className="p-5 space-y-3">
          <textarea
            rows={8}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder={isAr ? 'اكتب ملاحظاتك هنا...' : 'Write your notes...'}
            className="w-full rounded-2xl bg-white/[0.04] border border-white/12 p-4 text-sm focus:outline-none focus:border-[#FF7900]"
          />
          <PrimaryButton onClick={() => persist({ ...parsed, note })}>{isAr ? 'حفظ الملاحظة' : 'Save Note'}</PrimaryButton>
        </GlassCard>
      ) : widget.widget_type === 'quick_expense' ? (
        <GlassCard className="p-5 space-y-3 max-w-md">
          <InputField label={isAr ? 'وصف المصروف' : 'Expense Title'} value={expTitle} onChange={(e) => setExpTitle(e.target.value)} />
          <InputField label={isAr ? 'المبلغ' : 'Amount'} type="number" value={expAmount} onChange={(e) => setExpAmount(e.target.value)} />
          <PrimaryButton
            onClick={async () => {
              if (!expTitle || !expAmount) return;
              await apiFetch('/api/transactions', {
                method: 'POST',
                body: JSON.stringify({
                  type: 'expense',
                  title: expTitle,
                  amount: Number(expAmount),
                  category: 'other',
                  date: new Date().toISOString().slice(0, 10),
                }),
              });
              setExpTitle('');
              setExpAmount('');
              onUpdate();
            }}
          >
            {isAr ? 'تسجيل المصروف فورًا' : 'Log Expense'}
          </PrimaryButton>
        </GlassCard>
      ) : (
        <GlassCard className="p-5 space-y-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!newItem.trim()) return;
              const next = [...items, { id: String(Date.now()), text: newItem.trim(), done: false }];
              setItems(next);
              setNewItem('');
              persist({ ...parsed, items: next });
            }}
            className="flex gap-2"
          >
            <input
              value={newItem}
              onChange={(e) => setNewItem(e.target.value)}
              placeholder={isAr ? 'أضف عنصرًا جديدًا...' : 'Add checklist item...'}
              className="flex-1 min-h-[44px] rounded-xl bg-white/6 border border-white/12 px-4 text-sm"
            />
            <PrimaryButton type="submit">{isAr ? 'إضافة' : 'Add'}</PrimaryButton>
          </form>
          <div className="space-y-2">
            {items.map((it) => (
              <div key={it.id} className="flex items-center justify-between rounded-xl bg-white/[0.04] px-3.5 py-2.5">
                <button
                  onClick={() => {
                    const next = items.map((x) => (x.id === it.id ? { ...x, done: !x.done } : x));
                    setItems(next);
                    persist({ ...parsed, items: next });
                  }}
                  className="flex items-center gap-2.5 text-sm cursor-pointer"
                >
                  {it.done ? <CheckCircle2 size={18} className="text-emerald-400" /> : <Circle size={18} className="opacity-45" />}
                  <span className={it.done ? 'line-through opacity-50' : ''}>{it.text}</span>
                </button>
                <button
                  onClick={() => {
                    const next = items.filter((x) => x.id !== it.id);
                    setItems(next);
                    persist({ ...parsed, items: next });
                  }}
                  className="text-red-400 p-1 cursor-pointer"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
          </div>
        </GlassCard>
      )}
    </div>
  );
};
