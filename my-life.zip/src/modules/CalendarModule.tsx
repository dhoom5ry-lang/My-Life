import React, { useEffect, useMemo, useState } from 'react';
import { Calendar as CalIcon, ChevronLeft, ChevronRight, MapPin, Plus, Trash2, Users } from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { CalendarEventItem, Language } from '../types';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

export const CalendarModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [events, setEvents] = useState<CalendarEventItem[]>([]);
  const [view, setView] = useState<'day' | 'week' | 'month'>('month');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().slice(0, 10));
  const [modalOpen, setModalOpen] = useState(false);

  const [form, setForm] = useState({
    title: '',
    date: new Date().toISOString().slice(0, 10),
    start_time: '10:00',
    end_time: '11:00',
    location: '',
    priority: 'medium' as 'low' | 'medium' | 'high',
    recurrence: 'none' as 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly',
    description: '',
    shared_with_family: false,
    reminder_minutes: '30',
  });

  const load = async () => {
    const res = await apiFetch<{ events: CalendarEventItem[] }>('/api/events');
    setEvents(res.events || []);
  };

  useEffect(() => {
    load();
  }, []);

  const currentMonthDate = new Date(`${selectedDate}T00:00:00`);
  const year = currentMonthDate.getFullYear();
  const month = currentMonthDate.getMonth();

  const monthDays = useMemo(() => {
    const first = new Date(year, month, 1);
    const startPad = first.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: (string | null)[] = Array(startPad).fill(null);
    for (let d = 1; d <= daysInMonth; d++) {
      const iso = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      cells.push(iso);
    }
    return cells;
  }, [year, month]);

  const weekDays = useMemo(() => {
    const base = new Date(`${selectedDate}T00:00:00`);
    const day = base.getDay();
    const start = new Date(base);
    start.setDate(base.getDate() - day);
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      return d.toISOString().slice(0, 10);
    });
  }, [selectedDate]);

  const visibleEvents = useMemo(() => {
    if (view === 'day') return events.filter((e) => e.date === selectedDate);
    if (view === 'week') return events.filter((e) => weekDays.includes(e.date));
    return events.filter((e) => e.date === selectedDate);
  }, [events, view, selectedDate, weekDays]);

  const shiftMonth = (delta: number) => {
    const d = new Date(year, month + delta, 1);
    setSelectedDate(`${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-01`);
  };

  const monthLabel = currentMonthDate.toLocaleDateString(isAr ? 'ar-SA' : 'en-US', {
    month: 'long',
    year: 'numeric',
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-white/6 p-1 rounded-xl border border-white/10">
          {(['day', 'week', 'month'] as const).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={`px-4 py-2 rounded-lg text-xs font-semibold cursor-pointer transition ${
                view === v ? 'bg-[#FF7900] text-white' : 'text-white/70 hover:text-white'
              }`}
            >
              {v === 'day' ? (isAr ? 'اليوم' : 'Day') : v === 'week' ? (isAr ? 'الأسبوع' : 'Week') : isAr ? 'الشهر' : 'Month'}
            </button>
          ))}
        </div>

        <PrimaryButton
          onClick={() => {
            setForm((f) => ({ ...f, date: selectedDate }));
            setModalOpen(true);
          }}
        >
          <Plus size={16} />
          <span>{isAr ? 'إضافة موعد' : 'Add Event'}</span>
        </PrimaryButton>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Calendar Surface */}
        <GlassCard className="p-5 lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between">
            <button onClick={() => shiftMonth(-1)} className="p-2 rounded-xl bg-white/8 hover:bg-white/14 cursor-pointer">
              {isAr ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
            </button>
            <h3 className="text-base font-bold">{monthLabel}</h3>
            <button onClick={() => shiftMonth(1)} className="p-2 rounded-xl bg-white/8 hover:bg-white/14 cursor-pointer">
              {isAr ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
            </button>
          </div>

          {view === 'week' ? (
            <div className="grid grid-cols-7 gap-2">
              {weekDays.map((iso) => {
                const count = events.filter((e) => e.date === iso).length;
                const active = iso === selectedDate;
                return (
                  <button
                    key={iso}
                    onClick={() => setSelectedDate(iso)}
                    className={`p-3 rounded-2xl border text-center cursor-pointer transition ${
                      active ? 'bg-[#FF7900] border-[#FF7900] text-white' : 'bg-white/5 border-white/10 hover:bg-white/10'
                    }`}
                  >
                    <p className="text-[11px] opacity-75">{new Date(`${iso}T00:00:00`).toLocaleDateString(isAr ? 'ar-SA' : 'en-US', { weekday: 'short' })}</p>
                    <p className="text-base font-bold font-mono-num mt-1">{iso.slice(8)}</p>
                    {count > 0 && <p className="text-[10px] mt-1 font-mono-num">{count} •</p>}
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="grid grid-cols-7 gap-1.5 text-center">
              {(isAr ? ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'] : ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']).map((d) => (
                <div key={d} className="text-[11px] opacity-55 py-1">
                  {d}
                </div>
              ))}
              {monthDays.map((iso, i) => {
                if (!iso) return <div key={`empty-${i}`} />;
                const active = iso === selectedDate;
                const dayEvents = events.filter((e) => e.date === iso);
                return (
                  <button
                    key={iso}
                    onClick={() => setSelectedDate(iso)}
                    className={`min-h-[46px] rounded-xl border flex flex-col items-center justify-center cursor-pointer transition ${
                      active
                        ? 'bg-[#FF7900] border-[#FF7900] text-white font-bold shadow-lg shadow-[#FF7900]/25'
                        : 'bg-white/[0.03] border-white/8 hover:bg-white/10'
                    }`}
                  >
                    <span className="text-xs font-mono-num">{Number(iso.slice(8))}</span>
                    {dayEvents.length > 0 && (
                      <span className={`text-[9px] font-mono-num ${active ? 'text-white' : 'text-[#FF7900]'}`}>
                        {dayEvents.length}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </GlassCard>

        {/* Agenda for Selected Day / Week */}
        <GlassCard className="p-5 lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold flex items-center gap-2">
              <CalIcon size={16} className="text-[#FF7900]" />
              <span>{view === 'week' ? (isAr ? 'مواعيد الأسبوع' : 'Week Agenda') : selectedDate}</span>
            </h4>
            <span className="text-xs font-mono-num opacity-65">
              {visibleEvents.length} {isAr ? 'موعد' : 'events'}
            </span>
          </div>

          {visibleEvents.length === 0 ? (
            <div className="py-12 text-center text-sm opacity-60">
              {isAr ? 'لا توجد مواعيد في هذا التاريخ.' : 'No appointments scheduled.'}
            </div>
          ) : (
            <div className="space-y-3 max-h-[380px] overflow-y-auto">
              {visibleEvents.map((ev) => (
                <div key={ev.id} className="rounded-2xl bg-white/[0.04] border border-white/10 p-3.5 space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h5 className="font-bold text-sm">{ev.title}</h5>
                      <p className="text-xs text-[#FF7900] font-mono-num mt-0.5">
                        {ev.date} · {ev.start_time} - {ev.end_time}
                      </p>
                    </div>
                    <button
                      onClick={async () => {
                        await apiFetch(`/api/events/${ev.id}`, { method: 'DELETE' });
                        load();
                      }}
                      className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  {ev.location && (
                    <p className="text-xs opacity-65 flex items-center gap-1">
                      <MapPin size={12} /> {ev.location}
                    </p>
                  )}
                  <div className="flex items-center gap-3 text-[11px] opacity-60">
                    <span>{ev.priority}</span>
                    {ev.recurrence !== 'none' && <span>· {ev.recurrence}</span>}
                    {ev.shared_with_family === 1 && (
                      <span className="inline-flex items-center gap-1 text-purple-300">
                        · <Users size={11} /> {isAr ? 'مشترك مع العائلة' : 'Family Shared'}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      </div>

      <GlassModal open={modalOpen} onClose={() => setModalOpen(false)} title={isAr ? 'إضافة موعد جديد' : 'Add Appointment'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/events', {
              method: 'POST',
              body: JSON.stringify({ ...form, reminder_minutes: Number(form.reminder_minutes) }),
            });
            setModalOpen(false);
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'عنوان الموعد' : 'Title'} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <div className="grid grid-cols-3 gap-2.5">
            <InputField label={isAr ? 'التاريخ' : 'Date'} type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            <InputField label={isAr ? 'من' : 'Start'} type="time" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} />
            <InputField label={isAr ? 'إلى' : 'End'} type="time" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} />
          </div>
          <InputField label={isAr ? 'المكان' : 'Location'} value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
          <div className="grid grid-cols-2 gap-3">
            <SelectField label={isAr ? 'الأولوية' : 'Priority'} value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value as 'low' | 'medium' | 'high' })}>
              <option value="low">{isAr ? 'منخفضة' : 'Low'}</option>
              <option value="medium">{isAr ? 'متوسطة' : 'Medium'}</option>
              <option value="high">{isAr ? 'عالية' : 'High'}</option>
            </SelectField>
            <SelectField label={isAr ? 'التكرار' : 'Recurrence'} value={form.recurrence} onChange={(e) => setForm({ ...form, recurrence: e.target.value as typeof form.recurrence })}>
              <option value="none">{isAr ? 'مرة واحدة' : 'None'}</option>
              <option value="daily">{isAr ? 'يومي' : 'Daily'}</option>
              <option value="weekly">{isAr ? 'أسبوعي' : 'Weekly'}</option>
              <option value="monthly">{isAr ? 'شهري' : 'Monthly'}</option>
              <option value="yearly">{isAr ? 'سنوي' : 'Yearly'}</option>
            </SelectField>
          </div>
          <InputField label={isAr ? 'الوصف' : 'Description'} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input
              type="checkbox"
              checked={form.shared_with_family}
              onChange={(e) => setForm({ ...form, shared_with_family: e.target.checked })}
              className="accent-[#FF7900]"
            />
            <span>{isAr ? 'مشاركة الموعد مع العائلة' : 'Share appointment with Family'}</span>
          </label>
          <PrimaryButton type="submit" className="w-full">
            {isAr ? 'حفظ الموعد' : 'Save Appointment'}
          </PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};
