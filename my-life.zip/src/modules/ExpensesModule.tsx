import React, { useEffect, useMemo, useState } from 'react';
import { ArrowDownLeft, ArrowUpRight, Edit3, Plus, Trash2 } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatCurrency } from '../lib/i18n';
import type { DocumentItem, Language, TransactionItem } from '../types';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

export const EXPENSE_CATEGORIES = [
  { id: 'home', ar: 'المنزل', en: 'Home', color: '#22C55E' },
  { id: 'food', ar: 'الطعام', en: 'Food', color: '#F59E0B' },
  { id: 'transport', ar: 'النقل', en: 'Transport', color: '#3B82F6' },
  { id: 'shopping', ar: 'التسوق', en: 'Shopping', color: '#EC4899' },
  { id: 'health', ar: 'الصحة', en: 'Health', color: '#EF4444' },
  { id: 'education', ar: 'التعليم', en: 'Education', color: '#8B5CF6' },
  { id: 'entertainment', ar: 'الترفيه', en: 'Entertainment', color: '#14B8A6' },
  { id: 'telecom', ar: 'الاتصالات', en: 'Telecom', color: '#06B6D4' },
  { id: 'bills', ar: 'الفواتير', en: 'Bills', color: '#FF7900' },
  { id: 'other', ar: 'أخرى', en: 'Other', color: '#94A3B8' },
];

export const ExpensesModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [txs, setTxs] = useState<TransactionItem[]>([]);
  const [docs, setDocs] = useState<DocumentItem[]>([]);
  const [period, setPeriod] = useState<'daily' | 'monthly' | 'yearly'>('monthly');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<TransactionItem | null>(null);

  const [form, setForm] = useState({
    type: 'expense' as 'expense' | 'income',
    title: '',
    amount: '',
    category: 'food',
    date: new Date().toISOString().slice(0, 10),
    payment_method: 'card',
    invoice_doc_id: '',
    notes: '',
  });

  const load = async () => {
    const [tRes, dRes] = await Promise.all([
      apiFetch<{ transactions: TransactionItem[] }>('/api/transactions'),
      apiFetch<{ documents: DocumentItem[] }>('/api/documents'),
    ]);
    setTxs(tRes.transactions || []);
    setDocs(dRes.documents || []);
  };

  useEffect(() => {
    load();
  }, []);

  const periodFiltered = useMemo(() => {
    const now = new Date().toISOString();
    const today = now.slice(0, 10);
    const month = now.slice(0, 7);
    const year = now.slice(0, 4);
    return txs.filter((t) => {
      if (period === 'daily') return t.date === today;
      if (period === 'monthly') return t.date.startsWith(month);
      return t.date.startsWith(year);
    });
  }, [txs, period]);

  const summary = useMemo(() => {
    let income = 0;
    let expense = 0;
    const catTotals: Record<string, number> = {};
    for (const t of periodFiltered) {
      if (t.type === 'income') income += t.amount;
      else {
        expense += t.amount;
        catTotals[t.category] = (catTotals[t.category] || 0) + t.amount;
      }
    }
    const breakdown = EXPENSE_CATEGORIES.map((c) => ({
      ...c,
      total: catTotals[c.id] || 0,
      pct: expense > 0 ? Math.round(((catTotals[c.id] || 0) / expense) * 100) : 0,
    }))
      .filter((c) => c.total > 0)
      .sort((a, b) => b.total - a.total);

    return { income, expense, net: income - expense, breakdown };
  }, [periodFiltered]);

  const openModal = (type: 'expense' | 'income', tx?: TransactionItem) => {
    if (tx) {
      setEditing(tx);
      setForm({
        type: tx.type,
        title: tx.title,
        amount: String(tx.amount),
        category: tx.category,
        date: tx.date,
        payment_method: tx.payment_method,
        invoice_doc_id: tx.invoice_doc_id || '',
        notes: tx.notes || '',
      });
    } else {
      setEditing(null);
      setForm({
        type,
        title: '',
        amount: '',
        category: type === 'income' ? 'other' : 'food',
        date: new Date().toISOString().slice(0, 10),
        payment_method: 'card',
        invoice_doc_id: '',
        notes: '',
      });
    }
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      ...form,
      amount: Number(form.amount || 0),
      invoice_doc_id: form.invoice_doc_id || null,
    };
    if (editing) {
      await apiFetch(`/api/transactions/${editing.id}`, {
        method: 'PATCH',
        body: JSON.stringify(payload),
      });
    } else {
      await apiFetch('/api/transactions', {
        method: 'POST',
        body: JSON.stringify(payload),
      });
    }
    setModalOpen(false);
    load();
  };

  // Interactive SVG Donut Chart segments
  const radius = 56;
  const circumference = 2 * Math.PI * radius;
  let cumulative = 0;

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-white/6 p-1 rounded-xl border border-white/10">
          {(['daily', 'monthly', 'yearly'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3.5 py-2 rounded-lg text-xs font-semibold cursor-pointer transition ${
                period === p ? 'bg-[#FF7900] text-white' : 'text-white/70 hover:text-white'
              }`}
            >
              {p === 'daily' ? (isAr ? 'يومي' : 'Daily') : p === 'monthly' ? (isAr ? 'شهري' : 'Monthly') : isAr ? 'سنوي' : 'Yearly'}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => openModal('income')}
            className="min-h-[44px] px-4 rounded-xl bg-emerald-500/20 border border-emerald-500/35 text-emerald-300 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer hover:bg-emerald-500/30 transition"
          >
            <ArrowDownLeft size={16} />
            <span>{isAr ? 'إضافة دخل' : 'Add Income'}</span>
          </button>
          <PrimaryButton onClick={() => openModal('expense')}>
            <Plus size={16} />
            <span>{isAr ? 'إضافة مصروف' : 'Add Expense'}</span>
          </PrimaryButton>
        </div>
      </div>

      {/* Totals */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <GlassCard className="p-5">
          <p className="text-xs opacity-60">{isAr ? 'إجمالي الدخل' : 'Total Income'}</p>
          <p className="text-2xl font-bold font-mono-num text-emerald-400 mt-1">{formatCurrency(summary.income, lang)}</p>
        </GlassCard>
        <GlassCard className="p-5">
          <p className="text-xs opacity-60">{isAr ? 'إجمالي المصروفات' : 'Total Expenses'}</p>
          <p className="text-2xl font-bold font-mono-num text-[#FF7900] mt-1">{formatCurrency(summary.expense, lang)}</p>
        </GlassCard>
        <GlassCard className="p-5">
          <p className="text-xs opacity-60">{isAr ? 'صافي الرصيد' : 'Net Balance'}</p>
          <p className={`text-2xl font-bold font-mono-num mt-1 ${summary.net >= 0 ? 'text-white' : 'text-red-400'}`}>
            {formatCurrency(summary.net, lang)}
          </p>
        </GlassCard>
      </div>

      {/* Interactive Donut Chart + Category Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <GlassCard className="p-6 lg:col-span-5 flex flex-col items-center justify-center gap-4">
          <h4 className="text-sm font-semibold self-start">{isAr ? 'توزيع المصروفات' : 'Expense Breakdown'}</h4>
          <div className="relative w-44 h-44 flex items-center justify-center">
            <svg viewBox="0 0 140 140" className="w-full h-full -rotate-90">
              <circle cx="70" cy="70" r={radius} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="16" />
              {summary.breakdown.map((seg) => {
                const dash = (seg.pct / 100) * circumference;
                const offset = -cumulative;
                cumulative += dash;
                return (
                  <circle
                    key={seg.id}
                    cx="70"
                    cy="70"
                    r={radius}
                    fill="none"
                    stroke={seg.color}
                    strokeWidth="16"
                    strokeDasharray={`${dash} ${circumference}`}
                    strokeDashoffset={offset}
                    strokeLinecap="round"
                  />
                );
              })}
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="text-base font-bold font-mono-num">{summary.expense.toLocaleString()}</span>
              <span className="text-[11px] opacity-60">{isAr ? 'ر.س' : 'SAR'}</span>
            </div>
          </div>
          <div className="w-full space-y-2">
            {summary.breakdown.map((b) => (
              <div key={b.id} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: b.color }} />
                  <span>{isAr ? b.ar : b.en}</span>
                </div>
                <span className="font-mono-num opacity-80">
                  {b.pct}% · {formatCurrency(b.total, lang)}
                </span>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Transactions Ledger */}
        <GlassCard className="p-5 lg:col-span-7 space-y-3">
          <h4 className="text-sm font-semibold">{isAr ? 'سجل المعاملات' : 'Transactions Ledger'}</h4>
          {periodFiltered.length === 0 ? (
            <div className="py-12 text-center text-sm opacity-60">{isAr ? 'لا توجد معاملات في هذه الفترة.' : 'No transactions in this period.'}</div>
          ) : (
            <div className="divide-y divide-white/8 max-h-[420px] overflow-y-auto">
              {periodFiltered.map((t) => {
                const cat = EXPENSE_CATEGORIES.find((c) => c.id === t.category);
                return (
                  <div key={t.id} className="py-3 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          t.type === 'income' ? 'bg-emerald-500/15 text-emerald-400' : 'bg-[#FF7900]/15 text-[#FF7900]'
                        }`}
                      >
                        {t.type === 'income' ? <ArrowDownLeft size={18} /> : <ArrowUpRight size={18} />}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold truncate">{t.title}</p>
                        <p className="text-xs opacity-55">
                          {cat ? (isAr ? cat.ar : cat.en) : t.category} · {t.date} · {t.payment_method}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={`text-sm font-bold font-mono-num ${
                          t.type === 'income' ? 'text-emerald-400' : 'text-white'
                        }`}
                      >
                        {t.type === 'income' ? '+' : '-'}
                        {formatCurrency(t.amount, lang)}
                      </span>
                      <button
                        onClick={() => openModal(t.type, t)}
                        className="p-1.5 rounded-lg hover:bg-white/10 opacity-65 hover:opacity-100 cursor-pointer"
                      >
                        <Edit3 size={14} />
                      </button>
                      <button
                        onClick={async () => {
                          await apiFetch(`/api/transactions/${t.id}`, { method: 'DELETE' });
                          load();
                        }}
                        className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </GlassCard>
      </div>

      <GlassModal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={
          editing
            ? isAr
              ? 'تعديل المعاملة'
              : 'Edit Transaction'
            : form.type === 'income'
            ? isAr
              ? 'إضافة دخل جديد'
              : 'Add Income'
            : isAr
            ? 'إضافة مصروف جديد'
            : 'Add Expense'
        }
      >
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setForm({ ...form, type: 'expense' })}
              className={`min-h-[42px] rounded-xl text-xs font-semibold cursor-pointer ${
                form.type === 'expense' ? 'bg-[#FF7900] text-white' : 'bg-white/6 text-white/70'
              }`}
            >
              {isAr ? 'مصروف' : 'Expense'}
            </button>
            <button
              type="button"
              onClick={() => setForm({ ...form, type: 'income' })}
              className={`min-h-[42px] rounded-xl text-xs font-semibold cursor-pointer ${
                form.type === 'income' ? 'bg-emerald-600 text-white' : 'bg-white/6 text-white/70'
              }`}
            >
              {isAr ? 'دخل' : 'Income'}
            </button>
          </div>
          <InputField
            label={isAr ? 'الوصف' : 'Title'}
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            required
          />
          <div className="grid grid-cols-2 gap-3">
            <InputField
              label={isAr ? 'المبلغ' : 'Amount'}
              type="number"
              step="0.01"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              required
            />
            <InputField
              label={isAr ? 'التاريخ' : 'Date'}
              type="date"
              value={form.date}
              onChange={(e) => setForm({ ...form, date: e.target.value })}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <SelectField
              label={isAr ? 'التصنيف' : 'Category'}
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
            >
              {EXPENSE_CATEGORIES.map((c) => (
                <option key={c.id} value={c.id}>
                  {isAr ? c.ar : c.en}
                </option>
              ))}
            </SelectField>
            <SelectField
              label={isAr ? 'طريقة الدفع' : 'Payment Method'}
              value={form.payment_method}
              onChange={(e) => setForm({ ...form, payment_method: e.target.value })}
            >
              <option value="card">{isAr ? 'بطاقة' : 'Card'}</option>
              <option value="cash">{isAr ? 'نقدي' : 'Cash'}</option>
              <option value="bank">{isAr ? 'تحويل بنكي' : 'Bank'}</option>
              <option value="apple_pay">Apple Pay</option>
            </SelectField>
          </div>
          <SelectField
            label={isAr ? 'إرفاق فاتورة' : 'Attach Invoice'}
            value={form.invoice_doc_id}
            onChange={(e) => setForm({ ...form, invoice_doc_id: e.target.value })}
          >
            <option value="">{isAr ? 'بدون فاتورة' : 'None'}</option>
            {docs.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}.{d.ext}
              </option>
            ))}
          </SelectField>
          <InputField
            label={isAr ? 'ملاحظات' : 'Notes'}
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
          />
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={() => setModalOpen(false)} className="px-4 py-2 rounded-xl bg-white/8 text-sm cursor-pointer">
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <PrimaryButton type="submit">{isAr ? 'حفظ' : 'Save'}</PrimaryButton>
          </div>
        </form>
      </GlassModal>
    </div>
  );
};
