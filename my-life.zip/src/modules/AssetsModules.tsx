import React, { useEffect, useState } from 'react';
import { Building2, CheckSquare, Plane, Plus, ShieldCheck, Trash2, Wrench, AlertCircle } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatCurrency } from '../lib/i18n';
import type { Language, MaintenanceItem, PropertyItem, TripItem, WarrantyItem } from '../types';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

export const WarrantiesModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [items, setItems] = useState<WarrantyItem[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    product_name: '',
    manufacturer: '',
    purchase_date: new Date().toISOString().slice(0, 10),
    expiry_date: new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10),
    serial_number: '',
    service_center: '',
    notes: '',
  });

  const load = async () => {
    const res = await apiFetch<{ warranties: WarrantyItem[] }>('/api/warranties');
    setItems(res.warranties || []);
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <PrimaryButton onClick={() => setOpen(true)}>
          <Plus size={16} />
          <span>{isAr ? 'تسجيل ضمان منتج' : 'Register Warranty'}</span>
        </PrimaryButton>
      </div>

      {items.length === 0 ? (
        <GlassCard className="p-10 text-center text-sm opacity-65">{isAr ? 'لا توجد ضمانات مسجلة.' : 'No warranties registered.'}</GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {items.map((w) => {
            const daysLeft = Math.ceil((new Date(w.expiry_date).getTime() - Date.now()) / 86400000);
            const expiringSoon = daysLeft >= 0 && daysLeft <= 45;
            return (
              <GlassCard key={w.id} className="p-5 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-blue-500/15 text-blue-400 flex items-center justify-center shrink-0">
                      <ShieldCheck size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm">{w.product_name}</h4>
                      <p className="text-xs opacity-60">{w.manufacturer || '—'}</p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      await apiFetch(`/api/warranties/${w.id}`, { method: 'DELETE' });
                      load();
                    }}
                    className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
                <div className="text-xs space-y-1 opacity-75">
                  <p className="font-mono-num">S/N: {w.serial_number || '—'}</p>
                  <p>{isAr ? 'مركز الصيانة:' : 'Service Center:'} {w.service_center || '—'}</p>
                  <p className="font-mono-num">{isAr ? 'ينتهي في:' : 'Expires:'} {w.expiry_date}</p>
                </div>
                {expiringSoon && (
                  <p className="text-xs text-amber-400 flex items-center gap-1 font-semibold">
                    <AlertCircle size={13} />
                    {isAr ? `ينتهي الضمان خلال ${daysLeft} يومًا` : `Expires in ${daysLeft} days`}
                  </p>
                )}
              </GlassCard>
            );
          })}
        </div>
      )}

      <GlassModal open={open} onClose={() => setOpen(false)} title={isAr ? 'تسجيل ضمان جديد' : 'Add Product Warranty'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/warranties', { method: 'POST', body: JSON.stringify(form) });
            setOpen(false);
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'اسم المنتج' : 'Product Name'} value={form.product_name} onChange={(e) => setForm({ ...form, product_name: e.target.value })} required />
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'الشركة المصنعة' : 'Manufacturer'} value={form.manufacturer} onChange={(e) => setForm({ ...form, manufacturer: e.target.value })} />
            <InputField label={isAr ? 'رقم التسلسل' : 'Serial Number'} value={form.serial_number} onChange={(e) => setForm({ ...form, serial_number: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'تاريخ الشراء' : 'Purchase Date'} type="date" value={form.purchase_date} onChange={(e) => setForm({ ...form, purchase_date: e.target.value })} />
            <InputField label={isAr ? 'انتهاء الضمان' : 'Expiry Date'} type="date" value={form.expiry_date} onChange={(e) => setForm({ ...form, expiry_date: e.target.value })} />
          </div>
          <InputField label={isAr ? 'مركز الصيانة' : 'Service Center'} value={form.service_center} onChange={(e) => setForm({ ...form, service_center: e.target.value })} />
          <PrimaryButton type="submit" className="w-full">{isAr ? 'حفظ الضمان' : 'Save Warranty'}</PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};

export const MaintenanceModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [logs, setLogs] = useState<MaintenanceItem[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    category: 'home' as MaintenanceItem['category'],
    title: '',
    service_center: '',
    scheduled_date: new Date().toISOString().slice(0, 10),
    cost: '0',
    status: 'scheduled' as MaintenanceItem['status'],
    notes: '',
  });

  const load = async () => {
    const res = await apiFetch<{ logs: MaintenanceItem[] }>('/api/maintenance');
    setLogs(res.logs || []);
  };

  useEffect(() => {
    load();
  }, []);

  const cats = [
    { id: 'car', ar: 'السيارة', en: 'Car' },
    { id: 'home', ar: 'المنزل', en: 'Home' },
    { id: 'appliances', ar: 'الأجهزة', en: 'Appliances' },
    { id: 'ac', ar: 'المكيفات', en: 'AC' },
    { id: 'equipment', ar: 'المعدات', en: 'Equipment' },
    { id: 'other', ar: 'أخرى', en: 'Other' },
  ];

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <PrimaryButton onClick={() => setOpen(true)}>
          <Plus size={16} />
          <span>{isAr ? 'طلب صيانة جديد' : 'New Maintenance Request'}</span>
        </PrimaryButton>
      </div>

      {logs.length === 0 ? (
        <GlassCard className="p-10 text-center text-sm opacity-65">{isAr ? 'لا توجد طلبات صيانة.' : 'No maintenance records.'}</GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {logs.map((m) => {
            const c = cats.find((x) => x.id === m.category);
            return (
              <GlassCard key={m.id} className="p-5 flex items-center justify-between gap-4">
                <div className="flex items-center gap-3.5">
                  <div className="w-11 h-11 rounded-2xl bg-pink-500/15 text-pink-400 flex items-center justify-center">
                    <Wrench size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{m.title}</h4>
                    <p className="text-xs opacity-60">
                      {c ? (isAr ? c.ar : c.en) : m.category} · {m.scheduled_date} · {formatCurrency(m.cost, lang)}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <select
                    value={m.status}
                    onChange={async (e) => {
                      await apiFetch(`/api/maintenance/${m.id}`, {
                        method: 'PATCH',
                        body: JSON.stringify({ status: e.target.value, cost: m.cost }),
                      });
                      load();
                    }}
                    className="rounded-lg bg-[#18181b] border border-white/12 px-2 py-1 text-xs"
                  >
                    <option value="scheduled">{isAr ? 'مجدولة' : 'Scheduled'}</option>
                    <option value="in_progress">{isAr ? 'قيد التنفيذ' : 'In Progress'}</option>
                    <option value="completed">{isAr ? 'مكتملة' : 'Completed'}</option>
                  </select>
                  <button
                    onClick={async () => {
                      await apiFetch(`/api/maintenance/${m.id}`, { method: 'DELETE' });
                      load();
                    }}
                    className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </GlassCard>
            );
          })}
        </div>
      )}

      <GlassModal open={open} onClose={() => setOpen(false)} title={isAr ? 'إضافة سجل صيانة' : 'Schedule Maintenance'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/maintenance', { method: 'POST', body: JSON.stringify({ ...form, cost: Number(form.cost || 0) }) });
            setOpen(false);
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'وصف الصيانة' : 'Title'} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <div className="grid grid-cols-2 gap-3">
            <SelectField label={isAr ? 'القسم' : 'Category'} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value as MaintenanceItem['category'] })}>
              {cats.map((c) => (
                <option key={c.id} value={c.id}>{isAr ? c.ar : c.en}</option>
              ))}
            </SelectField>
            <InputField label={isAr ? 'التاريخ المجدول' : 'Date'} type="date" value={form.scheduled_date} onChange={(e) => setForm({ ...form, scheduled_date: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'التكلفة المتوقعة' : 'Cost'} type="number" value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })} />
            <InputField label={isAr ? 'مركز الخدمة' : 'Service Center'} value={form.service_center} onChange={(e) => setForm({ ...form, service_center: e.target.value })} />
          </div>
          <PrimaryButton type="submit" className="w-full">{isAr ? 'حفظ' : 'Save'}</PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};

export const PropertiesModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [items, setItems] = useState<PropertyItem[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    name: '',
    address: '',
    value: '',
    lease_start: '',
    lease_end: '',
    monthly_rent: '',
    expenses_total: '0',
    revenue_total: '0',
    notes: '',
  });

  const load = async () => {
    const res = await apiFetch<{ properties: PropertyItem[] }>('/api/properties');
    setItems(res.properties || []);
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <PrimaryButton onClick={() => setOpen(true)}>
          <Plus size={16} />
          <span>{isAr ? 'إضافة عقار' : 'Add Property'}</span>
        </PrimaryButton>
      </div>
      {items.length === 0 ? (
        <GlassCard className="p-10 text-center text-sm opacity-65">{isAr ? 'لا توجد عقارات مسجلة بعد.' : 'No properties added yet.'}</GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {items.map((p) => (
            <GlassCard key={p.id} className="p-5 space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-teal-500/15 text-teal-400 flex items-center justify-center">
                    <Building2 size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm">{p.name}</h4>
                    <p className="text-xs opacity-60">{p.address}</p>
                  </div>
                </div>
                <button
                  onClick={async () => {
                    await apiFetch(`/api/properties/${p.id}`, { method: 'DELETE' });
                    load();
                  }}
                  className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                >
                  <Trash2 size={14} />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/8 text-xs">
                <div>
                  <span className="opacity-60 block">{isAr ? 'القيمة' : 'Value'}</span>
                  <span className="font-bold font-mono-num">{formatCurrency(p.value, lang)}</span>
                </div>
                <div>
                  <span className="opacity-60 block">{isAr ? 'الإيجار الشهري' : 'Monthly Rent'}</span>
                  <span className="font-bold font-mono-num text-emerald-400">{formatCurrency(p.monthly_rent, lang)}</span>
                </div>
                <div>
                  <span className="opacity-60 block">{isAr ? 'انتهاء العقد' : 'Lease End'}</span>
                  <span className="font-bold font-mono-num">{p.lease_end || '—'}</span>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      )}

      <GlassModal open={open} onClose={() => setOpen(false)} title={isAr ? 'إضافة عقار وممتلكات' : 'Add Property'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/properties', {
              method: 'POST',
              body: JSON.stringify({
                ...form,
                value: Number(form.value || 0),
                monthly_rent: Number(form.monthly_rent || 0),
                expenses_total: Number(form.expenses_total || 0),
                revenue_total: Number(form.revenue_total || 0),
              }),
            });
            setOpen(false);
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'اسم العقار' : 'Property Name'} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <InputField label={isAr ? 'العنوان' : 'Address'} value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} required />
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'قيمة العقار' : 'Value'} type="number" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
            <InputField label={isAr ? 'الإيجار الشهري' : 'Monthly Rent'} type="number" value={form.monthly_rent} onChange={(e) => setForm({ ...form, monthly_rent: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'بداية العقد' : 'Lease Start'} type="date" value={form.lease_start} onChange={(e) => setForm({ ...form, lease_start: e.target.value })} />
            <InputField label={isAr ? 'انتهاء العقد' : 'Lease End'} type="date" value={form.lease_end} onChange={(e) => setForm({ ...form, lease_end: e.target.value })} />
          </div>
          <PrimaryButton type="submit" className="w-full">{isAr ? 'حفظ العقار' : 'Save Property'}</PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};

export const TravelModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [trips, setTrips] = useState<TripItem[]>([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    destination: '',
    departure_date: new Date().toISOString().slice(0, 10),
    return_date: new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10),
    flight_info: '',
    hotel_info: '',
    budget: '',
    spent: '0',
    notes: '',
  });

  const load = async () => {
    const res = await apiFetch<{ trips: TripItem[] }>('/api/trips');
    setTrips(res.trips || []);
  };

  useEffect(() => {
    load();
  }, []);

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <PrimaryButton onClick={() => setOpen(true)}>
          <Plus size={16} />
          <span>{isAr ? 'إضافة رحلة' : 'Add Trip'}</span>
        </PrimaryButton>
      </div>

      {trips.length === 0 ? (
        <GlassCard className="p-10 text-center text-sm opacity-65">{isAr ? 'لا توجد رحلات مضافة بعد.' : 'No trips added yet.'}</GlassCard>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {trips.map((tr) => {
            const checklist: { id: string; text: string; done: boolean }[] = JSON.parse(tr.checklist_json || '[]');
            return (
              <GlassCard key={tr.id} className="p-5 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-purple-500/15 text-purple-300 flex items-center justify-center">
                      <Plane size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-base">{tr.destination}</h4>
                      <p className="text-xs opacity-60 font-mono-num">
                        {tr.departure_date} → {tr.return_date}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={async () => {
                      await apiFetch(`/api/trips/${tr.id}`, { method: 'DELETE' });
                      load();
                    }}
                    className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                <div className="text-xs space-y-1 opacity-75">
                  {tr.flight_info && <p>{isAr ? 'الطيران:' : 'Flight:'} {tr.flight_info}</p>}
                  {tr.hotel_info && <p>{isAr ? 'الفندق:' : 'Hotel:'} {tr.hotel_info}</p>}
                  <p className="font-mono-num">
                    {isAr ? 'الميزانية:' : 'Budget:'} {formatCurrency(tr.budget, lang)}
                  </p>
                </div>

                <div className="pt-2 border-t border-white/8 space-y-1.5">
                  <p className="text-xs font-semibold opacity-75">{isAr ? 'قائمة تجهيزات السفر' : 'Packing Checklist'}</p>
                  {checklist.map((c) => (
                    <button
                      key={c.id}
                      onClick={async () => {
                        const updated = checklist.map((x) => (x.id === c.id ? { ...x, done: !x.done } : x));
                        await apiFetch(`/api/trips/${tr.id}`, {
                          method: 'PATCH',
                          body: JSON.stringify({ checklist: updated }),
                        });
                        load();
                      }}
                      className="flex items-center gap-2 text-xs cursor-pointer"
                    >
                      <CheckSquare size={14} className={c.done ? 'text-emerald-400' : 'opacity-45'} />
                      <span className={c.done ? 'line-through opacity-55' : ''}>{c.text}</span>
                    </button>
                  ))}
                </div>
              </GlassCard>
            );
          })}
        </div>
      )}

      <GlassModal open={open} onClose={() => setOpen(false)} title={isAr ? 'إضافة رحلة وحجوزات' : 'Add Trip'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/trips', {
              method: 'POST',
              body: JSON.stringify({
                ...form,
                budget: Number(form.budget || 0),
                spent: Number(form.spent || 0),
                checklist: [
                  { id: '1', text: isAr ? 'جواز السفر والتأشيرة' : 'Passport & Visa', done: false },
                  { id: '2', text: isAr ? 'تذاكر الطيران والفندق' : 'Flight & Hotel Confirmations', done: false },
                ],
              }),
            });
            setOpen(false);
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'الوجهة' : 'Destination'} value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} required />
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'تاريخ المغادرة' : 'Departure'} type="date" value={form.departure_date} onChange={(e) => setForm({ ...form, departure_date: e.target.value })} />
            <InputField label={isAr ? 'تاريخ العودة' : 'Return'} type="date" value={form.return_date} onChange={(e) => setForm({ ...form, return_date: e.target.value })} />
          </div>
          <InputField label={isAr ? 'معلومات الطيران' : 'Flight Info'} value={form.flight_info} onChange={(e) => setForm({ ...form, flight_info: e.target.value })} />
          <InputField label={isAr ? 'حجز الفندق' : 'Hotel Info'} value={form.hotel_info} onChange={(e) => setForm({ ...form, hotel_info: e.target.value })} />
          <InputField label={isAr ? 'الميزانية' : 'Budget'} type="number" value={form.budget} onChange={(e) => setForm({ ...form, budget: e.target.value })} />
          <PrimaryButton type="submit" className="w-full">{isAr ? 'حفظ الرحلة' : 'Save Trip'}</PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};
