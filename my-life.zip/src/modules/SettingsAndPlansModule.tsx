import React, { useEffect, useState } from 'react';
import {
  Check,
  Crown,
  Download,
  Laptop,
  LogOut,
  Moon,
  Shield,
  Smartphone,
  Sun,
  Trash2,
} from 'lucide-react';
import { apiFetch } from '../lib/api';
import type { CardStyle, IconShape, Language, ModuleId, ThemeMode, User } from '../types';
import { GlassCard, InputField, PrimaryButton } from '../components/GlassUI';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const SettingsModule: React.FC<{
  user: User;
  lang: Language;
  onUserUpdate: (u: User) => void;
  onNavigate: (mod: ModuleId) => void;
  onOpenInstall: () => void;
  onLogout: () => void;
  pwa: ReturnType<typeof usePWAInstall>;
}> = ({ user, lang, onUserUpdate, onNavigate, onOpenInstall, onLogout, pwa }) => {
  const isAr = lang === 'ar';
  const [name, setName] = useState(user.name);
  const [email, setEmail] = useState(user.email);
  const [theme, setTheme] = useState<ThemeMode>(user.theme);
  const [language, setLanguage] = useState<Language>(user.language);
  const [accentColor, setAccentColor] = useState(user.accent_color || '#FF7900');
  const [iconShape, setIconShape] = useState<IconShape>(user.icon_shape || 'squircle');
  const [cardStyle, setCardStyle] = useState<CardStyle>(user.card_style || 'glass');
  const [notificationsEnabled, setNotificationsEnabled] = useState(Boolean(user.notifications_enabled));
  const [privacyMode, setPrivacyMode] = useState(Boolean(user.privacy_mode));

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [sessions, setSessions] = useState<{ id: string; device_name: string; last_active_at: string }[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState('');
  const [msg, setMsg] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    apiFetch<{ sessions: typeof sessions; currentSessionId: string }>('/api/auth/sessions')
      .then((res) => {
        setSessions(res.sessions || []);
        setCurrentSessionId(res.currentSessionId || '');
      })
      .catch(() => {});
  }, []);

  const saveProfile = async (overrides?: Partial<User>) => {
    const payload = {
      name,
      email,
      theme,
      language,
      accent_color: accentColor,
      icon_shape: iconShape,
      card_style: cardStyle,
      notifications_enabled: notificationsEnabled,
      privacy_mode: privacyMode,
      ...overrides,
    };
    const res = await apiFetch<{ user: User }>('/api/auth/profile', {
      method: 'PATCH',
      body: JSON.stringify(payload),
    });
    onUserUpdate(res.user);
    setMsg(isAr ? 'تم حفظ الإعدادات وتطبيق المظهر' : 'Settings saved & applied');
  };

  const accentPalette = ['#FF7900', '#EF4444', '#EC4899', '#8B5CF6', '#3B82F6', '#10B981'];

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {msg && (
        <div className="rounded-2xl bg-emerald-500/15 border border-emerald-500/35 px-4 py-3 text-xs text-emerald-200">
          {msg}
        </div>
      )}

      {/* Account */}
      <GlassCard className="p-6 space-y-4">
        <h3 className="font-bold text-base">{isAr ? 'الحساب والملف الشخصي' : 'Account & Profile'}</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <InputField label={isAr ? 'الاسم الكامل' : 'Full Name'} value={name} onChange={(e) => setName(e.target.value)} />
          <InputField label={isAr ? 'البريد الإلكتروني' : 'Email'} type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <PrimaryButton onClick={() => saveProfile()}>{isAr ? 'حفظ بيانات الحساب' : 'Save Profile'}</PrimaryButton>
      </GlassCard>

      {/* Theme, Language & Visual Customization */}
      <GlassCard className="p-6 space-y-5">
        <h3 className="font-bold text-base">{isAr ? 'التخصيص والمظهر واللغة' : 'Theme, Language & Appearance'}</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <span className="text-xs opacity-70">{isAr ? 'المظهر' : 'Theme Mode'}</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setTheme('dark');
                  saveProfile({ theme: 'dark' });
                }}
                className={`min-h-[44px] rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer ${
                  theme === 'dark' ? 'bg-[#FF7900]/20 border-[#FF7900]' : 'bg-white/5 border-white/10'
                }`}
              >
                <Moon size={15} />
                <span>{isAr ? 'داكن' : 'Dark'}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setTheme('light');
                  saveProfile({ theme: 'light' });
                }}
                className={`min-h-[44px] rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer ${
                  theme === 'light' ? 'bg-[#FF7900]/20 border-[#FF7900]' : 'bg-white/5 border-white/10'
                }`}
              >
                <Sun size={15} />
                <span>{isAr ? 'فاتح' : 'Light'}</span>
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <span className="text-xs opacity-70">{isAr ? 'اللغة (RTL / LTR)' : 'Language (RTL / LTR)'}</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => {
                  setLanguage('ar');
                  saveProfile({ language: 'ar' });
                }}
                className={`min-h-[44px] rounded-xl border text-xs font-semibold cursor-pointer ${
                  language === 'ar' ? 'bg-[#FF7900]/20 border-[#FF7900]' : 'bg-white/5 border-white/10'
                }`}
              >
                العربية (RTL)
              </button>
              <button
                type="button"
                onClick={() => {
                  setLanguage('en');
                  saveProfile({ language: 'en' });
                }}
                className={`min-h-[44px] rounded-xl border text-xs font-semibold cursor-pointer ${
                  language === 'en' ? 'bg-[#FF7900]/20 border-[#FF7900]' : 'bg-white/5 border-white/10'
                }`}
              >
                English (LTR)
              </button>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <span className="text-xs opacity-70">{isAr ? 'لون السمة الرئيسي' : 'Primary Accent Color'}</span>
          <div className="flex flex-wrap items-center gap-2.5">
            {accentPalette.map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => {
                  setAccentColor(c);
                  saveProfile({ accent_color: c });
                }}
                className={`w-8 h-8 rounded-full border cursor-pointer transition ${
                  accentColor === c ? 'ring-2 ring-white scale-110' : 'border-white/25'
                }`}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <span className="text-xs opacity-70">{isAr ? 'شكل الأيقونات' : 'Icon Shape'}</span>
            <div className="grid grid-cols-3 gap-2">
              {(['squircle', 'circle', 'rounded'] as IconShape[]).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => {
                    setIconShape(s);
                    saveProfile({ icon_shape: s });
                  }}
                  className={`min-h-[40px] rounded-xl border text-xs cursor-pointer ${
                    iconShape === s ? 'bg-[#FF7900]/20 border-[#FF7900]' : 'bg-white/5 border-white/10'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            <span className="text-xs opacity-70">{isAr ? 'نمط البطاقات والمجلدات' : 'Surface Style'}</span>
            <div className="grid grid-cols-2 gap-2">
              {(['glass', 'classic'] as CardStyle[]).map((cs) => (
                <button
                  key={cs}
                  type="button"
                  onClick={() => {
                    setCardStyle(cs);
                    saveProfile({ card_style: cs });
                  }}
                  className={`min-h-[40px] rounded-xl border text-xs cursor-pointer ${
                    cardStyle === cs ? 'bg-[#FF7900]/20 border-[#FF7900]' : 'bg-white/5 border-white/10'
                  }`}
                >
                  {cs === 'glass' ? (isAr ? 'زجاجي' : 'Glass') : isAr ? 'كلاسيكي' : 'Classic'}
                </button>
              ))}
            </div>
          </div>
        </div>
      </GlassCard>

      {/* Password & Security */}
      <GlassCard className="p-6 space-y-4">
        <h3 className="font-bold text-base flex items-center gap-2">
          <Shield size={18} className="text-[#FF7900]" />
          <span>{isAr ? 'الأمان والخصوصية وتغيير كلمة المرور' : 'Security, Privacy & Password'}</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <InputField label={isAr ? 'كلمة المرور الحالية' : 'Current Password'} type="password" value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
          <InputField label={isAr ? 'كلمة المرور الجديدة' : 'New Password'} type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <PrimaryButton
            onClick={async () => {
              try {
                await apiFetch('/api/auth/password', {
                  method: 'POST',
                  body: JSON.stringify({ currentPassword, newPassword }),
                });
                setCurrentPassword('');
                setNewPassword('');
                setMsg(isAr ? 'تم تحديث كلمة المرور بنجاح' : 'Password updated');
              } catch (err) {
                setMsg((err as Error).message);
              }
            }}
          >
            {isAr ? 'تغيير كلمة المرور' : 'Update Password'}
          </PrimaryButton>
          <a
            href="/api/auth/export-data"
            className="min-h-[44px] px-4 rounded-xl bg-white/8 border border-white/12 text-xs font-semibold inline-flex items-center gap-2"
          >
            <Download size={15} />
            <span>{isAr ? 'تصدير جميع بياناتي (JSON)' : 'Export All My Data'}</span>
          </a>
        </div>

        <div className="flex flex-wrap gap-6 pt-2 text-xs">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={notificationsEnabled}
              onChange={(e) => {
                setNotificationsEnabled(e.target.checked);
                saveProfile({ notifications_enabled: e.target.checked ? 1 : 0 });
              }}
              className="accent-[#FF7900]"
            />
            <span>{isAr ? 'تفعيل الإشعارات والتنبيهات' : 'Enable Notifications'}</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={privacyMode}
              onChange={(e) => {
                setPrivacyMode(e.target.checked);
                saveProfile({ privacy_mode: e.target.checked ? 1 : 0 });
              }}
              className="accent-[#FF7900]"
            />
            <span>{isAr ? 'الالتزام بضوابط الخصوصية وحماية البيانات الشخصية' : 'Strict Personal Data Protection Mode'}</span>
          </label>
        </div>
      </GlassCard>

      {/* Connected Devices */}
      <GlassCard className="p-6 space-y-3">
        <h3 className="font-bold text-base flex items-center gap-2">
          <Laptop size={18} className="text-[#FF7900]" />
          <span>{isAr ? 'الأجهزة المتصلة والجلسات النشطة' : 'Connected Devices & Sessions'}</span>
        </h3>
        <div className="divide-y divide-white/8">
          {sessions.map((s) => (
            <div key={s.id} className="py-2.5 flex items-center justify-between text-xs">
              <div>
                <p className="font-bold">
                  {s.device_name} {s.id === currentSessionId ? (isAr ? '(الجهاز الحالي)' : '(Current)') : ''}
                </p>
                <p className="opacity-60 font-mono-num">{s.last_active_at.slice(0, 19).replace('T', ' ')}</p>
              </div>
              {s.id !== currentSessionId && (
                <button
                  onClick={async () => {
                    await apiFetch(`/api/auth/sessions/${s.id}`, { method: 'DELETE' });
                    setSessions((prev) => prev.filter((x) => x.id !== s.id));
                  }}
                  className="px-3 py-1.5 rounded-lg bg-red-500/20 text-red-300 cursor-pointer"
                >
                  {isAr ? 'إنهاء الجلسة' : 'Revoke'}
                </button>
              )}
            </div>
          ))}
        </div>
      </GlassCard>

      {/* Quick Links: Install PWA, Plans, Backup, Icon Library, Logout, Delete Account */}
      <GlassCard className="p-6 space-y-4">
        <h3 className="font-bold text-base">{isAr ? 'التطبيق والباقة والمساعدة' : 'App, Plan & Account Actions'}</h3>
        <div className="flex flex-wrap gap-3">
          {!pwa.isInstalled && (
            <button
              onClick={onOpenInstall}
              className="min-h-[44px] px-4 rounded-xl bg-[#FF7900]/20 border border-[#FF7900]/40 text-[#FF7900] text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
            >
              <Smartphone size={16} />
              <span>{isAr ? 'تثبيت تطبيق MY LIFE على الجهاز' : 'Install MY LIFE App'}</span>
            </button>
          )}
          <button
            onClick={() => onNavigate('plans')}
            className="min-h-[44px] px-4 rounded-xl bg-white/8 border border-white/12 text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
          >
            <Crown size={16} className="text-amber-400" />
            <span>{isAr ? `إدارة الباقة (${user.plan})` : `Manage Plan (${user.plan})`}</span>
          </button>
          <button
            onClick={() => onNavigate('backup')}
            className="min-h-[44px] px-4 rounded-xl bg-white/8 border border-white/12 text-xs font-semibold cursor-pointer"
          >
            {isAr ? 'النسخ الاحتياطي المشفر' : 'Encrypted Backups'}
          </button>
          <button
            onClick={onLogout}
            className="min-h-[44px] px-4 rounded-xl bg-white/8 border border-white/12 text-xs font-semibold inline-flex items-center gap-2 cursor-pointer"
          >
            <LogOut size={15} />
            <span>{isAr ? 'تسجيل الخروج' : 'Sign Out'}</span>
          </button>
        </div>

        <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
          <div className="text-xs opacity-65">
            MY LIFE · YOUR LIFE, ORGANIZED. · {isAr ? 'حماية البيانات والخصوصية متوافقة مع متطلبات حماية البيانات الشخصية.' : 'Privacy-first personal digital life ecosystem.'}
          </div>
          {!confirmDelete ? (
            <button
              onClick={() => setConfirmDelete(true)}
              className="px-3.5 py-2 rounded-xl bg-red-500/15 text-red-300 text-xs font-semibold cursor-pointer"
            >
              {isAr ? 'حذف الحساب نهائيًا' : 'Delete Account'}
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                onClick={async () => {
                  await apiFetch('/api/auth/delete-account', { method: 'DELETE' });
                  onLogout();
                }}
                className="px-3.5 py-2 rounded-xl bg-red-600 text-white text-xs font-semibold inline-flex items-center gap-1 cursor-pointer"
              >
                <Trash2 size={14} />
                <span>{isAr ? 'تأكيد الحذف النهائي' : 'Confirm Permanent Delete'}</span>
              </button>
              <button onClick={() => setConfirmDelete(false)} className="px-3 py-2 rounded-xl bg-white/10 text-xs cursor-pointer">
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          )}
        </div>
      </GlassCard>
    </div>
  );
};

export const PlansModule: React.FC<{
  user: User;
  lang: Language;
  onUserUpdate: (u: User) => void;
}> = ({ user, lang, onUserUpdate }) => {
  const isAr = lang === 'ar';
  const [billing, setBilling] = useState<{ id: string; plan: string; amount: number; status: string; invoice_number: string; created_at: string }[]>([]);
  const [notice, setNotice] = useState('');

  const load = async () => {
    const res = await apiFetch<{ currentPlan: string; billingHistory: typeof billing }>('/api/plans');
    setBilling(res.billingHistory || []);
  };

  useEffect(() => {
    load();
  }, []);

  const plans = [
    {
      id: 'FREE' as const,
      price: 0,
      audience: isAr ? 'للاستخدام الشخصي الأساسي' : 'Personal essentials',
      features: isAr
        ? ['جميع الأقسام الـ 21 الأساسية', 'حتى 3 أدوات مخصصة', 'مساحة تخزين 1 جيجابايت', 'مجلدات زجاجية ثلاثية الأبعاد']
        : ['All 21 core sections', 'Up to 3 custom widgets', '1 GB document storage', '3D Glass Folders'],
    },
    {
      id: 'PLUS' as const,
      price: 29,
      audience: isAr ? 'للأفراد الأكثر إنتاجية' : 'Power individuals',
      features: isAr
        ? ['أدوات مخصصة غير محدودة', 'تقارير متقدمة وتصدير PDF/Excel', 'مساحة تخزين 50 جيجابايت', 'تخصيص كامل للألوان والمجلدات']
        : ['Unlimited custom widgets', 'Advanced PDF/Excel reports', '50 GB document storage', 'Full theme & folder customization'],
    },
    {
      id: 'FAMILY' as const,
      price: 49,
      audience: isAr ? 'لإدارة شؤون العائلة' : 'Connected families',
      features: isAr
        ? ['حتى 6 أفراد في المجموعة', 'ميزانية ومصروفات عائلية مشتركة', 'صلاحيات وصول مخصصة لكل فرد', 'مساحة تخزين 200 جيجابايت']
        : ['Up to 6 family members', 'Shared family budget & bills', 'Per-member RBAC permissions', '200 GB shared storage'],
    },
    {
      id: 'BUSINESS' as const,
      price: 99,
      audience: isAr ? 'للشركات وفرق العمل' : 'Teams & businesses',
      features: isAr
        ? ['أدوات أعمال وإدارة موظفين', 'تقارير تجارية ومالية متقدمة', 'صلاحيات متعددة المستويات', 'مساحة تخزين 1 تيرابايت']
        : ['Business tools & staff management', 'Commercial financial reports', 'Multi-tier role permissions', '1 TB team storage'],
    },
  ];

  const selectPlan = async (planId: User['plan']) => {
    await apiFetch('/api/plans/select', {
      method: 'POST',
      body: JSON.stringify({ plan: planId }),
    });
    const me = await apiFetch<{ user: User }>('/api/auth/me');
    onUserUpdate(me.user);
    setNotice(
      planId === 'FREE'
        ? isAr
          ? 'تم التبديل إلى الباقة المجانية FREE.'
          : 'Switched to FREE plan.'
        : isAr
        ? `تم تسجيل طلب باقة ${planId}. تفعيل الدفع الفعلي يتطلب ربط بوابة دفع معتمدة.`
        : `Selected ${planId}. Live billing requires configuring a compliant payment gateway.`
    );
    load();
  };

  return (
    <div className="space-y-6">
      {notice && (
        <div className="rounded-2xl bg-[#FF7900]/15 border border-[#FF7900]/35 px-4 py-3 text-xs text-white">
          {notice}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {plans.map((p) => {
          const active = user.plan === p.id;
          return (
            <GlassCard key={p.id} className={`p-6 flex flex-col justify-between gap-5 ${active ? 'border-[#FF7900]' : ''}`}>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-bold">{p.id}</h4>
                  {active && <span className="text-xs font-semibold text-[#FF7900]">{isAr ? 'الباقة الحالية' : 'Current'}</span>}
                </div>
                <p className="text-xs opacity-65">{p.audience}</p>
                <div className="pt-1">
                  <span className="text-3xl font-bold font-mono-num">{p.price}</span>
                  <span className="text-xs opacity-65 ms-1">{isAr ? 'ر.س / شهريًا' : 'SAR / mo'}</span>
                </div>
                <ul className="space-y-2 pt-2 text-xs opacity-85">
                  {p.features.map((f) => (
                    <li key={f} className="flex items-start gap-2">
                      <Check size={14} className="text-emerald-400 shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <PrimaryButton
                onClick={() => selectPlan(p.id)}
                disabled={active}
                className="w-full"
              >
                {active ? (isAr ? 'مفعّلة حاليًا' : 'Active') : isAr ? `اختيار ${p.id}` : `Select ${p.id}`}
              </PrimaryButton>
            </GlassCard>
          );
        })}
      </div>

      <GlassCard className="p-5 space-y-3">
        <div className="flex items-center justify-between">
          <h4 className="text-sm font-bold">{isAr ? 'سجل الفواتير والاشتراكات' : 'Billing & Plan History'}</h4>
          {user.plan !== 'FREE' && (
            <button
              onClick={() => selectPlan('FREE')}
              className="px-3 py-1.5 rounded-xl bg-red-500/20 text-red-300 text-xs cursor-pointer"
            >
              {isAr ? 'إلغاء الاشتراك والعودة للمجانية' : 'Cancel Paid Plan'}
            </button>
          )}
        </div>
        {billing.length === 0 ? (
          <p className="text-xs opacity-60 py-4">{isAr ? 'لا توجد فواتير مسجلة.' : 'No billing records yet.'}</p>
        ) : (
          <div className="divide-y divide-white/8 text-xs">
            {billing.map((b) => (
              <div key={b.id} className="py-2.5 flex items-center justify-between">
                <span className="font-mono">{b.invoice_number} · {b.plan}</span>
                <span className="font-mono-num">{b.amount} SAR · {b.status}</span>
              </div>
            ))}
          </div>
        )}
      </GlassCard>
    </div>
  );
};
