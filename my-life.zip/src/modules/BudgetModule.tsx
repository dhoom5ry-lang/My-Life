import React, { useEffect, useMemo, useState } from 'react';
import { AlertTriangle, PiggyBank, Plus, Trash2, Wallet } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatCurrency } from '../lib/i18n';
import type { BudgetItem, Language, SavingsGoal, TransactionItem } from '../types';
import { EXPENSE_CATEGORIES } from './ExpensesModule';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

export const BudgetModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [budgets, setBudgets] = useState<BudgetItem[]>([]);
  const [savings, setSavings] = useState<SavingsGoal[]>([]);
  const [txs, setTxs] = useState<TransactionItem[]>([]);
  const [budgetModal, setBudgetModal] = useState(false);
  const [goalModal, setGoalModal] = useState(false);

  const [bForm, setBForm] = useState({ category: 'food', period: 'monthly', limit_amount: '', alert_threshold: '80' });
  const [gForm, setGForm] = useState({ title: '', target_amount: '', current_amount: '0', deadline: '' });

  const load = async () => {
    const [bRes, tRes] = await Promise.all([
      apiFetch<{ budgets: BudgetItem[]; savings: SavingsGoal[] }>('/api/budgets'),
      apiFetch<{ transactions: TransactionItem[] }>('/api/transactions'),
    ]);
    setBudgets(bRes.budgets || []);
    setSavings(bRes.savings || []);
    setTxs(tRes.transactions || []);
  };

  useEffect(() => {
    load();
  }, []);

  const spentByCat = useMemo(() => {
    const monthPrefix = new Date().toISOString().slice(0, 7);
    const map: Record<string, number> = {};
    for (const t of txs) {
      if (t.type === 'expense' && t.date.startsWith(monthPrefix)) {
        map[t.category] = (map[t.category] || 0) + t.amount;
      }
    }
    return map;
  }, [txs]);

  const totalBudget = budgets.reduce((acc, b) => acc + b.limit_amount, 0);
  const totalSpent = budgets.reduce((acc, b) => acc + (spentByCat[b.category] || 0), 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <PrimaryButton onClick={() => setBudgetModal(true)}>
            <Plus size={16} />
            <span>{isAr ? 'إضافة ميزانية' : 'Add Budget'}</span>
          </PrimaryButton>
          <button
            onClick={() => setGoalModal(true)}
            className="min-h-[44px] px-4 rounded-xl bg-emerald-500/20 border border-emerald-500/35 text-emerald-300 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
          >
            <PiggyBank size={16} />
            <span>{isAr ? 'هدف ادخار جديد' : 'New Savings Goal'}</span>
          </button>
        </div>
      </div>

      {/* Overall Budget Summary */}
      <GlassCard className="p-6 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs opacity-60">{isAr ? 'ملخص الميزانية الشهرية' : 'Monthly Budget Overview'}</p>
            <h3 className="text-2xl font-bold font-mono-num mt-1">{formatCurrency(totalBudget, lang)}</h3>
          </div>
          <div className="text-left">
            <p className="text-xs opacity-60">{isAr ? 'المصروف الفعلي' : 'Actual Spent'}</p>
            <p className="text-lg font-bold font-mono-num text-[#FF7900]">{formatCurrency(totalSpent, lang)}</p>
          </div>
        </div>
        <div className="h-3 rounded-full bg-white/10 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{
              width: `${totalBudget > 0 ? Math.min(100, Math.round((totalSpent / totalBudget) * 100)) : 0}%`,
              backgroundColor: totalSpent > totalBudget ? '#EF4444' : '#FF7900',
            }}
          />
        </div>
      </GlassCard>

      {/* Category Budgets */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {budgets.map((b) => {
          const cat = EXPENSE_CATEGORIES.find((c) => c.id === b.category);
          const spent = spentByCat[b.category] || 0;
          const pct = b.limit_amount > 0 ? Math.round((spent / b.limit_amount) * 100) : 0;
          const overAlert = pct >= b.alert_threshold;

          return (
            <GlassCard key={b.id} className="p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <Wallet size={18} style={{ color: cat?.color || '#FF7900' }} />
                  <h4 className="font-bold text-sm">{cat ? (isAr ? cat.ar : cat.en) : b.category}</h4>
                </div>
                <div className="flex items-center gap-2">
                  {overAlert && (
                    <span className="inline-flex items-center gap-1 text-xs text-red-400 font-semibold">
                      <AlertTriangle size={14} />
                      {pct >= 100 ? (isAr ? 'تجاوز الحد' : 'Exceeded') : `${pct}%`}
                    </span>
                  )}
                  <button
                    onClick={async () => {
                      await apiFetch(`/api/budgets/${b.id}`, { method: 'DELETE' });
                      load();
                    }}
                    className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
              <div className="flex justify-between text-xs font-mono-num opacity-75">
                <span>
                  {isAr ? 'المصروف:' : 'Spent:'} {formatCurrency(spent, lang)}
                </span>
                <span>
                  {isAr ? 'الحد:' : 'Limit:'} {formatCurrency(b.limit_amount, lang)}
                </span>
              </div>
              <div className="h-2.5 rounded-full bg-white/10 overflow-hidden">
                <div
                  className="h-full rounded-full"
                  style={{
                    width: `${Math.min(100, pct)}%`,
                    backgroundColor: pct >= 100 ? '#EF4444' : pct >= b.alert_threshold ? '#F59E0B' : '#22C55E',
                  }}
                />
              </div>
            </GlassCard>
          );
        })}
      </div>

      {/* Savings Goals */}
      <div className="space-y-3">
        <h3 className="text-base font-bold">{isAr ? 'أهداف الادخار' : 'Savings Goals'}</h3>
        {savings.length === 0 ? (
          <GlassCard className="p-8 text-center text-sm opacity-65">
            {isAr ? 'لم تضف أهداف ادخار بعد.' : 'No savings goals added yet.'}
          </GlassCard>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {savings.map((g) => {
              const pct = g.target_amount > 0 ? Math.min(100, Math.round((g.current_amount / g.target_amount) * 100)) : 0;
              return (
                <GlassCard key={g.id} className="p-5 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-sm">{g.title}</h4>
                      {g.deadline && <p className="text-xs opacity-55 font-mono-num">{g.deadline}</p>}
                    </div>
                    <button
                      onClick={async () => {
                        await apiFetch(`/api/savings/${g.id}`, { method: 'DELETE' });
                        load();
                      }}
                      className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                  <div className="flex justify-between text-xs font-mono-num">
                    <span className="text-emerald-400">{formatCurrency(g.current_amount, lang)}</span>
                    <span className="opacity-70">{formatCurrency(g.target_amount, lang)} ({pct}%)</span>
                  </div>
                  <div className="h-2.5 rounded-full bg-white/10 overflow-hidden">
                    <div className="h-full rounded-full bg-emerald-500" style={{ width: `${pct}%` }} />
                  </div>
                  <button
                    onClick={async () => {
                      await apiFetch(`/api/savings/${g.id}`, {
                        method: 'PATCH',
                        body: JSON.stringify({ current_amount: g.current_amount + 500 }),
                      });
                      load();
                    }}
                    className="w-full py-2 rounded-xl bg-white/8 hover:bg-emerald-500/20 text-xs font-semibold transition cursor-pointer"
                  >
                    + 500 {isAr ? 'ر.س إيداع للهدف' : 'SAR Deposit'}
                  </button>
                </GlassCard>
              );
            })}
          </div>
        )}
      </div>

      {/* Modals */}
      <GlassModal open={budgetModal} onClose={() => setBudgetModal(false)} title={isAr ? 'إضافة ميزانية' : 'Add Budget'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/budgets', {
              method: 'POST',
              body: JSON.stringify({
                ...bForm,
                limit_amount: Number(bForm.limit_amount || 0),
                alert_threshold: Number(bForm.alert_threshold || 80),
              }),
            });
            setBudgetModal(false);
            load();
          }}
          className="space-y-3.5"
        >
          <SelectField label={isAr ? 'التصنيف' : 'Category'} value={bForm.category} onChange={(e) => setBForm({ ...bForm, category: e.target.value })}>
            {EXPENSE_CATEGORIES.map((c) => (
              <option key={c.id} value={c.id}>
                {isAr ? c.ar : c.en}
              </option>
            ))}
          </SelectField>
          <InputField
            label={isAr ? 'حد الإنفاق' : 'Spending Limit'}
            type="number"
            value={bForm.limit_amount}
            onChange={(e) => setBForm({ ...bForm, limit_amount: e.target.value })}
            required
          />
          <InputField
            label={isAr ? 'نسبة التنبيه (%)' : 'Alert Threshold (%)'}
            type="number"
            value={bForm.alert_threshold}
            onChange={(e) => setBForm({ ...bForm, alert_threshold: e.target.value })}
          />
          <PrimaryButton type="submit" className="w-full">
            {isAr ? 'حفظ الميزانية' : 'Save Budget'}
          </PrimaryButton>
        </form>
      </GlassModal>

      <GlassModal open={goalModal} onClose={() => setGoalModal(false)} title={isAr ? 'هدف ادخار جديد' : 'New Savings Goal'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/savings', {
              method: 'POST',
              body: JSON.stringify({
                ...gForm,
                target_amount: Number(gForm.target_amount || 0),
                current_amount: Number(gForm.current_amount || 0),
              }),
            });
            setGoalModal(false);
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'اسم الهدف' : 'Goal Title'} value={gForm.title} onChange={(e) => setGForm({ ...gForm, title: e.target.value })} required />
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'المبلغ المستهدف' : 'Target Amount'} type="number" value={gForm.target_amount} onChange={(e) => setGForm({ ...gForm, target_amount: e.target.value })} required />
            <InputField label={isAr ? 'المدخر حاليًا' : 'Current Saved'} type="number" value={gForm.current_amount} onChange={(e) => setGForm({ ...gForm, current_amount: e.target.value })} />
          </div>
          <InputField label={isAr ? 'تاريخ الاستحقاق' : 'Deadline'} type="date" value={gForm.deadline} onChange={(e) => setGForm({ ...gForm, deadline: e.target.value })} />
          <PrimaryButton type="submit" className="w-full">
            {isAr ? 'حفظ الهدف' : 'Save Goal'}
          </PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};
