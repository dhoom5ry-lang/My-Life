import React, { useEffect, useMemo, useState } from 'react';
import { Check, Copy, Lock, Plus, Shield, Trash2, UserPlus, Users } from 'lucide-react';
import { apiFetch } from '../lib/api';
import { formatCurrency } from '../lib/i18n';
import type { FamilyItem, FamilyMember, Language } from '../types';
import { GlassCard, GlassModal, InputField, PrimaryButton, SelectField } from '../components/GlassUI';

export const FamilyModule: React.FC<{ lang: Language }> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [family, setFamily] = useState<{ id: string; name: string; invite_code: string } | null>(null);
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [items, setItems] = useState<FamilyItem[]>([]);
  const [currentMember, setCurrentMember] = useState<FamilyMember | null>(null);

  const [newFamName, setNewFamName] = useState('');
  const [joinCode, setJoinCode] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);

  const [memberModal, setMemberModal] = useState(false);
  const [mForm, setMForm] = useState({
    display_name: '',
    relation: 'son',
    role: 'member' as 'admin' | 'member' | 'viewer',
    view_budget: true,
    add_expenses: true,
    view_calendar: true,
    manage_tasks: true,
  });

  const [itemModal, setItemModal] = useState(false);
  const [iForm, setIForm] = useState({
    item_type: 'expense' as FamilyItem['item_type'],
    title: '',
    amount: '',
    target_amount: '',
    due_date: '',
    assigned_to: '',
  });

  const load = async () => {
    const res = await apiFetch<{
      family: { id: string; name: string; invite_code: string } | null;
      members: FamilyMember[];
      items: FamilyItem[];
      currentMember: FamilyMember | null;
    }>('/api/family');
    setFamily(res.family);
    setMembers(res.members || []);
    setItems(res.items || []);
    setCurrentMember(res.currentMember);
  };

  useEffect(() => {
    load();
  }, []);

  const stats = useMemo(() => {
    const expenses = items.filter((i) => i.item_type === 'expense' || i.item_type === 'bill' || i.item_type === 'purchase').reduce((a, b) => a + b.amount, 0);
    const goalsTotal = items.filter((i) => i.item_type === 'goal').reduce((a, b) => a + b.amount, 0);
    return { expenses, goalsTotal };
  }, [items]);

  if (!family) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        <GlassCard className="p-6 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-[#FF7900]/15 border border-[#FF7900]/30 flex items-center justify-center text-[#FF7900]">
            <Users size={24} />
          </div>
          <h3 className="text-lg font-bold">{isAr ? 'إنشاء مجموعة عائلية' : 'Create Family Group'}</h3>
          <p className="text-xs opacity-70">
            {isAr
              ? 'أنشئ مساحة عائلية آمنة لإدارة الميزانية والمشتريات والمهام والمواعيد المشتركة مع صلاحيات دقيقة لكل فرد.'
              : 'Create a private family group with role-based permissions for budgets, chores, bills, and savings.'}
          </p>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setErrorMsg('');
              try {
                await apiFetch('/api/family/create', { method: 'POST', body: JSON.stringify({ name: newFamName || 'عائلتي' }) });
                load();
              } catch (err) {
                setErrorMsg((err as Error).message);
              }
            }}
            className="space-y-3"
          >
            <InputField label={isAr ? 'اسم العائلة' : 'Family Name'} value={newFamName} onChange={(e) => setNewFamName(e.target.value)} placeholder={isAr ? 'مثال: عائلة الأحمد' : 'e.g. Al-Ahmad Family'} required />
            <PrimaryButton type="submit" className="w-full">
              {isAr ? 'إنشاء المجموعة' : 'Create Family'}
            </PrimaryButton>
          </form>
        </GlassCard>

        <GlassCard className="p-6 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-300">
            <UserPlus size={24} />
          </div>
          <h3 className="text-lg font-bold">{isAr ? 'الانضمام برمز دعوة' : 'Join with Invite Code'}</h3>
          <p className="text-xs opacity-70">
            {isAr
              ? 'أدخل رمز الدعوة الخاص بعائلتك للانضمام وفق الصلاحيات المعتمدة.'
              : 'Enter your family invite code to join with approved permissions.'}
          </p>
          <form
            onSubmit={async (e) => {
              e.preventDefault();
              setErrorMsg('');
              try {
                await apiFetch('/api/family/join', { method: 'POST', body: JSON.stringify({ invite_code: joinCode }) });
                load();
              } catch (err) {
                setErrorMsg((err as Error).message);
              }
            }}
            className="space-y-3"
          >
            <InputField label={isAr ? 'رمز الدعوة' : 'Invite Code'} value={joinCode} onChange={(e) => setJoinCode(e.target.value)} placeholder="FAM-XXXXXX" required />
            <PrimaryButton type="submit" className="w-full">
              {isAr ? 'انضمام للعائلة' : 'Join Family'}
            </PrimaryButton>
          </form>
        </GlassCard>

        {errorMsg && <p className="md:col-span-2 text-sm text-red-400 text-center">{errorMsg}</p>}
      </div>
    );
  }

  const canManage = currentMember && ['owner', 'admin'].includes(currentMember.role);

  return (
    <div className="space-y-6">
      {/* Family Header */}
      <GlassCard className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-500/35 flex items-center justify-center text-purple-300">
            <Users size={22} />
          </div>
          <div>
            <h3 className="text-lg font-bold">{family.name}</h3>
            <p className="text-xs opacity-65 flex items-center gap-1.5">
              <Lock size={12} className="text-emerald-400" />
              <span>{isAr ? 'بيانات العائلة محمية ومعزولة حسب الصلاحيات' : 'Protected family workspace with RBAC isolation'}</span>
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={async () => {
              await navigator.clipboard.writeText(family.invite_code);
              setCopied(true);
              setTimeout(() => setCopied(false), 2000);
            }}
            className="min-h-[40px] px-3.5 rounded-xl bg-white/8 border border-white/12 text-xs font-mono inline-flex items-center gap-2 cursor-pointer"
          >
            {copied ? <Check size={14} className="text-emerald-400" /> : <Copy size={14} />}
            <span>{family.invite_code}</span>
          </button>
          {canManage && (
            <button
              onClick={() => setMemberModal(true)}
              className="min-h-[40px] px-3.5 rounded-xl bg-white/8 hover:bg-white/14 border border-white/12 text-xs font-semibold inline-flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus size={15} />
              <span>{isAr ? 'إضافة فرد' : 'Add Member'}</span>
            </button>
          )}
          <PrimaryButton onClick={() => setItemModal(true)}>
            <Plus size={16} />
            <span>{isAr ? 'إضافة عنصر عائلي' : 'Add Family Item'}</span>
          </PrimaryButton>
        </div>
      </GlassCard>

      {/* Family Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'أفراد العائلة' : 'Family Members'}</p>
          <p className="text-2xl font-bold font-mono-num mt-1">{members.length}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'المصروفات والفواتير المشتركة' : 'Shared Expenses & Bills'}</p>
          <p className="text-2xl font-bold font-mono-num text-[#FF7900] mt-1">{formatCurrency(stats.expenses, lang)}</p>
        </GlassCard>
        <GlassCard className="p-4">
          <p className="text-xs opacity-60">{isAr ? 'مدخرات العائلة' : 'Family Savings'}</p>
          <p className="text-2xl font-bold font-mono-num text-emerald-400 mt-1">{formatCurrency(stats.goalsTotal, lang)}</p>
        </GlassCard>
      </div>

      {/* Members + Shared Items */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        <GlassCard className="p-5 lg:col-span-5 space-y-3">
          <h4 className="text-sm font-bold flex items-center gap-2">
            <Shield size={15} className="text-[#FF7900]" />
            <span>{isAr ? 'الأعضاء والصلاحيات' : 'Members & Permissions'}</span>
          </h4>
          <div className="space-y-2.5">
            {members.map((m) => {
              const perms = JSON.parse(m.permissions || '{}');
              return (
                <div key={m.id} className="rounded-2xl bg-white/[0.04] border border-white/10 p-3.5 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-9 h-9 rounded-full flex items-center justify-center font-bold text-sm text-white"
                        style={{ backgroundColor: m.avatar_color || '#FF7900' }}
                      >
                        {m.display_name.slice(0, 1)}
                      </div>
                      <div>
                        <p className="text-sm font-bold">{m.display_name}</p>
                        <p className="text-xs opacity-60">{m.relation} · {m.role}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2 text-[11px] opacity-75">
                    <span>{perms.view_budget ? '✓ الميزانية' : '✕ الميزانية'}</span>
                    <span>· {perms.add_expenses ? '✓ إضافة مصروفات' : '✕ إضافة مصروفات'}</span>
                    <span>· {perms.manage_tasks ? '✓ المهام' : '✕ المهام'}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </GlassCard>

        <GlassCard className="p-5 lg:col-span-7 space-y-3">
          <h4 className="text-sm font-bold">{isAr ? 'الأنشطة والمصروفات والمهام العائلية' : 'Shared Family Ledger & Chores'}</h4>
          {items.length === 0 ? (
            <div className="py-12 text-center text-sm opacity-60">{isAr ? 'لا توجد عناصر عائلية مشتركة بعد.' : 'No shared family items yet.'}</div>
          ) : (
            <div className="space-y-2.5 max-h-[420px] overflow-y-auto">
              {items.map((it) => (
                <div key={it.id} className="rounded-2xl bg-white/[0.04] border border-white/10 p-3.5 flex items-center justify-between gap-3">
                  <div>
                    <p className="text-sm font-bold">{it.title}</p>
                    <p className="text-xs opacity-60">
                      {it.item_type} {it.assigned_to ? `· ${it.assigned_to}` : ''} {it.due_date ? `· ${it.due_date}` : ''}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {it.amount > 0 && <span className="text-sm font-bold font-mono-num text-[#FF7900]">{formatCurrency(it.amount, lang)}</span>}
                    <button
                      onClick={async () => {
                        await apiFetch(`/api/family/items/${it.id}`, {
                          method: 'PATCH',
                          body: JSON.stringify({ status: it.status === 'completed' ? 'pending' : 'completed', amount: it.amount }),
                        });
                        load();
                      }}
                      className={`px-2.5 py-1 rounded-lg text-xs cursor-pointer ${
                        it.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-white/10'
                      }`}
                    >
                      {it.status === 'completed' ? (isAr ? 'مكتمل' : 'Done') : isAr ? 'قيد المتابعة' : 'Active'}
                    </button>
                    <button
                      onClick={async () => {
                        await apiFetch(`/api/family/items/${it.id}`, { method: 'DELETE' });
                        load();
                      }}
                      className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 cursor-pointer"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </GlassCard>
      </div>

      {/* Add Member Modal */}
      <GlassModal open={memberModal} onClose={() => setMemberModal(false)} title={isAr ? 'إضافة فرد للعائلة' : 'Add Family Member'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/family/members', {
              method: 'POST',
              body: JSON.stringify({
                display_name: mForm.display_name,
                relation: mForm.relation,
                role: mForm.role,
                permissions: {
                  view_budget: mForm.view_budget,
                  add_expenses: mForm.add_expenses,
                  view_calendar: mForm.view_calendar,
                  manage_tasks: mForm.manage_tasks,
                },
              }),
            });
            setMemberModal(false);
            load();
          }}
          className="space-y-3.5"
        >
          <InputField label={isAr ? 'الاسم' : 'Display Name'} value={mForm.display_name} onChange={(e) => setMForm({ ...mForm, display_name: e.target.value })} required />
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'صلة القرابة' : 'Relation'} value={mForm.relation} onChange={(e) => setMForm({ ...mForm, relation: e.target.value })} placeholder="أب / أم / ابن" />
            <SelectField label={isAr ? 'الدور' : 'Role'} value={mForm.role} onChange={(e) => setMForm({ ...mForm, role: e.target.value as 'admin' | 'member' | 'viewer' })}>
              <option value="admin">{isAr ? 'مشرف' : 'Admin'}</option>
              <option value="member">{isAr ? 'عضو' : 'Member'}</option>
              <option value="viewer">{isAr ? 'مشاهد فقط' : 'Viewer'}</option>
            </SelectField>
          </div>
          <div className="space-y-2 rounded-2xl bg-white/5 p-3 text-xs">
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={mForm.view_budget} onChange={(e) => setMForm({ ...mForm, view_budget: e.target.checked })} className="accent-[#FF7900]" />
              <span>{isAr ? 'عرض الميزانية والمصروفات العائلية' : 'View Family Budget & Expenses'}</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={mForm.add_expenses} onChange={(e) => setMForm({ ...mForm, add_expenses: e.target.checked })} className="accent-[#FF7900]" />
              <span>{isAr ? 'إضافة مصروفات وفواتير' : 'Add Expenses & Bills'}</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input type="checkbox" checked={mForm.manage_tasks} onChange={(e) => setMForm({ ...mForm, manage_tasks: e.target.checked })} className="accent-[#FF7900]" />
              <span>{isAr ? 'إدارة المهام المنزلية' : 'Manage Household Tasks'}</span>
            </label>
          </div>
          <PrimaryButton type="submit" className="w-full">
            {isAr ? 'حفظ العضو' : 'Add Member'}
          </PrimaryButton>
        </form>
      </GlassModal>

      {/* Add Family Item Modal */}
      <GlassModal open={itemModal} onClose={() => setItemModal(false)} title={isAr ? 'إضافة عنصر عائلي' : 'Add Family Item'}>
        <form
          onSubmit={async (e) => {
            e.preventDefault();
            await apiFetch('/api/family/items', {
              method: 'POST',
              body: JSON.stringify({
                ...iForm,
                amount: Number(iForm.amount || 0),
                target_amount: Number(iForm.target_amount || 0),
              }),
            });
            setItemModal(false);
            load();
          }}
          className="space-y-3.5"
        >
          <SelectField label={isAr ? 'النوع' : 'Type'} value={iForm.item_type} onChange={(e) => setIForm({ ...iForm, item_type: e.target.value as FamilyItem['item_type'] })}>
            <option value="expense">{isAr ? 'مصروف عائلي' : 'Family Expense'}</option>
            <option value="bill">{isAr ? 'فاتورة مشتركة' : 'Shared Bill'}</option>
            <option value="purchase">{isAr ? 'مشتريات مشتركة' : 'Shared Purchase'}</option>
            <option value="task">{isAr ? 'مهمة منزلية' : 'Household Chore'}</option>
            <option value="goal">{isAr ? 'هدف ادخار عائلي' : 'Family Savings Goal'}</option>
          </SelectField>
          <InputField label={isAr ? 'العنوان' : 'Title'} value={iForm.title} onChange={(e) => setIForm({ ...iForm, title: e.target.value })} required />
          <div className="grid grid-cols-2 gap-3">
            <InputField label={isAr ? 'المبلغ (إن وجد)' : 'Amount'} type="number" value={iForm.amount} onChange={(e) => setIForm({ ...iForm, amount: e.target.value })} />
            <InputField label={isAr ? 'المكلف بها' : 'Assigned To'} value={iForm.assigned_to} onChange={(e) => setIForm({ ...iForm, assigned_to: e.target.value })} />
          </div>
          <InputField label={isAr ? 'التاريخ' : 'Due Date'} type="date" value={iForm.due_date} onChange={(e) => setIForm({ ...iForm, due_date: e.target.value })} />
          <PrimaryButton type="submit" className="w-full">
            {isAr ? 'حفظ' : 'Save'}
          </PrimaryButton>
        </form>
      </GlassModal>
    </div>
  );
};
